﻿using LosSantosRED.lsr.Interface;

public interface ILocationSetupable
{
    void Setup();
}