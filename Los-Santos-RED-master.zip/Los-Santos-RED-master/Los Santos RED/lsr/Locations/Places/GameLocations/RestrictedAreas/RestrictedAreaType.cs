﻿public enum RestrictedAreaType
{
    None,
    ImpoundLot,
    Jail,
    PoliceLot,
    GovernmentFacility,
    Airport,
    Port,
    Bank,
}