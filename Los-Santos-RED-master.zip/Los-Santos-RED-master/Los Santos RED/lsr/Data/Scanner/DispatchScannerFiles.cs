﻿public class DispatchScannerFiles
{
    public DispatchScannerFiles()
    {

    }
    //public class gtaiv_legacy_support
    //{
    //    public static ScannerFile InuhhEast { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x007624B6.mp3", "In...uhh... East.", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile InuhhWestern { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x00C21410.mp3", "In...uhh... Western", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile InuhhWest { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x040B13FE.mp3", "In...uhh... West", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile beepplaceholderbeep { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x06C2C42B.mp3", "*beep*placeholder(?)*beep*", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile FIBteamdispatchingfrom { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x0708C2C6.mp3", "FIB team dispatching from...", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile Dispatchairunitfrom { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x095C198D.mp3", "Dispatch air unit from...", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile DispatchingSWATunitsfrom { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x0F106A48.mp3", "Dispatching SWAT units from...", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile InuhhNorth { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x11889985.mp3", "In...uhh... North", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile InuhhCentral { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x13A847B7.mp3", "In...uhh... Central", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile InuhhNorthern { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x1B806676.mp3", "In...uhh... Northern", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile InEastern { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x1CC03B69.mp3", "In... Eastern", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile InuhhSouth { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x1D349635.mp3", "In...uhh... South", "0_gtaiv_legacy_support"); } }
    //    public static ScannerFile InuhhSouthern { get { return new ScannerFile("01_0_gtaiv_legacy_support\\0x1D74BE76.mp3", "In...uhh... Southern", "0_gtaiv_legacy_support"); } }
    //}
    //public class gtaiv_legacy_support_small
    //{
    //    public static ScannerFile Suspect { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x003685A2.mp3", "Suspect", "0_gtaiv_legacy_support_small"); } }
    //    public static ScannerFile for121 { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x01A766C8.mp3", "for(?)", "0_gtaiv_legacy_support_small"); } }
    //    public static ScannerFile Uhh { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x01E5D9FA.mp3", "Uhh...", "0_gtaiv_legacy_support_small"); } }
    //    public static ScannerFile Bright { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x0866A86E.mp3", "Bright", "0_gtaiv_legacy_support_small"); } }
    //    public static ScannerFile Dark { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x0B35C659.mp3", "Dark", "0_gtaiv_legacy_support_small"); } }
    //    public static ScannerFile Light { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x0E18707B.mp3", "Light", "0_gtaiv_legacy_support_small"); } }
    //    public static ScannerFile Central { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x0E43511A.mp3", "Central", "0_gtaiv_legacy_support_small"); } }
    //    public static ScannerFile Lastseen { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x15B4F5FC.mp3", "Last seen", "0_gtaiv_legacy_support_small"); } }
    //    public static ScannerFile beep { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x189A930F.mp3", "*beep*", "0_gtaiv_legacy_support_small"); } }
    //    public static ScannerFile Heading { get { return new ScannerFile("01_0_gtaiv_legacy_support_small\\0x19DDC879.mp3", "Heading", "0_gtaiv_legacy_support_small"); } }
    //}
    //public class age
    //{
    //    public static ScannerFile Early50s { get { return new ScannerFile("01_age\\0x00617E13.mp3", "Early 50s", "age"); } }
    //    public static ScannerFile Early20s { get { return new ScannerFile("01_age\\0x028E8E07.mp3", "Early 20s", "age"); } }
    //    public static ScannerFile Young { get { return new ScannerFile("01_age\\0x057E03E3.mp3", "Young", "age"); } }
    //    public static ScannerFile Elderly { get { return new ScannerFile("01_age\\0x09B1D180.mp3", "Elderly", "age"); } }
    //    public static ScannerFile Late20s { get { return new ScannerFile("01_age\\0x0F4F6D73.mp3", "Late 20s", "age"); } }
    //    public static ScannerFile Mid20s { get { return new ScannerFile("01_age\\0x107FA3B0.mp3", "Mid 20s", "age"); } }
    //    public static ScannerFile Late50s { get { return new ScannerFile("01_age\\0x11BC4434.mp3", "Late 50s", "age"); } }
    //    public static ScannerFile Mid50s { get { return new ScannerFile("01_age\\0x164F5F0E.mp3", "Mid 50s", "age"); } }
    //    public static ScannerFile Mid40s { get { return new ScannerFile("01_age\\0x16B57506.mp3", "Mid 40s", "age"); } }
    //    public static ScannerFile Early30s { get { return new ScannerFile("01_age\\0x18ECC893.mp3", "Early 30s", "age"); } }
    //    public static ScannerFile Mid30s { get { return new ScannerFile("01_age\\0x198138E7.mp3", "Mid 30s", "age"); } }
    //    public static ScannerFile Late30s { get { return new ScannerFile("01_age\\0x1A9DE131.mp3", "Late 30s", "age"); } }
    //    public static ScannerFile Late40s { get { return new ScannerFile("01_age\\0x1C74AC5A.mp3", "Late 40s", "age"); } }
    //    public static ScannerFile Teenage { get { return new ScannerFile("01_age\\0x1D5268E6.mp3", "Teenage", "age"); } }
    //    public static ScannerFile Early40s { get { return new ScannerFile("01_age\\0x1F9A8632.mp3", "Early 40s", "age"); } }
    //}
    //public class air_support_shoot_tires
    //{
    //    public static ScannerFile Airsupportceasefireonsuspectsvehicle { get { return new ScannerFile("01_air_support_shoot_tires\\0x00B655FE.mp3", "Air support, cease fire on suspect's vehicle.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportholdyourfire { get { return new ScannerFile("01_air_support_shoot_tires\\0x03C6DB9C.mp3", "Air support, hold your fire.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportmoveinatinmobileatsuspectsvehicle { get { return new ScannerFile("01_air_support_shoot_tires\\0x06694A56.mp3", "Air support, move in at in mobile at suspect's vehicle.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportyouareagotoimmobilizesuspectsvehicle { get { return new ScannerFile("01_air_support_shoot_tires\\0x09FE117F.mp3", "Air support, you are a go to immobilize suspect's vehicle.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportceasefire { get { return new ScannerFile("01_air_support_shoot_tires\\0x0A63E8D7.mp3", "Air support, cease fire.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportholdfire { get { return new ScannerFile("01_air_support_shoot_tires\\0x110F362E.mp3", "Air support, hold fire.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportholdyourfire1 { get { return new ScannerFile("01_air_support_shoot_tires\\0x1A46091E.mp3", "Air support, hold your fire.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportceasefiringonthevehicle { get { return new ScannerFile("01_air_support_shoot_tires\\0x1AED49EA.mp3", "Air support, cease firing on the vehicle.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportceasefire1 { get { return new ScannerFile("01_air_support_shoot_tires\\0x1C300C70.mp3", "Air support, cease fire.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportmoveinandimmobilizesuspectsvehicle { get { return new ScannerFile("01_air_support_shoot_tires\\0x1C36B5F0.mp3", "Air support, move in and immobilize suspect's vehicle.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupportyouarecleartoimmobilizesuspectsvehicle { get { return new ScannerFile("01_air_support_shoot_tires\\0x1F7BFC7C.mp3", "Air support, you are clear to immobilize suspect's vehicle.", "air_support_shoot_tires"); } }
    //    public static ScannerFile Airsupporttakeoutsuspectstires { get { return new ScannerFile("01_air_support_shoot_tires\\0x1FB47CEB.mp3", "Air support, take out suspect's tires.", "air_support_shoot_tires"); } }
    //}
    //public class all_crooks_caught
    //{
    //    public static ScannerFile Allsuspectsapprehended { get { return new ScannerFile("01_all_crooks_caught\\0x08CC5E87.mp3", "All suspects apprehended.", "all_crooks_caught"); } }
    //    public static ScannerFile Allsuspects1015 { get { return new ScannerFile("01_all_crooks_caught\\0x0DAB6838.mp3", "All suspects 10-15.", "all_crooks_caught"); } }
    //    public static ScannerFile Allcriminalsincustody { get { return new ScannerFile("01_all_crooks_caught\\0x1BD6048E.mp3", "All criminals in custody.", "all_crooks_caught"); } }
    //}
    public class areas
    {
        public static ScannerFile PalmerTaylorPowerStation { get { return new ScannerFile("01_areas\\0x001F9BDF.mp3", "Palmer-Taylor Power Station", "areas"); } }
        public static ScannerFile WestVinewood { get { return new ScannerFile("01_areas\\0x006C113D.mp3", "West Vinewood", "areas"); } }
        public static ScannerFile Strawberry { get { return new ScannerFile("01_areas\\0x012E7CF0.mp3", "Strawberry", "areas"); } }
        public static ScannerFile PaletoBay { get { return new ScannerFile("01_areas\\0x014B6EC2.mp3", "Paleto Bay", "areas"); } }
        public static ScannerFile TheMazeBankStadium { get { return new ScannerFile("01_areas\\0x017459B6.mp3", "The Maze Bank Stadium", "areas"); } }
        public static ScannerFile VinewoodHills { get { return new ScannerFile("01_areas\\0x0184FB75.mp3", "Vinewood Hills", "areas"); } }
        public static ScannerFile SouthLosSantos { get { return new ScannerFile("01_areas\\0x018BAE55.mp3", "South Los Santos", "areas"); } }
        public static ScannerFile TextileCity { get { return new ScannerFile("01_areas\\0x01E8415E.mp3", "Textile City", "areas"); } }
        public static ScannerFile BayTreeCanyon { get { return new ScannerFile("01_areas\\0x02011728.mp3", "Bay Tree Canyon", "areas"); } }
        public static ScannerFile MirrorPark { get { return new ScannerFile("01_areas\\0x021443CE.mp3", "Mirror Park", "areas"); } }
        public static ScannerFile TongvaValley { get { return new ScannerFile("01_areas\\0x023C5452.mp3", "Tongva Valley", "areas"); } }
        public static ScannerFile RonAlternatesWindFarm { get { return new ScannerFile("01_areas\\0x028CCF7A.mp3", "Ron Alternates Wind Farm", "areas"); } }
        public static ScannerFile SlabCity { get { return new ScannerFile("01_areas\\0x029DB946.mp3", "Slab City", "areas"); } }
        public static ScannerFile Eclipse { get { return new ScannerFile("01_areas\\0x02CA0B60.mp3", "Eclipse", "areas"); } }
        public static ScannerFile LasPuertasFreeway { get { return new ScannerFile("01_areas\\0x02E1BE9C.mp3", "Las Puertas Freeway", "areas"); } }
        public static ScannerFile VespucciBeach { get { return new ScannerFile("01_areas\\0x0345886A.mp3", "Vespucci Beach", "areas"); } }
        public static ScannerFile MarlowDrive { get { return new ScannerFile("01_areas\\0x0364A059.mp3", "Marlow Drive", "areas"); } }
        public static ScannerFile EastLosSantos { get { return new ScannerFile("01_areas\\0x036541D5.mp3", "East Los Santos", "areas"); } }
        public static ScannerFile LagoZancudo { get { return new ScannerFile("01_areas\\0x0387465C.mp3", "Lago Zancudo", "areas"); } }
        public static ScannerFile Vespucci { get { return new ScannerFile("01_areas\\0x03A3CA25.mp3", "Vespucci", "areas"); } }
        public static ScannerFile Terminal { get { return new ScannerFile("01_areas\\0x03C9418A.mp3", "Terminal", "areas"); } }
        public static ScannerFile PacificBluffs { get { return new ScannerFile("01_areas\\0x03DBE985.mp3", "Pacific Bluffs", "areas"); } }
        public static ScannerFile TheChiliadMountainStateWilderness { get { return new ScannerFile("01_areas\\0x03F7E5D5.mp3", "The Chiliad Mountain State Wilderness", "areas"); } }
        public static ScannerFile MuriettaHeights { get { return new ScannerFile("01_areas\\0x04672520.mp3", "Murietta Heights", "areas"); } }
        public static ScannerFile MountGordo { get { return new ScannerFile("01_areas\\0x05136C06.mp3", "Mount Gordo", "areas"); } }
        public static ScannerFile LasPuertasFreeway1 { get { return new ScannerFile("01_areas\\0x05358344.mp3", "Las Puertas Freeway", "areas"); } }
        public static ScannerFile MountChiliad { get { return new ScannerFile("01_areas\\0x05390970.mp3", "Mount Chiliad", "areas"); } }
        public static ScannerFile LosSantosInternationalAirport { get { return new ScannerFile("01_areas\\0x05E7E888.mp3", "Los Santos International Airport", "areas"); } }
        public static ScannerFile RatonCanyon { get { return new ScannerFile("01_areas\\0x060A34CC.mp3", "Raton Canyon", "areas"); } }
        public static ScannerFile Route68approach { get { return new ScannerFile("01_areas\\0x06F346C2.mp3", "Route 68 approach", "areas"); } }
        public static ScannerFile LosPorta { get { return new ScannerFile("01_areas\\0x07ADC1D6.mp3", "Los Porta(?)", "areas"); } }
        public static ScannerFile Harmony { get { return new ScannerFile("01_areas\\0x07B1DA7C.mp3", "Harmony", "areas"); } }
        public static ScannerFile GalileoPark { get { return new ScannerFile("01_areas\\0x07EFD2BE.mp3", "Galileo Park", "areas"); } }
        public static ScannerFile LittleSeoul { get { return new ScannerFile("01_areas\\0x0803333B.mp3", "Little Seoul", "areas"); } }
        public static ScannerFile PaletoForest { get { return new ScannerFile("01_areas\\0x08D2B05D.mp3", "PaletoForest", "areas"); } }
        public static ScannerFile PillboxHill { get { return new ScannerFile("01_areas\\0x092393C4.mp3", "PillboxHill", "areas"); } }
        public static ScannerFile VespucciCanal { get { return new ScannerFile("01_areas\\0x092C44E3.mp3", "VespucciCanal", "areas"); } }
        public static ScannerFile MirrorPark_1 { get { return new ScannerFile("01_areas\\0x09F6938F.mp3", "MirrorPark", "areas"); } }
        public static ScannerFile PartolaDrive { get { return new ScannerFile("01_areas\\0x0A0F49DE.mp3", "PartolaDrive", "areas"); } }
        public static ScannerFile PortOfSouthLosSantos { get { return new ScannerFile("01_areas\\0x0A4783C2.mp3", "PortOfSouthLosSantos", "areas"); } }
        public static ScannerFile LosPuertesStadium { get { return new ScannerFile("01_areas\\0x0A5D231E.mp3", "LosPuertesStadium", "areas"); } }
        public static ScannerFile SandyShores { get { return new ScannerFile("01_areas\\0x0AFA8A12.mp3", "SandyShores", "areas"); } }
        public static ScannerFile GrandeSonoranDesert { get { return new ScannerFile("01_areas\\0x0B00BF56.mp3", "GrandeSonoranDesert", "areas"); } }
        public static ScannerFile ProcopioBeach { get { return new ScannerFile("01_areas\\0x0B8229F0.mp3", "ProcopioBeach", "areas"); } }
        public static ScannerFile NorthChumash { get { return new ScannerFile("01_areas\\0x0B9376DB.mp3", "NorthChumash", "areas"); } }
        public static ScannerFile LosSantosFreeway { get { return new ScannerFile("01_areas\\0x0BB07036.mp3", "LosSantosFreeway", "areas"); } }
        public static ScannerFile MazeBankArena { get { return new ScannerFile("01_areas\\0x0BC694DB.mp3", "MazeBankArena", "areas"); } }
        public static ScannerFile UtopiaGardens { get { return new ScannerFile("01_areas\\0x0BDCCEF7.mp3", "UtopiaGardens", "areas"); } }
        public static ScannerFile LosSantosInternational { get { return new ScannerFile("01_areas\\0x0BFD1A02.mp3", "LosSantosInternational", "areas"); } }
        public static ScannerFile MtJosiah { get { return new ScannerFile("01_areas\\0x0CBDAD0D.mp3", "MtJosiah", "areas"); } }
        public static ScannerFile TheRedwoodLightsTrack { get { return new ScannerFile("01_areas\\0x0D2920BD.mp3", "TheRedwoodLightsTrack", "areas"); } }
        public static ScannerFile LosSantosInternational_1 { get { return new ScannerFile("01_areas\\0x0D4D375A.mp3", "LosSantosInternational", "areas"); } }
        public static ScannerFile Chumash { get { return new ScannerFile("01_areas\\0x0D68048E.mp3", "Chumash", "areas"); } }
        public static ScannerFile Chumash_1 { get { return new ScannerFile("01_areas\\0x0D9B84EB.mp3", "Chumash", "areas"); } }
        public static ScannerFile PorcopiaTruckStop { get { return new ScannerFile("01_areas\\0x0DAB6018.mp3", "PorcopiaTruckStop", "areas"); } }
        public static ScannerFile RockfordHills { get { return new ScannerFile("01_areas\\0x0E1A3BD7.mp3", "RockfordHills", "areas"); } }
        public static ScannerFile EastVinewood { get { return new ScannerFile("01_areas\\0x0E1C639C.mp3", "EastVinewood", "areas"); } }
        public static ScannerFile SouthLosSantos_1 { get { return new ScannerFile("01_areas\\0x0E61C7FF.mp3", "SouthLosSantos", "areas"); } }
        public static ScannerFile GreatOceanHighway { get { return new ScannerFile("01_areas\\0x0EA94CB1.mp3", "GreatOceanHighway", "areas"); } }
        public static ScannerFile GreatChapparalle { get { return new ScannerFile("01_areas\\0x0EA9C578.mp3", "GreatChapparalle", "areas"); } }
        public static ScannerFile ChamberlainHills { get { return new ScannerFile("01_areas\\0x0EF6ED8C.mp3", "ChamberlainHills", "areas"); } }
        public static ScannerFile Vinewood { get { return new ScannerFile("01_areas\\0x0F2B8859.mp3", "Vinewood", "areas"); } }
        public static ScannerFile DorsetDrive { get { return new ScannerFile("01_areas\\0x0F78F5C9.mp3", "DorsetDrive", "areas"); } }
        public static ScannerFile BraddockPass { get { return new ScannerFile("01_areas\\0x0FA9EE2A.mp3", "BraddockPass", "areas"); } }
        public static ScannerFile TongaHills { get { return new ScannerFile("01_areas\\0x0FF01B2B.mp3", "TongaHills", "areas"); } }
        public static ScannerFile PacificBluffs_1 { get { return new ScannerFile("01_areas\\0x101A0201.mp3", "PacificBluffs", "areas"); } }
        public static ScannerFile LaPuertes { get { return new ScannerFile("01_areas\\0x106A6182.mp3", "LaPuertes", "areas"); } }
        public static ScannerFile Richman { get { return new ScannerFile("01_areas\\0x10C9CE0E.mp3", "Richman", "areas"); } }
        public static ScannerFile SanAndreas { get { return new ScannerFile("01_areas\\0x114D6EDA.mp3", "SanAndreas", "areas"); } }
        public static ScannerFile DavisCourts { get { return new ScannerFile("01_areas\\0x118C3C55.mp3", "DavisCourts", "areas"); } }
        public static ScannerFile TheAlamaSea { get { return new ScannerFile("01_areas\\0x11EC2FB7.mp3", "TheAlamaSea", "areas"); } }
        public static ScannerFile CountrySide { get { return new ScannerFile("01_areas\\0x12D2E37E.mp3", "CountrySide", "areas"); } }
        public static ScannerFile Burton { get { return new ScannerFile("01_areas\\0x12FF796D.mp3", "Burton", "areas"); } }
        public static ScannerFile TheBraddockTunnel { get { return new ScannerFile("01_areas\\0x13538DA2.mp3", "TheBraddockTunnel", "areas"); } }
        public static ScannerFile Alta { get { return new ScannerFile("01_areas\\0x138D4EAB.mp3", "Alta", "areas"); } }
        public static ScannerFile EastLosSantos_1 { get { return new ScannerFile("01_areas\\0x13A22250.mp3", "EastLosSantos", "areas"); } }
        public static ScannerFile MorningWood { get { return new ScannerFile("01_areas\\0x13C5B629.mp3", "MorningWood", "areas"); } }
        public static ScannerFile BoilingBrookPenitentiary { get { return new ScannerFile("01_areas\\0x13CCE7C9.mp3", "BoilingBrookPenitentiary", "areas"); } }
        public static ScannerFile Banning { get { return new ScannerFile("01_areas\\0x13F1BE48.mp3", "Banning", "areas"); } }
        public static ScannerFile TheRaceCourse { get { return new ScannerFile("01_areas\\0x13F539FA.mp3", "TheRaceCourse", "areas"); } }
        public static ScannerFile ChilliadMountainStWilderness { get { return new ScannerFile("01_areas\\0x140A2311.mp3", "0x140A2311", "areas"); } }
        public static ScannerFile DowntownVinewood { get { return new ScannerFile("01_areas\\0x149F97C8.mp3", "DowntownVinewood", "areas"); } }
        public static ScannerFile Downtown { get { return new ScannerFile("01_areas\\0x14E31C13.mp3", "Downtown", "areas"); } }
        public static ScannerFile PorcopioBeach { get { return new ScannerFile("01_areas\\0x14FF4DA7.mp3", "PorcopioBeach", "areas"); } }
        public static ScannerFile DelPierro { get { return new ScannerFile("01_areas\\0x153EE641.mp3", "DelPierro", "areas"); } }
        public static ScannerFile ZancudoRiver { get { return new ScannerFile("01_areas\\0x15BABEA1.mp3", "ZancudoRiver", "areas"); } }
        public static ScannerFile Richman_1 { get { return new ScannerFile("01_areas\\0x16E5DA45.mp3", "Richman_1", "areas"); } }
        public static ScannerFile FtZancudo { get { return new ScannerFile("01_areas\\0x16E98448.mp3", "FtZancudo", "areas"); } }
        public static ScannerFile MissionRow { get { return new ScannerFile("01_areas\\0x17235ECC.mp3", "MissionRow", "areas"); } }
        public static ScannerFile Howard { get { return new ScannerFile("01_areas\\0x17919CF8.mp3", "Howard", "areas"); } }
        public static ScannerFile SanTiaskiMtRange { get { return new ScannerFile("01_areas\\0x17AD6380.mp3", "SanTiaskiMtRange", "areas"); } }
        public static ScannerFile TheRedwoodLightsTrack_1 { get { return new ScannerFile("01_areas\\0x17BA758E.mp3", "TheRedwoodLightsTrack", "areas"); } }
        public static ScannerFile ZancudoRiver_1 { get { return new ScannerFile("01_areas\\0x17D282D1.mp3", "ZancudoRiver", "areas"); } }
        public static ScannerFile SonoraWindfarm { get { return new ScannerFile("01_areas\\0x17E495A5.mp3", "SonoraWindfarm", "areas"); } }
        public static ScannerFile BacklotCity { get { return new ScannerFile("01_areas\\0x17F11DAD.mp3", "BacklotCity", "areas"); } }
        public static ScannerFile ElysianIsland { get { return new ScannerFile("01_areas\\0x1891CD57.mp3", "ElysianIsland", "areas"); } }
        public static ScannerFile PortOfSouthLosSantos_1 { get { return new ScannerFile("01_areas\\0x1891E057.mp3", "PortOfSouthLosSantos_1", "areas"); } }
        public static ScannerFile TheMovieStudios { get { return new ScannerFile("01_areas\\0x189EC125.mp3", "TheMovieStudios", "areas"); } }
        public static ScannerFile TheStadium { get { return new ScannerFile("01_areas\\0x18C2B8B5.mp3", "TheStadium", "areas"); } }
        public static ScannerFile LaMesa { get { return new ScannerFile("01_areas\\0x18C85309.mp3", "LaMesa", "areas"); } }
        public static ScannerFile Downtown_1 { get { return new ScannerFile("01_areas\\0x18D0A3EF.mp3", "Downtown", "areas"); } }
        public static ScannerFile TheGWCGolfingSociety { get { return new ScannerFile("01_areas\\0x1910AD05.mp3", "TheGWCGolfingSociety", "areas"); } }
        public static ScannerFile LittleSeoul_1 { get { return new ScannerFile("01_areas\\0x19319598.mp3", "LittleSeoul", "areas"); } }
        public static ScannerFile NorthYankton { get { return new ScannerFile("01_areas\\0x193D6DBC.mp3", "NorthYankton", "areas"); } }
        public static ScannerFile SandyShores_1 { get { return new ScannerFile("01_areas\\0x19BBE794.mp3", "SandyShores", "areas"); } }
        public static ScannerFile Chumash_2 { get { return new ScannerFile("01_areas\\0x1ACA5F52.mp3", "Chumash", "areas"); } }
        public static ScannerFile APMTerminal { get { return new ScannerFile("01_areas\\0x1AD23A10.mp3", "APMTerminal", "areas"); } }
        public static ScannerFile PuertoDelSoul { get { return new ScannerFile("01_areas\\0x1B64BCB8.mp3", "PuertoDelSoul", "areas"); } }
        public static ScannerFile Chumash_3 { get { return new ScannerFile("01_areas\\0x1B6CE08C.mp3", "Chumash", "areas"); } }
        public static ScannerFile RichmanGlenn { get { return new ScannerFile("01_areas\\0x1BD63BBB.mp3", "RichmanGlenn", "areas"); } }
        public static ScannerFile DelPierroBeach { get { return new ScannerFile("01_areas\\0x1C4C6513.mp3", "DelPierroBeach", "areas"); } }
        public static ScannerFile PalominoHighlands { get { return new ScannerFile("01_areas\\0x1C528EF2.mp3", "PalominoHighlands", "areas"); } }
        public static ScannerFile SonoraFreeway { get { return new ScannerFile("01_areas\\0x1C6991D6.mp3", "SonoraFreeway", "areas"); } }
        public static ScannerFile RedwoodLightsStadium { get { return new ScannerFile("01_areas\\0x1C8CEC13.mp3", "RedwoodLightsStadium", "areas"); } }
        public static ScannerFile CypressFlats { get { return new ScannerFile("01_areas\\0x1C9D42A2.mp3", "CypressFlats", "areas"); } }
        public static ScannerFile Grapeseed { get { return new ScannerFile("01_areas\\0x1C9D6CA9.mp3", "Grapeseed", "areas"); } }
        public static ScannerFile TatathiaMountains { get { return new ScannerFile("01_areas\\0x1CC50A90.mp3", "TatathiaMountains", "areas"); } }
        public static ScannerFile LosPuerta { get { return new ScannerFile("01_areas\\0x1CD22C22.mp3", "LosPuerta", "areas"); } }
        public static ScannerFile LostMCClubhouse { get { return new ScannerFile("01_areas\\0x1D127686.mp3", "LostMCClubhouse", "areas"); } }
        public static ScannerFile LaPorta { get { return new ScannerFile("01_areas\\0x1D9900EF.mp3", "LaPorta", "areas"); } }
        public static ScannerFile TheOcean { get { return new ScannerFile("01_areas\\0x1D9FFECB.mp3", "TheOcean", "areas"); } }
        public static ScannerFile RichardsMajesticStudio { get { return new ScannerFile("01_areas\\0x1DF1BA88.mp3", "RichardsMajesticStudio", "areas"); } }
        public static ScannerFile HeartAttacksBeach { get { return new ScannerFile("01_areas\\0x1E0EF1FA.mp3", "HeartAttacksBeach", "areas"); } }
        public static ScannerFile Rancho { get { return new ScannerFile("01_areas\\0x1E8562C5.mp3", "Rancho", "areas"); } }
        public static ScannerFile Davis { get { return new ScannerFile("01_areas\\0x1ED41C86.mp3", "Davis", "areas"); } }
        public static ScannerFile LaPortaFreeway { get { return new ScannerFile("01_areas\\0x1EE53212.mp3", "LaPortaFreeway", "areas"); } }
        public static ScannerFile ElBerroHights { get { return new ScannerFile("01_areas\\0x1EF77B93.mp3", "ElBerroHights", "areas"); } }
        public static ScannerFile DelPierro_1 { get { return new ScannerFile("01_areas\\0x1F7B7ABB.mp3", "DelPierro", "areas"); } }
        public static ScannerFile RockfordHills_1 { get { return new ScannerFile("01_areas\\0x1FD39F4A.mp3", "RockfordHills", "areas"); } }
    }
    //public class area_direction
    //{
    //    public static ScannerFile Northern { get { return new ScannerFile("01_area_direction\\0x00C822E3.mp3", "Northern", "area_direction"); } }
    //    public static ScannerFile Eastern { get { return new ScannerFile("01_area_direction\\0x00D20737.mp3", "Eastern", "area_direction"); } }
    //    public static ScannerFile Western { get { return new ScannerFile("01_area_direction\\0x03F4BFA1.mp3", "Western", "area_direction"); } }
    //    public static ScannerFile Central { get { return new ScannerFile("01_area_direction\\0x04886DF6.mp3", "Central", "area_direction"); } }
    //    public static ScannerFile Central1 { get { return new ScannerFile("01_area_direction\\0x088F3603.mp3", "Central", "area_direction"); } }
    //    public static ScannerFile Southern { get { return new ScannerFile("01_area_direction\\0x0A6BC575.mp3", "Southern", "area_direction"); } }
    //    public static ScannerFile Central1_1 { get { return new ScannerFile("01_area_direction\\0x123E8963.mp3", "Central", "area_direction"); } }
    //}
    public class assistance_required
    {
        public static ScannerFile Backupneeded { get { return new ScannerFile("01_assistance_required\\0x04BBD783.mp3", "Backup needed.", "assistance_required"); } }
        public static ScannerFile Officersneeded { get { return new ScannerFile("01_assistance_required\\0x09EF61E7.mp3", "Officers needed.", "assistance_required"); } }
        public static ScannerFile Assistancerequired { get { return new ScannerFile("01_assistance_required\\0x0D3F2889.mp3", "Assistance required.", "assistance_required"); } }
        public static ScannerFile Backuprequired { get { return new ScannerFile("01_assistance_required\\0x0F0BEC23.mp3", "Backup required.", "assistance_required"); } }
        public static ScannerFile Officersrequired { get { return new ScannerFile("01_assistance_required\\0x167DBB07.mp3", "Officers required.", "assistance_required"); } }
        public static ScannerFile Assistanceneeded { get { return new ScannerFile("01_assistance_required\\0x1D4D88A6.mp3", "Assistance needed.", "assistance_required"); } }
    }
    public class attempt_to_find
    {
        public static ScannerFile AllunitsATonsuspects20 { get { return new ScannerFile("01_attempt_to_find\\0x04F0EE36.mp3", "All units, AT on suspect's 20.", "attempt_to_find"); } }
        public static ScannerFile Allunitsattempttoreacquirevisual { get { return new ScannerFile("01_attempt_to_find\\0x0CD4FDFF.mp3", "All units, attempt to reacquire visual.", "attempt_to_find"); } }
        public static ScannerFile RemainintheareaATL20onsuspect { get { return new ScannerFile("01_attempt_to_find\\0x0F32C2BA.mp3", "Remain in the area; AT-L20 on suspect.", "attempt_to_find"); } }
        public static ScannerFile Allunitsattempttoreacquire { get { return new ScannerFile("01_attempt_to_find\\0x178D9375.mp3", "All units, attempt to reacquire.", "attempt_to_find"); } }
        public static ScannerFile RemainintheareaATL20onsuspect1 { get { return new ScannerFile("01_attempt_to_find\\0x1A92197A.mp3", "Remain in the area; AT-L20 on suspect.", "attempt_to_find"); } }
    }
    public class attention_all_area_units
    {
        public static ScannerFile MajesticCountyUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x0183A299.mp3", "Attention all Majestic County units,", "attention_all_area_units"); } }
        public static ScannerFile MajesticCountyUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x032265D7.mp3", "Dispatch to any available Majestic County unit,", "attention_all_area_units"); } }
        public static ScannerFile MajesticCountyUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x0CC93925.mp3", "Any available Majestic County unit", "attention_all_area_units"); } }
        public static ScannerFile MajesticCountyUnits4 { get { return new ScannerFile("01_attention_all_area_units\\0x18709072.mp3", "Any unit in the Majestic County area", "attention_all_area_units"); } }
        public static ScannerFile CentralUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x002E9CB4.mp3", "Any unit in the central area,", "attention_all_area_units"); } }
        public static ScannerFile CentralUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x02F56240.mp3", "Dispatch to any available central unit,", "attention_all_area_units"); } }
        public static ScannerFile CentralUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x12D3C1FD.mp3", "Dispatch to all central units", "attention_all_area_units"); } }
        public static ScannerFile PortOfLosSantosUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x006919FF.mp3", "Any unit in the Port of Los Santos area,", "attention_all_area_units"); } }
        public static ScannerFile PortOfLosSantosUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x11137B4A.mp3", "Dispatch to all Port of Los Santos units", "attention_all_area_units"); } }
        public static ScannerFile PortOfLosSantosUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x0AB3AEA2.mp3", "All available Port of Los Santos units", "attention_all_area_units"); } }
        public static ScannerFile PortOfLosSantosUnits4 { get { return new ScannerFile("01_attention_all_area_units\\0x1BE850F4.mp3", "Any available Port of Los Santos units", "attention_all_area_units"); } }
        public static ScannerFile DowntownUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x0DBA6A78.mp3", "All available downtown units", "attention_all_area_units"); } }
        public static ScannerFile DowntownUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x02C5949A.mp3", "Any unit in the downtown area,", "attention_all_area_units"); } }
        public static ScannerFile DowntownUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x1A434396.mp3", "Any available downtown unit", "attention_all_area_units"); } }
        public static ScannerFile DowntownUnits4 { get { return new ScannerFile("01_attention_all_area_units\\0x10FC3107.mp3", "Any available unit in the downtown area", "attention_all_area_units"); } }
        public static ScannerFile DowntownUnits5 { get { return new ScannerFile("01_attention_all_area_units\\0x14EC78E8.mp3", "Dispatch to any downtown unit", "attention_all_area_units"); } }
        public static ScannerFile DowntownUnits6 { get { return new ScannerFile("01_attention_all_area_units\\0x1FF0CEE5.mp3", "Attention all downtown units", "attention_all_area_units"); } }
        public static ScannerFile AirTrafficUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x026A5966.mp3", "Dispatch to all air traffic units,", "attention_all_area_units"); } }
        public static ScannerFile AirTrafficUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x0804A4A0.mp3", "Any available air traffic unit", "attention_all_area_units"); } }
        public static ScannerFile AirTrafficUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x16C28216.mp3", "Dispatch to any available air traffic unit", "attention_all_area_units"); } }
        public static ScannerFile ChumashUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x0271A78D.mp3", "Dispatch to any available Chumash unit,", "attention_all_area_units"); } }
        public static ScannerFile ChumashUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x0D257CF4.mp3", "Attention all Chumash units", "attention_all_area_units"); } }
        public static ScannerFile ChumashUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x104FC34A.mp3", "All available Chumash units", "attention_all_area_units"); } }
        public static ScannerFile CoastCuardUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x05922078.mp3", "Attention all Coast Guard units", "attention_all_area_units"); } }
        public static ScannerFile CoastGuardUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x126F7A3C.mp3", "Disptach to all Coast Guard units", "attention_all_area_units"); } }
        public static ScannerFile CoastGuardUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x183605CA.mp3", "Any available Coast Guard unit", "attention_all_area_units"); } }
        public static ScannerFile CoastGuardUnits4 { get { return new ScannerFile("01_attention_all_area_units\\0x184885E5.mp3", "All available Coast Guard units", "attention_all_area_units"); } }
        public static ScannerFile VespucciAreaUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x15DFDF96.mp3", "Any unit in the Vespucci area", "attention_all_area_units"); } }
        public static ScannerFile VespucciAreaUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x07A78326.mp3", "Any available unit in the Vespucci area", "attention_all_area_units"); } }
        public static ScannerFile EastLosSantosUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x04473B6D.mp3", "Attention all east Los Santos units", "attention_all_area_units"); } }
        public static ScannerFile EastLosSantosUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x127917D1.mp3", "Any available east Los Santos unit", "attention_all_area_units"); } }
        public static ScannerFile EastLosSantosUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x1EC9F072.mp3", "Any unit in the east Los Santos area", "attention_all_area_units"); } }
        public static ScannerFile SandyShoresUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x148BFCF6.mp3", "Any unit in the Sandy Shores area", "attention_all_area_units"); } }
        public static ScannerFile SandyShoresUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x17DBC397.mp3", "Attention all Sandy Shores units", "attention_all_area_units"); } }
        public static ScannerFile SandyShoresUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x0A36E84D.mp3", "Dispatch to all Sandy Shores units", "attention_all_area_units"); } }
        public static ScannerFile VenturaCountyUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x0412FFEA.mp3", "Dispatch to all Ventura County units", "attention_all_area_units"); } }
        public static ScannerFile VenturaCountyUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x1522220A.mp3", "Any available Ventura County unit", "attention_all_area_units"); } }
        public static ScannerFile VenturaCountyUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x16B56530.mp3", "Any availbe unit in the Ventura County area", "attention_all_area_units"); } }
        public static ScannerFile VenturaCountyUnits4 { get { return new ScannerFile("01_attention_all_area_units\\0x1E8634D1.mp3", "All availble Ventura County units", "attention_all_area_units"); } }
        public static ScannerFile VinewoodUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x1DA275D7.mp3", "0x1DA275D7", "attention_all_area_units"); } }
        public static ScannerFile VinewoodUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x16D8A845.mp3", "0x16D8A845", "attention_all_area_units"); } }
        public static ScannerFile VinewoodUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x1BBD320D.mp3", "0x1BBD320D", "attention_all_area_units"); } }
        public static ScannerFile PaletoBayUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x1DCDF6F8.mp3", "any available unit in the paleto bay area", "attention_all_area_units"); } }
        public static ScannerFile PaletoBayUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x18FFAD5C.mp3", "any available unit in the paleto bay area", "attention_all_area_units"); } }
        public static ScannerFile PaletoBayUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x032E41B8.mp3", "any available unit in the paleto bay area", "attention_all_area_units"); } }
        public static ScannerFile VinewoodHillsUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x1145C27E.mp3", "any unit in the vinewood hills area", "attention_all_area_units"); } }
        public static ScannerFile VinewoodHillsUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x0F6BBEC8.mp3", "any unit in the vinewood hills area", "attention_all_area_units"); } }
        public static ScannerFile VinewoodHillsUnits3 { get { return new ScannerFile("01_attention_all_area_units\\0x1CA5193B.mp3", "any unit in the vinewood hills area", "attention_all_area_units"); } }
        public static ScannerFile SouthLosSantosUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x1CEB8EB7.mp3", "any sourth los santos units", "attention_all_area_units"); } }
        public static ScannerFile SouthLosSantosUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x1E7BD1D7.mp3", "any sourth los santos units", "attention_all_area_units"); } }
        public static ScannerFile RedwoodLightsUnits1 { get { return new ScannerFile("01_attention_all_area_units\\0x1BC9F71B.mp3", "0x1BC9F71B", "attention_all_area_units"); } }
        public static ScannerFile RedwoodLightsUnits2 { get { return new ScannerFile("01_attention_all_area_units\\0x0A089398.mp3", "0x0A089398", "attention_all_area_units"); } }
        public static ScannerFile CapeCatfishUnits { get { return new ScannerFile("01_attention_all_area_units\\0x0361C69C.mp3", "0x0361C69C", "attention_all_area_units"); } }
        public static ScannerFile ZancudoRiverUnits { get { return new ScannerFile("01_attention_all_area_units\\0x05A60B35.mp3", "0x05A60B35", "attention_all_area_units"); } }
        public static ScannerFile GalilleUnits { get { return new ScannerFile("01_attention_all_area_units\\0x07872AFA.mp3", "0x07872AFA", "attention_all_area_units"); } }
        public static ScannerFile KalafiaBridgeUnits { get { return new ScannerFile("01_attention_all_area_units\\0x0B8B47C9.mp3", "0x0B8B47C9", "attention_all_area_units"); } }
        public static ScannerFile CassidyCreekUnits { get { return new ScannerFile("01_attention_all_area_units\\0x0D43C2A8.mp3", "0x0D43C2A8", "attention_all_area_units"); } }
        public static ScannerFile LandActDamnUnits { get { return new ScannerFile("01_attention_all_area_units\\0x0D8B042A.mp3", "0x0D8B042A", "attention_all_area_units"); } }
        public static ScannerFile HumaneLabsUnits { get { return new ScannerFile("01_attention_all_area_units\\0x0E5F5E95.mp3", "0x0E5F5E95", "attention_all_area_units"); } }
        public static ScannerFile BollingBrokeUnits { get { return new ScannerFile("01_attention_all_area_units\\0x10A654A4.mp3", "0x10A654A4", "attention_all_area_units"); } }
        public static ScannerFile AlamoSeaUnits { get { return new ScannerFile("01_attention_all_area_units\\0x1580264A.mp3", "0x1580264A", "attention_all_area_units"); } }
        public static ScannerFile VinewoodRacetrackUnits { get { return new ScannerFile("01_attention_all_area_units\\0x1824EF93.mp3", "0x1824EF93", "attention_all_area_units"); } }
        public static ScannerFile ElGordoLightHouseUnits { get { return new ScannerFile("01_attention_all_area_units\\0x1843E726.mp3", "0x1843E726", "attention_all_area_units"); } }
        public static ScannerFile PaletoBayDeltaUnits { get { return new ScannerFile("01_attention_all_area_units\\0x0F28DEDA.mp3", "0x0F28DEDA", "attention_all_area_units"); } }
        public static ScannerFile SanAndreasStateOfficeUnits { get { return new ScannerFile("01_attention_all_area_units\\0x1C807125.mp3", "0x1C807125", "attention_all_area_units"); } }
        public static ScannerFile RedwoodStadiumUnits { get { return new ScannerFile("01_attention_all_area_units\\0x1F400CC0.mp3", "0x1F400CC0", "attention_all_area_units"); } }
        public static ScannerFile LandActReservoirUnits { get { return new ScannerFile("01_attention_all_area_units\\0x1FE288E6.mp3", "0x1FE288E6", "attention_all_area_units"); } }

    }
    public class attention_all_units_gen
    {
        public static ScannerFile Attentionallunits { get { return new ScannerFile("01_attention_all_units_gen\\0x0834F3C0.mp3", "Attention all units,", "attention_all_units_gen"); } }
        public static ScannerFile Attentionallunits1 { get { return new ScannerFile("01_attention_all_units_gen\\0x0E42FFE4.mp3", "Attention all units,", "attention_all_units_gen"); } }
        public static ScannerFile Allunits { get { return new ScannerFile("01_attention_all_units_gen\\0x15078D6D.mp3", "All units,", "attention_all_units_gen"); } }
        public static ScannerFile Attentionallunits2 { get { return new ScannerFile("01_attention_all_units_gen\\0x1D7ADE4C.mp3", "Attention all units,", "attention_all_units_gen"); } }
        public static ScannerFile Attentionallunits3 { get { return new ScannerFile("01_attention_all_units_gen\\0x1EC1A0E1.mp3", "Attention all units,", "attention_all_units_gen"); } }
    }
    //public class attention_generic
    //{
    //    public static ScannerFile AttentionThisisdispatch { get { return new ScannerFile("01_attention_generic\\0x053CA2E6.mp3", "Attention. This is dispatch.", "attention_generic"); } }
    //    public static ScannerFile Attentionthisisdispatch { get { return new ScannerFile("01_attention_generic\\0x12043C6C.mp3", "Attention, this is dispatch.", "attention_generic"); } }
    //}
    public class attention_specific
    {
        public static ScannerFile Dispatchtocarumm { get { return new ScannerFile("01_attention_specific\\0x066E5F2B.mp3", "Dispatch to car umm...", "attention_specific"); } }
        public static ScannerFile Attentioncaruhh { get { return new ScannerFile("01_attention_specific\\0x073C20C6.mp3", "Attention car uhh...", "attention_specific"); } }
        public static ScannerFile Dispatchtocarumm1 { get { return new ScannerFile("01_attention_specific\\0x14D23BEE.mp3", "Dispatch to car umm...", "attention_specific"); } }
        public static ScannerFile Attentioncaruhh1 { get { return new ScannerFile("01_attention_specific\\0x1A1846A3.mp3", "Attention car uhh...", "attention_specific"); } }
        public static ScannerFile Attentioncaruhhorof { get { return new ScannerFile("01_attention_specific\\0x1D930D74.mp3", "Attention car uhh... (or 'of')", "attention_specific"); } }
    }
    public class attention_unit_specific
    {
        public static ScannerFile Dispatchcallingunitumm { get { return new ScannerFile("01_attention_unit_specific\\0x0AA6BFE8.mp3", "Dispatch calling unit umm...", "attention_unit_specific"); } }
        public static ScannerFile Dispatchcallingunit { get { return new ScannerFile("01_attention_unit_specific\\0x1874DB8F.mp3", "Dispatch calling unit...", "attention_unit_specific"); } }
        public static ScannerFile Attentionunit { get { return new ScannerFile("01_attention_unit_specific\\0x1E2DE701.mp3", "Attention unit...", "attention_unit_specific"); } }
    }
    //public class build
    //{
    //    public static ScannerFile BUILDATHLETIC01 { get { return new ScannerFile("01_build\\BUILD_ATHLETIC_01.mp3", "BUILD_ATHLETIC_01", "build"); } }
    //    public static ScannerFile BUILDAVERAGE01 { get { return new ScannerFile("01_build\\BUILD_AVERAGE_01.mp3", "BUILD_AVERAGE_01", "build"); } }
    //    public static ScannerFile BUILDHEAVY01 { get { return new ScannerFile("01_build\\BUILD_HEAVY_01.mp3", "BUILD_HEAVY_01", "build"); } }
    //    public static ScannerFile BUILDMUSCULAR01 { get { return new ScannerFile("01_build\\BUILD_MUSCULAR_01.mp3", "BUILD_MUSCULAR_01", "build"); } }
    //    public static ScannerFile BUILDOBESE01 { get { return new ScannerFile("01_build\\BUILD_OBESE_01.mp3", "BUILD_OBESE_01", "build"); } }
    //    public static ScannerFile BUILDSLENDER01 { get { return new ScannerFile("01_build\\BUILD_SLENDER_01.mp3", "BUILD_SLENDER_01", "build"); } }
    //    public static ScannerFile BUILDTHIN01 { get { return new ScannerFile("01_build\\BUILD_THIN_01.mp3", "BUILD_THIN_01", "build"); } }
    //}
    //public class car
    //{
    //    public static ScannerFile CAR01 { get { return new ScannerFile("01_car\\CAR_01.mp3", "CAR_01", "car"); } }
    //    public static ScannerFile CAR02 { get { return new ScannerFile("01_car\\CAR_02.mp3", "CAR_02", "car"); } }
    //    public static ScannerFile CAR03 { get { return new ScannerFile("01_car\\CAR_03.mp3", "CAR_03", "car"); } }
    //    public static ScannerFile CAR04 { get { return new ScannerFile("01_car\\CAR_04.mp3", "CAR_04", "car"); } }
    //    public static ScannerFile CAR05 { get { return new ScannerFile("01_car\\CAR_05.mp3", "CAR_05", "car"); } }
    //}
    public class carrying_weapon
    {
        public static ScannerFile Carryingagrenadelauncher { get { return new ScannerFile("01_carrying_weapon\\0x00FE11D6.mp3", "Carrying a grenade launcher.", "carrying_weapon"); } }
        public static ScannerFile ArmedwithanRPG { get { return new ScannerFile("01_carrying_weapon\\0x01007DCB.mp3", "Armed with an RPG.", "carrying_weapon"); } }
        public static ScannerFile Armedwithexplosives { get { return new ScannerFile("01_carrying_weapon\\0x01948EA6.mp3", "Armed with explosives.", "carrying_weapon"); } }
        public static ScannerFile Carryingaknife { get { return new ScannerFile("01_carrying_weapon\\0x01A0F654.mp3", "Carrying a knife.", "carrying_weapon"); } }
        public static ScannerFile Armedwithagun { get { return new ScannerFile("01_carrying_weapon\\0x048A699A.mp3", "Armed with a gun.", "carrying_weapon"); } }
        public static ScannerFile Carryingabat { get { return new ScannerFile("01_carrying_weapon\\0x04CFB5C1.mp3", "Carrying a bat.", "carrying_weapon"); } }
        public static ScannerFile Armedwithaweapon { get { return new ScannerFile("01_carrying_weapon\\0x04FA024B.mp3", "Armed with a weapon.", "carrying_weapon"); } }
        public static ScannerFile Armedwithasniperrifle { get { return new ScannerFile("01_carrying_weapon\\0x05F26EE0.mp3", "Armed with a sniper rifle.", "carrying_weapon"); } }
        public static ScannerFile Armedwithagat { get { return new ScannerFile("01_carrying_weapon\\0x062DE1F3.mp3", "Armed with a gat(?)", "carrying_weapon"); } }
        public static ScannerFile Armedwithasawedoffshotgun { get { return new ScannerFile("01_carrying_weapon\\0x07E4EAE1.mp3", "Armed with a sawed-off shotgun.", "carrying_weapon"); } }
        public static ScannerFile Carryinganassaultshotgun { get { return new ScannerFile("01_carrying_weapon\\0x0872CE5F.mp3", "Carrying an assault shotgun.", "carrying_weapon"); } }
        public static ScannerFile Carryinganassaultrifle { get { return new ScannerFile("01_carrying_weapon\\0x087FD323.mp3", "Carrying an assault rifle.", "carrying_weapon"); } }
        public static ScannerFile Carryinganexplosive { get { return new ScannerFile("01_carrying_weapon\\0x0B56F594.mp3", "Carrying an explosive.", "carrying_weapon"); } }
        public static ScannerFile Armedwithagrenadelauncher { get { return new ScannerFile("01_carrying_weapon\\0x0EDCED90.mp3", "Armed with a grenade launcher.", "carrying_weapon"); } }
        public static ScannerFile Armedwithaknife { get { return new ScannerFile("01_carrying_weapon\\0x100F1331.mp3", "Armed with a knife.", "carrying_weapon"); } }
        public static ScannerFile Armedwithafirearm { get { return new ScannerFile("01_carrying_weapon\\0x10B1C1E8.mp3", "Armed with a firearm.", "carrying_weapon"); } }
        public static ScannerFile Carryingashotgun { get { return new ScannerFile("01_carrying_weapon\\0x10DCD959.mp3", "Carrying a shotgun.", "carrying_weapon"); } }
        public static ScannerFile Armedwithanassaultshotgun { get { return new ScannerFile("01_carrying_weapon\\0x133223DD.mp3", "Armed with an assault shotgun.", "carrying_weapon"); } }
        public static ScannerFile Carryingasawedoffshotgun { get { return new ScannerFile("01_carrying_weapon\\0x15968645.mp3", "Carrying a sawed-off shotgun.", "carrying_weapon"); } }
        public static ScannerFile Armedwithabat { get { return new ScannerFile("01_carrying_weapon\\0x15EF5805.mp3", "Armed with a bat.", "carrying_weapon"); } }
        public static ScannerFile Carryingafirearm { get { return new ScannerFile("01_carrying_weapon\\0x164D0D1F.mp3", "Carrying a firearm.", "carrying_weapon"); } }
        public static ScannerFile Armedwithasubmachinegun { get { return new ScannerFile("01_carrying_weapon\\0x16BF89F9.mp3", "Armed with a sub machine gun.", "carrying_weapon"); } }
        public static ScannerFile Armedwithamachinegun { get { return new ScannerFile("01_carrying_weapon\\0x16E501E6.mp3", "Armed with a machine gun.", "carrying_weapon"); } }
        public static ScannerFile Carryingaweapon { get { return new ScannerFile("01_carrying_weapon\\0x174C66EE.mp3", "Carrying a weapon.", "carrying_weapon"); } }
        public static ScannerFile Carryingagun { get { return new ScannerFile("01_carrying_weapon\\0x191092A7.mp3", "Carrying a gun.", "carrying_weapon"); } }
        public static ScannerFile Armedwithanexplosive { get { return new ScannerFile("01_carrying_weapon\\0x1A8453EF.mp3", "Armed with an explosive.", "carrying_weapon"); } }
        public static ScannerFile Armedwithaminigun { get { return new ScannerFile("01_carrying_weapon\\0x1B175AFC.mp3", "Armed with a minigun.", "carrying_weapon"); } }
        public static ScannerFile Carryingagat { get { return new ScannerFile("01_carrying_weapon\\0x1B62CC5D.mp3", "Carrying a gat(?)", "carrying_weapon"); } }
        public static ScannerFile Carryingasubmachinegun { get { return new ScannerFile("01_carrying_weapon\\0x1B685349.mp3", "Carrying a sub machine gun.", "carrying_weapon"); } }
        public static ScannerFile Carryingamachinegun { get { return new ScannerFile("01_carrying_weapon\\0x1B950B8E.mp3", "Carrying a machine gun.", "carrying_weapon"); } }
        public static ScannerFile Armedwithashotgun { get { return new ScannerFile("01_carrying_weapon\\0x1D8FB2BF.mp3", "Armed with a shotgun.", "carrying_weapon"); } }
        public static ScannerFile CarryinganRPG { get { return new ScannerFile("01_carrying_weapon\\0x1F6F3AA8.mp3", "Carrying an RPG.", "carrying_weapon"); } }
    }

    public class car_code_composite 
    { 
        public static ScannerFile SevenEdwardSeven { get {return new ScannerFile("01_car_code_composite\\0x04ECD8ED.mp3","7-Edward-7","car_code_composite"); } }
        public static ScannerFile _1Adam13{ get { return new ScannerFile("01_car_code_composite\\0x04F7F7DD.mp3", "1-Adam-13", "car_code_composite"); } }
        public static ScannerFile _4Mary5{ get { return new ScannerFile("01_car_code_composite\\0x0741C430.mp3", "4-Mary-5", "car_code_composite"); } }
        public static ScannerFile _1David4 { get { return new ScannerFile("01_car_code_composite\\0x0749580E.mp3", "1-David-4", "car_code_composite"); } }
        public static ScannerFile _2Lincoln8{ get { return new ScannerFile("01_car_code_composite\\0x07911FB2.mp3", "2-Lincoln-8", "car_code_composite"); } }
        public static ScannerFile _2Edward6 { get { return new ScannerFile("01_car_code_composite\\0x08094919.mp3", "2-Edward-6", "car_code_composite"); } }
        public static ScannerFile _3Lincoln12 { get { return new ScannerFile("01_car_code_composite\\0x0CFFC800.mp3", "3-Lincoln-12", "car_code_composite"); } }
        public static ScannerFile _9David1 { get { return new ScannerFile("01_car_code_composite\\0x0E2B53BA.mp3", "9-David-1", "car_code_composite"); } }
        public static ScannerFile _8Lincoln5{ get { return new ScannerFile("01_car_code_composite\\0x12354C79.mp3", "8-Lincoln-5", "car_code_composite"); } }
        public static ScannerFile _3Lincoln2{ get { return new ScannerFile("01_car_code_composite\\0x1240ABC0.mp3", "3-Lincoln-2", "car_code_composite"); } }
        public static ScannerFile _6David6{ get { return new ScannerFile("01_car_code_composite\\0x15CA5EF5.mp3", "6-David-6", "car_code_composite"); } }
        public static ScannerFile _1Adam5 { get { return new ScannerFile("01_car_code_composite\\0x17DC4DCB.mp3", "1-Adam-5", "car_code_composite"); } }
        public static ScannerFile _8Mary7{ get { return new ScannerFile("01_car_code_composite\\0x19BDE3DC.mp3", "8-Mary-7", "car_code_composite"); } }
        public static ScannerFile _2Edward5{ get { return new ScannerFile("01_car_code_composite\\0x1A9F3B2C.mp3", "2-Edward-5", "car_code_composite"); } }
        public static ScannerFile _7Edward14{ get { return new ScannerFile("01_car_code_composite\\0x1CD2F553.mp3", "7-Edward-14", "car_code_composite"); } }
        public static ScannerFile _9Lincoln15{ get { return new ScannerFile("01_car_code_composite\\0x1F00095C.mp3", "9-Lincoln-15", "car_code_composite"); } }
    }


    public class car_code_division 
    { 
        public static ScannerFile _1 { get {return new ScannerFile("01_car_code_division\\0x06DF1221.mp3","1","car_code_division"); } }//Central
        public static ScannerFile _2 { get { return new ScannerFile("01_car_code_division\\0x10564158.mp3", "2", "car_code_division"); } }//Port Authority, Industrial
        public static ScannerFile _3 { get { return new ScannerFile("01_car_code_division\\0x1C908C63.mp3", "3", "car_code_division"); } }//Davis
        public static ScannerFile _4 { get { return new ScannerFile("01_car_code_division\\0x0EA506D5.mp3", "4", "car_code_division"); } }//Mirror Park
        public static ScannerFile _5 { get { return new ScannerFile("01_car_code_division\\0x1202F364.mp3", "5", "car_code_division"); } }//Metro
        public static ScannerFile _6 { get { return new ScannerFile("01_car_code_division\\0x146737ED.mp3", "6", "car_code_division"); } }//Vinewood
        public static ScannerFile _7 { get { return new ScannerFile("01_car_code_division\\0x141CAEE1.mp3", "7", "car_code_division"); } }//Vespucci
        public static ScannerFile _8 { get { return new ScannerFile("01_car_code_division\\0x0792F0F1.mp3", "8", "car_code_division"); } }
        public static ScannerFile _9 { get { return new ScannerFile("01_car_code_division\\0x071CEDC9.mp3", "9", "car_code_division"); } }
        public static ScannerFile _10 { get { return new ScannerFile("01_car_code_division\\0x15777950.mp3", "10", "car_code_division"); } }

    }
    public class car_code_unit_type
    {
        public static ScannerFile Adam { get { return new ScannerFile("01_car_code_unit_type\\0x019DB368.mp3", "Adam", "car_code_unit_type"); } }
        public static ScannerFile Charles { get { return new ScannerFile("01_car_code_unit_type\\0x01B6CB32.mp3", "Charles", "car_code_unit_type"); } }
        public static ScannerFile Ida { get { return new ScannerFile("01_car_code_unit_type\\0x028EAC65.mp3", "Ida", "car_code_unit_type"); } }
        public static ScannerFile Queen { get { return new ScannerFile("01_car_code_unit_type\\0x0312DE16.mp3", "Queen", "car_code_unit_type"); } }
        public static ScannerFile Sam { get { return new ScannerFile("01_car_code_unit_type\\0x06A12117.mp3", "Sam", "car_code_unit_type"); } }
        public static ScannerFile David { get { return new ScannerFile("01_car_code_unit_type\\0x06D04A5D.mp3", "David", "car_code_unit_type"); } }
        public static ScannerFile Ocean { get { return new ScannerFile("01_car_code_unit_type\\0x07AD2CCF.mp3", "Ocean", "car_code_unit_type"); } }
        public static ScannerFile Young { get { return new ScannerFile("01_car_code_unit_type\\0x095B6C31.mp3", "Young", "car_code_unit_type"); } }
        public static ScannerFile Lincoln { get { return new ScannerFile("01_car_code_unit_type\\0x0978B52D.mp3", "Lincoln", "car_code_unit_type"); } }
        public static ScannerFile Tom { get { return new ScannerFile("01_car_code_unit_type\\0x0D320902.mp3", "Tom", "car_code_unit_type"); } }
        public static ScannerFile Zebra { get { return new ScannerFile("01_car_code_unit_type\\0x0DD6DFB0.mp3", "Zebra", "car_code_unit_type"); } }
        public static ScannerFile Union { get { return new ScannerFile("01_car_code_unit_type\\0x0F9D1299.mp3", "Union", "car_code_unit_type"); } }
        public static ScannerFile King { get { return new ScannerFile("01_car_code_unit_type\\0x0FA51727.mp3", "King", "car_code_unit_type"); } }
        public static ScannerFile Mary { get { return new ScannerFile("01_car_code_unit_type\\0x106EEE1F.mp3", "Mary", "car_code_unit_type"); } }
        public static ScannerFile Paul { get { return new ScannerFile("01_car_code_unit_type\\0x1148453E.mp3", "Paul", "car_code_unit_type"); } }
        public static ScannerFile Edward { get { return new ScannerFile("01_car_code_unit_type\\0x1507C292.mp3", "Edward", "car_code_unit_type"); } }
        public static ScannerFile George { get { return new ScannerFile("01_car_code_unit_type\\0x155E5D66.mp3", "George", "car_code_unit_type"); } }
        public static ScannerFile Robert { get { return new ScannerFile("01_car_code_unit_type\\0x17FE0862.mp3", "Robert", "car_code_unit_type"); } }
        public static ScannerFile Henry { get { return new ScannerFile("01_car_code_unit_type\\0x1859236F.mp3", "Henry", "car_code_unit_type"); } }
        public static ScannerFile Boy { get { return new ScannerFile("01_car_code_unit_type\\0x192087BE.mp3", "Boy", "car_code_unit_type"); } }
        public static ScannerFile John { get { return new ScannerFile("01_car_code_unit_type\\0x1C48EEC3.mp3", "John", "car_code_unit_type"); } }
        public static ScannerFile XRay { get { return new ScannerFile("01_car_code_unit_type\\0x1C9CE941.mp3", "X-Ray", "car_code_unit_type"); } }
        public static ScannerFile Nora { get { return new ScannerFile("01_car_code_unit_type\\0x1D0F2801.mp3", "Nora", "car_code_unit_type"); } }
        public static ScannerFile William { get { return new ScannerFile("01_car_code_unit_type\\0x1ED2ABFD.mp3", "William", "car_code_unit_type"); } }
        public static ScannerFile Frank { get { return new ScannerFile("01_car_code_unit_type\\0x1FA95EBC.mp3", "Frank", "car_code_unit_type"); } }
        public static ScannerFile Victor { get { return new ScannerFile("01_car_code_unit_type\\0x1FE2D860.mp3", "Victor", "car_code_unit_type"); } }
    }

    public class car_code_beat
    {
        public static ScannerFile one { get { return new ScannerFile("01_car_code_beat\\0x1361FCAE.mp3", "1", "car_code_beat"); } }
        public static ScannerFile two { get { return new ScannerFile("01_car_code_beat\\0x1049F2F3.mp3", "2", "car_code_beat"); } }
        public static ScannerFile three { get { return new ScannerFile("01_car_code_beat\\0x0E57C6EE.mp3", "3", "car_code_beat"); } }
        public static ScannerFile four { get { return new ScannerFile("01_car_code_beat\\0x05AFDDFC.mp3", "4", "car_code_beat"); } }
        public static ScannerFile five { get { return new ScannerFile("01_car_code_beat\\0x0A17C498.mp3", "5", "car_code_beat"); } }
        public static ScannerFile six { get { return new ScannerFile("01_car_code_beat\\0x048DB95D.mp3", "6", "car_code_beat"); } }
        public static ScannerFile seven { get { return new ScannerFile("01_car_code_beat\\0x045F6810.mp3", "7", "car_code_beat"); } }
        public static ScannerFile eight { get { return new ScannerFile("01_car_code_beat\\0x0D675D57.mp3", "8", "car_code_beat"); } }
        public static ScannerFile nine { get { return new ScannerFile("01_car_code_beat\\0x14488E9C.mp3", "9", "car_code_beat"); } }
        public static ScannerFile ten { get { return new ScannerFile("01_car_code_beat\\0x131E6122.mp3", "10", "car_code_beat"); } }
        public static ScannerFile eleven { get { return new ScannerFile("01_car_code_beat\\0x0D88503E.mp3", "11", "car_code_beat"); } }
        public static ScannerFile twelve { get { return new ScannerFile("01_car_code_beat\\0x1D7566AD.mp3", "12", "car_code_beat"); } }
        public static ScannerFile thirteen { get { return new ScannerFile("01_car_code_beat\\0x056934B0.mp3", "13", "car_code_beat"); } }
        public static ScannerFile fourteen { get { return new ScannerFile("01_car_code_beat\\0x15E37467.mp3", "14", "car_code_beat"); } }
        public static ScannerFile fifteen { get { return new ScannerFile("01_car_code_beat\\0x0DCE9405.mp3", "15", "car_code_beat"); } }
        public static ScannerFile sixteen { get { return new ScannerFile("01_car_code_beat\\0x0E40B65E.mp3", "16", "car_code_beat"); } }
        public static ScannerFile seventeen { get { return new ScannerFile("01_car_code_beat\\0x08632482.mp3", "17", "car_code_beat"); } }
        public static ScannerFile eighteen { get { return new ScannerFile("01_car_code_beat\\0x1CC8A958.mp3", "18", "car_code_beat"); } }
        public static ScannerFile nineteen { get { return new ScannerFile("01_car_code_beat\\0x12850991.mp3", "19", "car_code_beat"); } }
        public static ScannerFile twenty { get { return new ScannerFile("01_car_code_beat\\0x04114DC3.mp3", "20", "car_code_beat"); } }
        public static ScannerFile twentyone { get { return new ScannerFile("01_car_code_beat\\0x0AC0CD3B.mp3", "21", "car_code_beat"); } }
        public static ScannerFile twentytwo { get { return new ScannerFile("01_car_code_beat\\0x070401AA.mp3", "22", "car_code_beat"); } }
        public static ScannerFile twentythree { get { return new ScannerFile("01_car_code_beat\\0x13F6EC22.mp3", "23", "car_code_beat"); } }
        public static ScannerFile twentyfour { get { return new ScannerFile("01_car_code_beat\\0x1E112D7D.mp3", "24", "car_code_beat"); } }
    }


    //public class clothing_item_outfit
    //{
    //    public static ScannerFile Afirefightersuniform { get { return new ScannerFile("01_clothing_item_outfit\\0x05FCA5E3.mp3", "A firefighter's uniform", "clothing_item_outfit"); } }
    //    public static ScannerFile Awetsuit { get { return new ScannerFile("01_clothing_item_outfit\\0x07F171A5.mp3", "A wet suit", "clothing_item_outfit"); } }
    //    public static ScannerFile Atracksuit { get { return new ScannerFile("01_clothing_item_outfit\\0x088DE65C.mp3", "A track suit", "clothing_item_outfit"); } }
    //    public static ScannerFile Firefightingattire { get { return new ScannerFile("01_clothing_item_outfit\\0x13964116.mp3", "Firefighting attire", "clothing_item_outfit"); } }
    //    public static ScannerFile Ajanitorsuniform { get { return new ScannerFile("01_clothing_item_outfit\\0x17D713A7.mp3", "A janitor's uniform", "clothing_item_outfit"); } }
    //    public static ScannerFile Apoliceofficersuniform { get { return new ScannerFile("01_clothing_item_outfit\\0x1A275FE2.mp3", "A police officer's uniform", "clothing_item_outfit"); } }
    //    public static ScannerFile Agasmask { get { return new ScannerFile("01_clothing_item_outfit\\0x1AE21C68.mp3", "A gas mask", "clothing_item_outfit"); } }
    //    public static ScannerFile Adarkgraysuit { get { return new ScannerFile("01_clothing_item_outfit\\0x1C215456.mp3", "A dark gray suit", "clothing_item_outfit"); } }
    //}
    //public class clothing_item_pants
    //{
    //    public static ScannerFile Brookjeans { get { return new ScannerFile("01_clothing_item_pants\\0x0124C899.mp3", "Brook(?) jeans", "clothing_item_pants"); } }
    //    public static ScannerFile Lightpants { get { return new ScannerFile("01_clothing_item_pants\\0x07DAA810.mp3", "Light pants", "clothing_item_pants"); } }
    //    public static ScannerFile Darkpants { get { return new ScannerFile("01_clothing_item_pants\\0x09FF1A21.mp3", "Dark pants", "clothing_item_pants"); } }
    //    public static ScannerFile Bluejeans { get { return new ScannerFile("01_clothing_item_pants\\0x0CEA5160.mp3", "Blue jeans", "clothing_item_pants"); } }
    //    public static ScannerFile Lightshorts { get { return new ScannerFile("01_clothing_item_pants\\0x12A4D46F.mp3", "Light shorts", "clothing_item_pants"); } }
    //    public static ScannerFile Blackjeans { get { return new ScannerFile("01_clothing_item_pants\\0x15D1CBC3.mp3", "Black jeans", "clothing_item_pants"); } }
    //    public static ScannerFile Cargopants { get { return new ScannerFile("01_clothing_item_pants\\0x1761F58C.mp3", "Cargo pants", "clothing_item_pants"); } }
    //    public static ScannerFile Darkshorts { get { return new ScannerFile("01_clothing_item_pants\\0x186A9052.mp3", "Dark shorts", "clothing_item_pants"); } }
    //}
    //public class clothing_item_shoes
    //{
    //    public static ScannerFile Lightsneakers { get { return new ScannerFile("01_clothing_item_shoes\\0x04DF1D1B.mp3", "Light sneakers", "clothing_item_shoes"); } }
    //    public static ScannerFile Blackboots { get { return new ScannerFile("01_clothing_item_shoes\\0x0D8BF112.mp3", "Black boots", "clothing_item_shoes"); } }
    //    public static ScannerFile Darksneakers { get { return new ScannerFile("01_clothing_item_shoes\\0x1222B07E.mp3", "Dark sneakers", "clothing_item_shoes"); } }
    //    public static ScannerFile Brownboots { get { return new ScannerFile("01_clothing_item_shoes\\0x18770478.mp3", "Brown boots", "clothing_item_shoes"); } }
    //    public static ScannerFile Brownshoes { get { return new ScannerFile("01_clothing_item_shoes\\0x1C00A135.mp3", "Brown shoes", "clothing_item_shoes"); } }
    //    public static ScannerFile Blackshoes { get { return new ScannerFile("01_clothing_item_shoes\\0x1DF3345A.mp3", "Black shoes", "clothing_item_shoes"); } }
    //}
    //public class clothing_item_torso
    //{
    //    public static ScannerFile Shortsleeveshirt { get { return new ScannerFile("01_clothing_item_torso\\0x021EEEAF.mp3", "Short sleeve shirt", "clothing_item_torso"); } }
    //    public static ScannerFile Suitjacket { get { return new ScannerFile("01_clothing_item_torso\\0x02BEDD9F.mp3", "Suit jacket", "clothing_item_torso"); } }
    //    public static ScannerFile Leatherjacket { get { return new ScannerFile("01_clothing_item_torso\\0x03FB29CC.mp3", "Leather jacket", "clothing_item_torso"); } }
    //    public static ScannerFile Darkjacket { get { return new ScannerFile("01_clothing_item_torso\\0x04E5C73E.mp3", "Dark jacket", "clothing_item_torso"); } }
    //    public static ScannerFile Blueshirt { get { return new ScannerFile("01_clothing_item_torso\\0x06CA50C1.mp3", "Blue shirt", "clothing_item_torso"); } }
    //    public static ScannerFile Darkshirt { get { return new ScannerFile("01_clothing_item_torso\\0x0724F7EF.mp3", "Dark shirt", "clothing_item_torso"); } }
    //    public static ScannerFile Denimjacket { get { return new ScannerFile("01_clothing_item_torso\\0x0C7CEAEE.mp3", "Denim jacket", "clothing_item_torso"); } }
    //    public static ScannerFile Noshirt { get { return new ScannerFile("01_clothing_item_torso\\0x0CE3051C.mp3", "No shirt", "clothing_item_torso"); } }
    //    public static ScannerFile Greenshirt { get { return new ScannerFile("01_clothing_item_torso\\0x0D4A8107.mp3", "Green shirt", "clothing_item_torso"); } }
    //    public static ScannerFile Longsleeveshirt { get { return new ScannerFile("01_clothing_item_torso\\0x0DF91657.mp3", "Long sleeve shirt", "clothing_item_torso"); } }
    //    public static ScannerFile Redshirt { get { return new ScannerFile("01_clothing_item_torso\\0x107319A5.mp3", "Red shirt", "clothing_item_torso"); } }
    //    public static ScannerFile Lightshirt { get { return new ScannerFile("01_clothing_item_torso\\0x1707806C.mp3", "Light shirt", "clothing_item_torso"); } }
    //    public static ScannerFile Lightjacket { get { return new ScannerFile("01_clothing_item_torso\\0x1D00E5A1.mp3", "Light jacket", "clothing_item_torso"); } }
    //}
    public class colour
    {
        public static ScannerFile COLORAQUA01 { get { return new ScannerFile("01_colour\\COLOR_AQUA_01.mp3", "COLOR_AQUA_01", "colour"); } }
        public static ScannerFile COLORBEIGE01 { get { return new ScannerFile("01_colour\\COLOR_BEIGE_01.mp3", "COLOR_BEIGE_01", "colour"); } }
        public static ScannerFile COLORBLACK01 { get { return new ScannerFile("01_colour\\COLOR_BLACK_01.mp3", "COLOR_BLACK_01", "colour"); } }
        public static ScannerFile COLORBLUE01 { get { return new ScannerFile("01_colour\\COLOR_BLUE_01.mp3", "COLOR_BLUE_01", "colour"); } }
        public static ScannerFile COLORBRONZE01 { get { return new ScannerFile("01_colour\\COLOR_BRONZE_01.mp3", "COLOR_BRONZE_01", "colour"); } }
        public static ScannerFile COLORBROWN01 { get { return new ScannerFile("01_colour\\COLOR_BROWN_01.mp3", "COLOR_BROWN_01", "colour"); } }
        public static ScannerFile COLORDARKBLUE01 { get { return new ScannerFile("01_colour\\COLOR_DARK_BLUE_01.mp3", "COLOR_DARK_BLUE_01", "colour"); } }
        public static ScannerFile COLORDARKBROWN01 { get { return new ScannerFile("01_colour\\COLOR_DARK_BROWN_01.mp3", "COLOR_DARK_BROWN_01", "colour"); } }
        public static ScannerFile COLORDARKGREEN01 { get { return new ScannerFile("01_colour\\COLOR_DARK_GREEN_01.mp3", "COLOR_DARK_GREEN_01", "colour"); } }
        public static ScannerFile COLORDARKGREY01 { get { return new ScannerFile("01_colour\\COLOR_DARK_GREY_01.mp3", "COLOR_DARK_GREY_01", "colour"); } }
        public static ScannerFile COLORDARKMAROON01 { get { return new ScannerFile("01_colour\\COLOR_DARK_MAROON_01.mp3", "COLOR_DARK_MAROON_01", "colour"); } }
        public static ScannerFile COLORDARKORANGE01 { get { return new ScannerFile("01_colour\\COLOR_DARK_ORANGE_01.mp3", "COLOR_DARK_ORANGE_01", "colour"); } }
        public static ScannerFile COLORDARKPURPLE01 { get { return new ScannerFile("01_colour\\COLOR_DARK_PURPLE_01.mp3", "COLOR_DARK_PURPLE_01", "colour"); } }
        public static ScannerFile COLORDARKRED01 { get { return new ScannerFile("01_colour\\COLOR_DARK_RED_01.mp3", "COLOR_DARK_RED_01", "colour"); } }
        public static ScannerFile COLORDARKSILVER01 { get { return new ScannerFile("01_colour\\COLOR_DARK_SILVER_01.mp3", "COLOR_DARK_SILVER_01", "colour"); } }
        public static ScannerFile COLORDARKYELLOW01 { get { return new ScannerFile("01_colour\\COLOR_DARK_YELLOW_01.mp3", "COLOR_DARK_YELLOW_01", "colour"); } }
        public static ScannerFile COLORGOLD01 { get { return new ScannerFile("01_colour\\COLOR_GOLD_01.mp3", "COLOR_GOLD_01", "colour"); } }
        public static ScannerFile COLORGRAPHITE01 { get { return new ScannerFile("01_colour\\COLOR_GRAPHITE_01.mp3", "COLOR_GRAPHITE_01", "colour"); } }
        public static ScannerFile COLORGREEN01 { get { return new ScannerFile("01_colour\\COLOR_GREEN_01.mp3", "COLOR_GREEN_01", "colour"); } }
        public static ScannerFile COLORGREY01 { get { return new ScannerFile("01_colour\\COLOR_GREY_01.mp3", "COLOR_GREY_01", "colour"); } }
        public static ScannerFile COLORGREY02 { get { return new ScannerFile("01_colour\\COLOR_GREY_02.mp3", "COLOR_GREY_02", "colour"); } }
        public static ScannerFile COLORLIGHTBLUE01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_BLUE_01.mp3", "COLOR_LIGHT_BLUE_01", "colour"); } }
        public static ScannerFile COLORLIGHTBROWN01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_BROWN_01.mp3", "COLOR_LIGHT_BROWN_01", "colour"); } }
        public static ScannerFile COLORLIGHTGREEN01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_GREEN_01.mp3", "COLOR_LIGHT_GREEN_01", "colour"); } }
        public static ScannerFile COLORLIGHTGREY01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_GREY_01.mp3", "COLOR_LIGHT_GREY_01", "colour"); } }
        public static ScannerFile COLORLIGHTMAROON01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_MAROON_01.mp3", "COLOR_LIGHT_MAROON_01", "colour"); } }
        public static ScannerFile COLORLIGHTORANGE01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_ORANGE_01.mp3", "COLOR_LIGHT_ORANGE_01", "colour"); } }
        public static ScannerFile COLORLIGHTPURPLE01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_PURPLE_01.mp3", "COLOR_LIGHT_PURPLE_01", "colour"); } }
        public static ScannerFile COLORLIGHTRED01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_RED_01.mp3", "COLOR_LIGHT_RED_01", "colour"); } }
        public static ScannerFile COLORLIGHTSILVER01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_SILVER_01.mp3", "COLOR_LIGHT_SILVER_01", "colour"); } }
        public static ScannerFile COLORLIGHTYELLOW01 { get { return new ScannerFile("01_colour\\COLOR_LIGHT_YELLOW_01.mp3", "COLOR_LIGHT_YELLOW_01", "colour"); } }
        public static ScannerFile COLORMAROON01 { get { return new ScannerFile("01_colour\\COLOR_MAROON_01.mp3", "COLOR_MAROON_01", "colour"); } }
        public static ScannerFile COLORMETALLICBLACK01 { get { return new ScannerFile("01_colour\\COLOR_METALLIC_BLACK_01.mp3", "COLOR_METALLIC_BLACK_01", "colour"); } }
        public static ScannerFile COLORMETALLICBLUE01 { get { return new ScannerFile("01_colour\\COLOR_METALLIC_BLUE_01.mp3", "COLOR_METALLIC_BLUE_01", "colour"); } }
        public static ScannerFile COLORMETALLICBROWN01 { get { return new ScannerFile("01_colour\\COLOR_METALLIC_BROWN_01.mp3", "COLOR_METALLIC_BROWN_01", "colour"); } }
        public static ScannerFile COLORMETALLICGREEN01 { get { return new ScannerFile("01_colour\\COLOR_METALLIC_GREEN_01.mp3", "COLOR_METALLIC_GREEN_01", "colour"); } }
        public static ScannerFile COLORMETALLICGREY01 { get { return new ScannerFile("01_colour\\COLOR_METALLIC_GREY_01.mp3", "COLOR_METALLIC_GREY_01", "colour"); } }
        public static ScannerFile COLORMETALLICPURPLE01 { get { return new ScannerFile("01_colour\\COLOR_METALLIC_PURPLE_01.mp3", "COLOR_METALLIC_PURPLE_01", "colour"); } }
        public static ScannerFile COLORMETALLICRED01 { get { return new ScannerFile("01_colour\\COLOR_METALLIC_RED_01.mp3", "COLOR_METALLIC_RED_01", "colour"); } }
        public static ScannerFile COLORMETALLICSILVER01 { get { return new ScannerFile("01_colour\\COLOR_METALLIC_SILVER_01.mp3", "COLOR_METALLIC_SILVER_01", "colour"); } }
        public static ScannerFile COLORMETALLICYELLOW01 { get { return new ScannerFile("01_colour\\COLOR_METALLIC_YELLOW_01.mp3", "COLOR_METALLIC_YELLOW_01", "colour"); } }
        public static ScannerFile COLORORANGE01 { get { return new ScannerFile("01_colour\\COLOR_ORANGE_01.mp3", "COLOR_ORANGE_01", "colour"); } }
        public static ScannerFile COLORPINK01 { get { return new ScannerFile("01_colour\\COLOR_PINK_01.mp3", "COLOR_PINK_01", "colour"); } }
        public static ScannerFile COLORPURPLE01 { get { return new ScannerFile("01_colour\\COLOR_PURPLE_01.mp3", "COLOR_PURPLE_01", "colour"); } }
        public static ScannerFile COLORRED01 { get { return new ScannerFile("01_colour\\COLOR_RED_01.mp3", "COLOR_RED_01", "colour"); } }
        public static ScannerFile COLORSILVER01 { get { return new ScannerFile("01_colour\\COLOR_SILVER_01.mp3", "COLOR_SILVER_01", "colour"); } }
        public static ScannerFile COLORWHITE01 { get { return new ScannerFile("01_colour\\COLOR_WHITE_01.mp3", "COLOR_WHITE_01", "colour"); } }
        public static ScannerFile COLORYELLOW01 { get { return new ScannerFile("01_colour\\COLOR_YELLOW_01.mp3", "COLOR_YELLOW_01", "colour"); } }
    }
    public class conjunctives
    {
        public static ScannerFile Onuh { get { return new ScannerFile("01_conjunctives\\0x011A8195.mp3", "On, uh...", "conjunctives"); } }
        public static ScannerFile In { get { return new ScannerFile("01_conjunctives\\0x03D81B43.mp3", "In...", "conjunctives"); } }
        public static ScannerFile after { get { return new ScannerFile("01_conjunctives\\0x04E066E1.mp3", "after(?)", "conjunctives"); } }
        public static ScannerFile In_1 { get { return new ScannerFile("01_conjunctives\\0x0504FCB6.mp3", "In...", "conjunctives"); } }
        public static ScannerFile In_2 { get { return new ScannerFile("01_conjunctives\\0x05F99F84.mp3", "In...", "conjunctives"); } }
        public static ScannerFile Over { get { return new ScannerFile("01_conjunctives\\0x0919B635.mp3", "Over...", "conjunctives"); } }
        public static ScannerFile Closetoum { get { return new ScannerFile("01_conjunctives\\0x0AF7ACDC.mp3", "Close to, um...", "conjunctives"); } }
        public static ScannerFile PossiblyAttheneedsconfirmation { get { return new ScannerFile("01_conjunctives\\0x0B53F3CF.mp3", "(Possibly At the, needs confirmation)", "conjunctives"); } }
        public static ScannerFile Insideuhh { get { return new ScannerFile("01_conjunctives\\0x0EC92FF6.mp3", "Inside, uhh...", "conjunctives"); } }
        public static ScannerFile Closetouhh { get { return new ScannerFile("01_conjunctives\\0x1037F75C.mp3", "Close to, uhh...", "conjunctives"); } }
        public static ScannerFile Unknownrequiresfurtherobservation { get { return new ScannerFile("01_conjunctives\\0x11263F74.mp3", "(Unknown, requires further observation)", "conjunctives"); } }
        public static ScannerFile Onauhh { get { return new ScannerFile("01_conjunctives\\0x12CF24FE.mp3", "On a, uhh...", "conjunctives"); } }
        public static ScannerFile PossiblyAttheneedsconfirmation1 { get { return new ScannerFile("01_conjunctives\\0x12E8C2F2.mp3", "(Possibly At the, needs confirmation)", "conjunctives"); } }
        public static ScannerFile Drivinga { get { return new ScannerFile("01_conjunctives\\0x14C128D7.mp3", "Driving a...", "conjunctives"); } }
        public static ScannerFile PossiblyAttheneedsconfirmation2 { get { return new ScannerFile("01_conjunctives\\0x17220B65.mp3", "(Possibly At the, needs confirmation)", "conjunctives"); } }
        public static ScannerFile After { get { return new ScannerFile("01_conjunctives\\0x17EF8D06.mp3", "After(?)", "conjunctives"); } }
        public static ScannerFile Nearumm { get { return new ScannerFile("01_conjunctives\\0x18AA0841.mp3", "Near, umm...", "conjunctives"); } }
        public static ScannerFile PossiblyAttheneedsconfirmation3 { get { return new ScannerFile("01_conjunctives\\0x19BE50A4.mp3", "(Possibly At the, needs confirmation)", "conjunctives"); } }
        public static ScannerFile DrivingAUmmm { get { return new ScannerFile("01_conjunctives\\0x1AF7F545.mp3", "Driving on... (combination of uhh and possibly a yawn)", "conjunctives"); } }
        public static ScannerFile Inside { get { return new ScannerFile("01_conjunctives\\0x1C248AAD.mp3", "Inside...", "conjunctives"); } }
        public static ScannerFile PossiblyAttheneedsconfirmation4 { get { return new ScannerFile("01_conjunctives\\0x1D19175A.mp3", "(Possibly At the, needs confirmation)", "conjunctives"); } }
        public static ScannerFile Over1 { get { return new ScannerFile("01_conjunctives\\0x1DC1DFC1.mp3", "Over...", "conjunctives"); } }
        public static ScannerFile Insideuhh1 { get { return new ScannerFile("01_conjunctives\\0x1F065070.mp3", "Inside, uhh...", "conjunctives"); } }
        public static ScannerFile AT01 { get { return new ScannerFile("01_conjunctives\\AT_01.mp3", "AT_01", "conjunctives"); } }
        public static ScannerFile AT02 { get { return new ScannerFile("01_conjunctives\\AT_02.mp3", "AT_02", "conjunctives"); } }
        public static ScannerFile A01 { get { return new ScannerFile("01_conjunctives\\A_01.mp3", "A_01", "conjunctives"); } }
        public static ScannerFile A02 { get { return new ScannerFile("01_conjunctives\\A_02.mp3", "A_02", "conjunctives"); } }
        public static ScannerFile FAN2BJAD01 { get { return new ScannerFile("01_conjunctives\\FAN2_BJAD_01.mp3", "FAN2_BJAD_01", "conjunctives"); } }
        public static ScannerFile Inuhh { get { return new ScannerFile("01_conjunctives\\IN_01.mp3", "In, uhh...", "conjunctives"); } }
        public static ScannerFile Inuhh2 { get { return new ScannerFile("01_conjunctives\\IN_02.mp3", "In...", "conjunctives"); } }
        public static ScannerFile Inuhh3 { get { return new ScannerFile("01_conjunctives\\IN_03.mp3", "IN_03", "conjunctives"); } }
        public static ScannerFile INA01 { get { return new ScannerFile("01_conjunctives\\IN_A_01.mp3", "IN_A_01", "conjunctives"); } }
        public static ScannerFile INA02 { get { return new ScannerFile("01_conjunctives\\IN_A_02.mp3", "IN_A_02", "conjunctives"); } }
        public static ScannerFile INA03 { get { return new ScannerFile("01_conjunctives\\IN_A_03.mp3", "IN_A_03", "conjunctives"); } }
        public static ScannerFile Onumm { get { return new ScannerFile("01_conjunctives\\ON_01.mp3", "On, umm...", "conjunctives"); } }
        public static ScannerFile Onuhh { get { return new ScannerFile("01_conjunctives\\ON_02.mp3", "On, uhh...", "conjunctives"); } }
        public static ScannerFile On { get { return new ScannerFile("01_conjunctives\\ON_03.mp3", "On...", "conjunctives"); } }
        public static ScannerFile On1 { get { return new ScannerFile("01_conjunctives\\ON_04.mp3", "On...", "conjunctives"); } }
        public static ScannerFile On2 { get { return new ScannerFile("01_conjunctives\\ON_05.mp3", "On...", "conjunctives"); } }
        public static ScannerFile On3 { get { return new ScannerFile("01_conjunctives\\ON_06.mp3", "On", "conjunctives"); } }
        public static ScannerFile On4 { get { return new ScannerFile("01_conjunctives\\ON_07.mp3", "On", "conjunctives"); } }
        public static ScannerFile OVER01 { get { return new ScannerFile("01_conjunctives\\OVER_01.mp3", "OVER_01", "conjunctives"); } }
    }
    //public class crime_10_24
    //{
    //    public static ScannerFile Astationemergency { get { return new ScannerFile("01_crime_10_24\\0x026A3806.mp3", "A station emergency.", "crime_10_24"); } }
    //    public static ScannerFile A1024 { get { return new ScannerFile("01_crime_10_24\\0x10A0D480.mp3", "A 10-24.", "crime_10_24"); } }
    //    public static ScannerFile Astationemergency1 { get { return new ScannerFile("01_crime_10_24\\0x14A19C80.mp3", "A station emergency.", "crime_10_24"); } }
    //    public static ScannerFile A10241 { get { return new ScannerFile("01_crime_10_24\\0x15BC9EAB.mp3", "A 10-24.", "crime_10_24"); } }
    //}
    //public class crime_10_351
    //{
    //    public static ScannerFile Possessionofdrugsforsale { get { return new ScannerFile("01_crime_10_351\\0x0E4C71EB.mp3", "Possession of drugs for sale.", "crime_10_351"); } }
    //    public static ScannerFile Apossessionofdrugsforsaleincident { get { return new ScannerFile("01_crime_10_351\\0x17A244B2.mp3", "A possession of drugs for sale incident.", "crime_10_351"); } }
    //    public static ScannerFile Possessionofdrugsforsale1 { get { return new ScannerFile("01_crime_10_351\\0x1E95927E.mp3", "Possession of drugs for sale.", "crime_10_351"); } }
    //}
    //public class crime_10_851
    //{
    //    public static ScannerFile A10851 { get { return new ScannerFile("01_crime_10_851\\0x013CC71E.mp3", "A 10-851.", "crime_10_851"); } }
    //    public static ScannerFile A108511 { get { return new ScannerFile("01_crime_10_851\\0x05258EF1.mp3", "A 10-851.", "crime_10_851"); } }
    //    public static ScannerFile Astolenvehicle { get { return new ScannerFile("01_crime_10_851\\0x0E03A0AD.mp3", "A stolen vehicle.", "crime_10_851"); } }
    //    public static ScannerFile Astolenvehicle1 { get { return new ScannerFile("01_crime_10_851\\0x12D86A56.mp3", "A stolen vehicle.", "crime_10_851"); } }
    //}
    //public class crime_10_99
    //{
    //    public static ScannerFile Anofficerrequiresimmediateassistance { get { return new ScannerFile("01_crime_10_99\\0x029C50BE.mp3", "An officer requires immediate assistance.", "crime_10_99"); } }
    //    public static ScannerFile Acode99 { get { return new ScannerFile("01_crime_10_99\\0x02A890D4.mp3", "A code 99.", "crime_10_99"); } }
    //    public static ScannerFile A1099 { get { return new ScannerFile("01_crime_10_99\\0x108A6C97.mp3", "A 10-99.", "crime_10_99"); } }
    //    public static ScannerFile Anofficerrequiresimmediatehelp { get { return new ScannerFile("01_crime_10_99\\0x149B34B9.mp3", "An officer requires immediate help.", "crime_10_99"); } }
    ////}
    //public class crime_11_351
    //{
    //    public static ScannerFile An11351 { get { return new ScannerFile("01_crime_11_351\\0x0654770E.mp3", "An 11-351.", "crime_11_351"); } }
    //    public static ScannerFile An113511 { get { return new ScannerFile("01_crime_11_351\\0x0B6E4141.mp3", "An 11-351.", "crime_11_351"); } }
    //    public static ScannerFile Apossessionofdrugsforsaleincident { get { return new ScannerFile("01_crime_11_351\\0x10140A8E.mp3", "A possession of drugs for sale incident.", "crime_11_351"); } }
    //}
    public class crime_11_357
    {
        public static ScannerFile Adrugpossessionincident { get { return new ScannerFile("01_crime_11_357\\0x0403DE60.mp3", "A drug possession incident.", "crime_11_357"); } }
        public static ScannerFile An11357 { get { return new ScannerFile("01_crime_11_357\\0x086B6730.mp3", "An 11-357.", "crime_11_357"); } }
        public static ScannerFile An113571 { get { return new ScannerFile("01_crime_11_357\\0x0C0EAE77.mp3", "An 11-357.", "crime_11_357"); } }
        public static ScannerFile An113571_1 { get { return new ScannerFile("01_crime_11_357\\0x1502C05F.mp3", "An 11-357.", "crime_11_357"); } }
        public static ScannerFile Adrugpossessionincident1 { get { return new ScannerFile("01_crime_11_357\\0x1A250AA4.mp3", "A drug possession incident.", "crime_11_357"); } }
    }
    public class crime_1_48_resist_arrest
    {
        public static ScannerFile Acriminalresistingarrest { get { return new ScannerFile("01_crime_1_48_resist_arrest\\0x0419C880.mp3", "A criminal resisting arrest.", "crime_1_48_resist_arrest"); } }
        public static ScannerFile A148 { get { return new ScannerFile("01_crime_1_48_resist_arrest\\0x08149075.mp3", "A 148.", "crime_1_48_resist_arrest"); } }
        public static ScannerFile Asuspectontherun { get { return new ScannerFile("01_crime_1_48_resist_arrest\\0x0EA15D8E.mp3", "A suspect on the run.", "crime_1_48_resist_arrest"); } }
        public static ScannerFile Apossible148 { get { return new ScannerFile("01_crime_1_48_resist_arrest\\0x131E2687.mp3", "A...possible 148.", "crime_1_48_resist_arrest"); } }
        public static ScannerFile Apossible1481 { get { return new ScannerFile("01_crime_1_48_resist_arrest\\0x16142C75.mp3", "A possible 148.", "crime_1_48_resist_arrest"); } }
        public static ScannerFile Acriminalresistingarrest1 { get { return new ScannerFile("01_crime_1_48_resist_arrest\\0x180F306A.mp3", "A criminal resisting arrest.", "crime_1_48_resist_arrest"); } }
        public static ScannerFile Asuspectfleeingacrimescene { get { return new ScannerFile("01_crime_1_48_resist_arrest\\0x1A29F4A0.mp3", "A suspect fleeing a crime scene.", "crime_1_48_resist_arrest"); } }
        public static ScannerFile A1481 { get { return new ScannerFile("01_crime_1_48_resist_arrest\\0x1B41BE61.mp3", "A...148", "crime_1_48_resist_arrest"); } }
    }
    public class crime_1_87
    {
        public static ScannerFile A187 { get { return new ScannerFile("01_crime_1_87\\0x0CB0FAB6.mp3", "A 187.", "crime_1_87"); } }
        public static ScannerFile Ahomicide { get { return new ScannerFile("01_crime_1_87\\0x133307C2.mp3", "A homicide.", "crime_1_87"); } }
    }
    public class crime_2_07
    {
        public static ScannerFile Akidnapping { get { return new ScannerFile("01_crime_2_07\\0x0AA06B74.mp3", "A kidnapping.", "crime_2_07"); } }
        public static ScannerFile A207 { get { return new ScannerFile("01_crime_2_07\\0x14D87FE1.mp3", "A 207.", "crime_2_07"); } }
        public static ScannerFile A2071 { get { return new ScannerFile("01_crime_2_07\\0x184786C0.mp3", "A 207.", "crime_2_07"); } }
        public static ScannerFile Akidnapping1 { get { return new ScannerFile("01_crime_2_07\\0x1C284E82.mp3", "A kidnapping.", "crime_2_07"); } }
    }
    public class crime_2_11
    {
        public static ScannerFile Anarmedrobbery { get { return new ScannerFile("01_crime_2_11\\0x07B6402C.mp3", "An armed robbery.", "crime_2_11"); } }
        public static ScannerFile Apossible211 { get { return new ScannerFile("01_crime_2_11\\0x19F9E4B3.mp3", "A possible 211.", "crime_2_11"); } }
        public static ScannerFile A211 { get { return new ScannerFile("01_crime_2_11\\0x1E842DC8.mp3", "A 211.", "crime_2_11"); } }
    }
    //public class crime_2_13
    //{
    //    public static ScannerFile A213 { get { return new ScannerFile("01_crime_2_13\\0x1490EDEF.mp3", "A 213.", "crime_2_13"); } }
    //    public static ScannerFile Useofexplosives { get { return new ScannerFile("01_crime_2_13\\0x190F36ED.mp3", "Use of explosives.", "crime_2_13"); } }
    //}
    //public class crime_2_17
    //{
    //    public static ScannerFile Anattemptedmurder { get { return new ScannerFile("01_crime_2_17\\0x0AFA345E.mp3", "An attempted murder.", "crime_2_17"); } }
    //    public static ScannerFile A217 { get { return new ScannerFile("01_crime_2_17\\0x1A5C9323.mp3", "A 217.", "crime_2_17"); } }
    //}
    //public class crime_2_40
    //{
    //    public static ScannerFile A240 { get { return new ScannerFile("01_crime_2_40\\0x0458F5C8.mp3", "A 240.", "crime_2_40"); } }
    //    public static ScannerFile Anassault { get { return new ScannerFile("01_crime_2_40\\0x15AA986C.mp3", "An assault.", "crime_2_40"); } }
    //}
    //public class crime_2_42
    //{
    //    public static ScannerFile A242 { get { return new ScannerFile("01_crime_2_42\\0x039009FB.mp3", "A 242.", "crime_2_42"); } }
    //    public static ScannerFile Abatteryincident { get { return new ScannerFile("01_crime_2_42\\0x13C5AA66.mp3", "A battery incident.", "crime_2_42"); } }
    //}
    //public class crime_2_45
    //{
    //    public static ScannerFile Anassaultwithadeadlyweapon { get { return new ScannerFile("01_crime_2_45\\0x032B7620.mp3", "An assault with a deadly weapon.", "crime_2_45"); } }
    //    public static ScannerFile Apossible245 { get { return new ScannerFile("01_crime_2_45\\0x0C3E8856.mp3", "A possible 245.", "crime_2_45"); } }
    //    public static ScannerFile A245 { get { return new ScannerFile("01_crime_2_45\\0x1E1A2C0D.mp3", "A 245.", "crime_2_45"); } }
    //}
    //public class crime_2_46
    //{
    //    public static ScannerFile Apossible246 { get { return new ScannerFile("01_crime_2_46\\0x04FA0824.mp3", "A possible 246.", "crime_2_46"); } }
    //    public static ScannerFile A246 { get { return new ScannerFile("01_crime_2_46\\0x1624AA79.mp3", "A 246.", "crime_2_46"); } }
    //    public static ScannerFile Ashootinginadwelling { get { return new ScannerFile("01_crime_2_46\\0x17176C4F.mp3", "A shooting in a dwelling.", "crime_2_46"); } }
    //}
    //public class crime_2_88
    //{
    //    public static ScannerFile Apossible288 { get { return new ScannerFile("01_crime_2_88\\0x001ABF70.mp3", "A possible 288.", "crime_2_88"); } }
    //    public static ScannerFile A288 { get { return new ScannerFile("01_crime_2_88\\0x0E4E5BD7.mp3", "A 288.", "crime_2_88"); } }
    //}
    //public class crime_3_11
    //{
    //    public static ScannerFile A311 { get { return new ScannerFile("01_crime_3_11\\0x0232E557.mp3", "A 311.", "crime_3_11"); } }
    //    public static ScannerFile Apossible311 { get { return new ScannerFile("01_crime_3_11\\0x15AE8C53.mp3", "A possible 311.", "crime_3_11"); } }
    //    public static ScannerFile Anindecentexposure { get { return new ScannerFile("01_crime_3_11\\0x196E53D3.mp3", "An indecent exposure.", "crime_3_11"); } }
    //}
    public class crime_3_90
    {
        public static ScannerFile Apossible390 { get { return new ScannerFile("01_crime_3_90\\0x08698BA8.mp3", "A possible 390.", "crime_3_90"); } }
        public static ScannerFile Publicintoxication { get { return new ScannerFile("01_crime_3_90\\0x1632E73A.mp3", "Public intoxication.", "crime_3_90"); } }
        public static ScannerFile A390 { get { return new ScannerFile("01_crime_3_90\\0x19882DE5.mp3", "A 390.", "crime_3_90"); } }
    }
    public class crime_4_06
    {
        public static ScannerFile Apossible406 { get { return new ScannerFile("01_crime_4_06\\0x061DEFD6.mp3", "A possible 406.", "crime_4_06"); } }
        public static ScannerFile Breakingandentering { get { return new ScannerFile("01_crime_4_06\\0x0FDFC35A.mp3", "Breaking and entering.", "crime_4_06"); } }
        public static ScannerFile A406 { get { return new ScannerFile("01_crime_4_06\\0x13790A8D.mp3", "A 406.", "crime_4_06"); } }
        public static ScannerFile ABnE { get { return new ScannerFile("01_crime_4_06\\0x1E81A09D.mp3", "A BnE.", "crime_4_06"); } }
    }
    //public class crime_4_15 { public static ScannerFile A415 { get { return new ScannerFile("01_crime_4_15\\0x06E7893A.mp3", "A 415.", "crime_4_15"); } } }
    //public class crime_4_15_george
    //{
    //    public static ScannerFile Apossiblegangrelateddisturbance { get { return new ScannerFile("01_crime_4_15_george\\0x0A3A3012.mp3", "A possible gang-related disturbance.", "crime_4_15_george"); } }
    //    public static ScannerFile Agangrelateddisturbance { get { return new ScannerFile("01_crime_4_15_george\\0x0B23B1DB.mp3", "A gang-related disturbance.", "crime_4_15_george"); } }
    //    public static ScannerFile A415George { get { return new ScannerFile("01_crime_4_15_george\\0x1D721678.mp3", "A 415 George.", "crime_4_15_george"); } }
    //}
    //public class crime_4_17
    //{
    //    public static ScannerFile Apersonwithafirearm { get { return new ScannerFile("01_crime_4_17\\0x0A578619.mp3", "A person with a firearm.", "crime_4_17"); } }
    //    public static ScannerFile A417 { get { return new ScannerFile("01_crime_4_17\\0x15D4DD10.mp3", "A 417.", "crime_4_17"); } }
    //    public static ScannerFile Apersonwithagun { get { return new ScannerFile("01_crime_4_17\\0x1F9EB0A4.mp3", "A person with a gun.", "crime_4_17"); } }
    //}
    //public class crime_4_17_king
    //{
    //    public static ScannerFile Apersonwithaknife { get { return new ScannerFile("01_crime_4_17_king\\0x05BD27F9.mp3", "A person with a knife.", "crime_4_17_king"); } }
    //    public static ScannerFile A417King { get { return new ScannerFile("01_crime_4_17_king\\0x11B4BFE4.mp3", "A 417 King.", "crime_4_17_king"); } }
    //    public static ScannerFile Apossible417King { get { return new ScannerFile("01_crime_4_17_king\\0x12F6426C.mp3", "A possible 417 King.", "crime_4_17_king"); } }
    //    public static ScannerFile A417King1 { get { return new ScannerFile("01_crime_4_17_king\\0x1AFE9278.mp3", "A 417 King.", "crime_4_17_king"); } }
    //}
    public class crime_4_19
    {
        public static ScannerFile Apossible419 { get { return new ScannerFile("01_crime_4_19\\0x0658CBC9.mp3", "A possible 419.", "crime_4_19"); } }
        public static ScannerFile A419 { get { return new ScannerFile("01_crime_4_19\\0x1103211D.mp3", "A 419.", "crime_4_19"); } }
        public static ScannerFile Adeadbody { get { return new ScannerFile("01_crime_4_19\\0x148F6836.mp3", "A dead body.", "crime_4_19"); } }
        public static ScannerFile Adeceasedperson { get { return new ScannerFile("01_crime_4_19\\0x19D032B4.mp3", "A deceased person.", "crime_4_19"); } }
    }
    //public class crime_4_59
    //{
    //    public static ScannerFile ABnE { get { return new ScannerFile("01_crime_4_59\\0x159DC5DC.mp3", "A BnE.", "crime_4_59"); } }
    //    public static ScannerFile Apossible459 { get { return new ScannerFile("01_crime_4_59\\0x18214A95.mp3", "A possible 459.", "crime_4_59"); } }
    //}
    //public class crime_4_80
    //{
    //    public static ScannerFile A480 { get { return new ScannerFile("01_crime_4_80\\0x05D8072E.mp3", "A 480.", "crime_4_80"); } }
    //    public static ScannerFile Afelonyhitandrun { get { return new ScannerFile("01_crime_4_80\\0x09A9CED1.mp3", "A felony hit and run.", "crime_4_80"); } }
    //    public static ScannerFile Ahitandrun { get { return new ScannerFile("01_crime_4_80\\0x0C46540B.mp3", "A hit and run.", "crime_4_80"); } }
    //    public static ScannerFile Apossible480 { get { return new ScannerFile("01_crime_4_80\\0x1719A9B2.mp3", "A possible 480.", "crime_4_80"); } }
    //}
    //public class crime_4_81
    //{
    //    public static ScannerFile Ahitandrun { get { return new ScannerFile("01_crime_4_81\\0x08B8E1B0.mp3", "A hit and run.", "crime_4_81"); } }
    //    public static ScannerFile A481 { get { return new ScannerFile("01_crime_4_81\\0x1A9E8577.mp3", "A 481.", "crime_4_81"); } }
    //}
    public class crime_4_84
    {
        public static ScannerFile Apettytheft { get { return new ScannerFile("01_crime_4_84\\0x089B4C9F.mp3", "A petty theft.", "crime_4_84"); } }
        public static ScannerFile Apossible484 { get { return new ScannerFile("01_crime_4_84\\0x125A601D.mp3", "A possible 484.", "crime_4_84"); } }
        public static ScannerFile A484 { get { return new ScannerFile("01_crime_4_84\\0x1C0E7386.mp3", "A 484.", "crime_4_84"); } }
    }
    //public class crime_4_84_paul_sam
    //{
    //    public static ScannerFile Apursetheft { get { return new ScannerFile("01_crime_4_84_paul_sam\\0x05649D12.mp3", "A purse theft.", "crime_4_84_paul_sam"); } }
    //    public static ScannerFile A484PaulSam { get { return new ScannerFile("01_crime_4_84_paul_sam\\0x07E5A217.mp3", "A 484 Paul-Sam.", "crime_4_84_paul_sam"); } }
    //    public static ScannerFile Apossible484PaulSam { get { return new ScannerFile("01_crime_4_84_paul_sam\\0x13CE79E5.mp3", "A possible 484 Paul-Sam.", "crime_4_84_paul_sam"); } }
    //}
    //public class crime_4_87
    //{
    //    public static ScannerFile Apossible487 { get { return new ScannerFile("01_crime_4_87\\0x047A29C5.mp3", "A possible 487.", "crime_4_87"); } }
    //    public static ScannerFile Agrandtheft { get { return new ScannerFile("01_crime_4_87\\0x11C84461.mp3", "A grand theft.", "crime_4_87"); } }
    //    public static ScannerFile A487 { get { return new ScannerFile("01_crime_4_87\\0x14FA8AC6.mp3", "A 487,", "crime_4_87"); } }
    //}
    //public class crime_4_88
    //{
    //    public static ScannerFile Apossible488 { get { return new ScannerFile("01_crime_4_88\\0x0A83BA37.mp3", "A possible 488.", "crime_4_88"); } }
    //    public static ScannerFile A488 { get { return new ScannerFile("01_crime_4_88\\0x1D09DF42.mp3", "A 488.", "crime_4_88"); } }
    //}
    public class crime_5_02
    {
        public static ScannerFile ADUI { get { return new ScannerFile("01_crime_5_02\\0x02098AFD.mp3", "A DUI.", "crime_5_02"); } }
        public static ScannerFile A502DUI { get { return new ScannerFile("01_crime_5_02\\0x021C8B2F.mp3", "A 502 DUI.", "crime_5_02"); } }
        public static ScannerFile A502 { get { return new ScannerFile("01_crime_5_02\\0x08BE9874.mp3", "A 502.", "crime_5_02"); } }
        public static ScannerFile Adriverundertheinfluence { get { return new ScannerFile("01_crime_5_02\\0x139E2E26.mp3", "A driver under the influence.", "crime_5_02"); } }
        public static ScannerFile Apossible502 { get { return new ScannerFile("01_crime_5_02\\0x142D2F50.mp3", "A possible 502.", "crime_5_02"); } }
        public static ScannerFile Adriverundertheinfluence1 { get { return new ScannerFile("01_crime_5_02\\0x1E54C392.mp3", "A driver under the influence.", "crime_5_02"); } }
    }
    public class crime_5_03
    {
        public static ScannerFile A503 { get { return new ScannerFile("01_crime_5_03\\0x1ADB2E53.mp3", "A 503.", "crime_5_03"); } }
        public static ScannerFile Apossible503 { get { return new ScannerFile("01_crime_5_03\\0x1E52F541.mp3", "A possible 503.", "crime_5_03"); } }
    }
    public class crime_5_04
    {
        public static ScannerFile Tamperingwithavehicle { get { return new ScannerFile("01_crime_5_04\\0x08C01409.mp3", "Tampering with a vehicle.", "crime_5_04"); } }
        public static ScannerFile A504 { get { return new ScannerFile("01_crime_5_04\\0x1868B35A.mp3", "A 504.", "crime_5_04"); } }
    }
    public class crime_5_05
    {
        public static ScannerFile A505 { get { return new ScannerFile("01_crime_5_05\\0x037BFDBB.mp3", "A 505.", "crime_5_05"); } }
        public static ScannerFile Adriveroutofcontrol { get { return new ScannerFile("01_crime_5_05\\0x05E10283.mp3", "A driver out of control.", "crime_5_05"); } }
    }
    public class crime_5_07
    {
        public static ScannerFile A507 { get { return new ScannerFile("01_crime_5_07\\0x021ACC57.mp3", "A 507.", "crime_5_07"); } }
        public static ScannerFile Apublicnuisance { get { return new ScannerFile("01_crime_5_07\\0x0CE561EB.mp3", "A public nuisance.", "crime_5_07"); } }
    }
    public class crime_5_10
    {
        public static ScannerFile A510 { get { return new ScannerFile("01_crime_5_10\\0x00FCB2AB.mp3", "A 510.", "crime_5_10"); } }
        public static ScannerFile Vehiclesracing { get { return new ScannerFile("01_crime_5_10\\0x12CE564E.mp3", "Vehicles racing.", "crime_5_10"); } }
        public static ScannerFile Speedingvehicle { get { return new ScannerFile("01_crime_5_10\\0x17561F60.mp3", "Speeding vehicles.", "crime_5_10"); } }
    }
    //public class crime_5_86
    //{
    //    public static ScannerFile A586 { get { return new ScannerFile("01_crime_5_86\\0x092E5D13.mp3", "A 586.", "crime_5_86"); } }
    //    public static ScannerFile Anillegallyparkedvehicle { get { return new ScannerFile("01_crime_5_86\\0x0D4EA555.mp3", "An illegally parked vehicle.", "crime_5_86"); } }
    //    public static ScannerFile Illegalparking { get { return new ScannerFile("01_crime_5_86\\0x18DA7C6C.mp3", "Illegal parking.", "crime_5_86"); } }
    //    public static ScannerFile Aparkingviolation { get { return new ScannerFile("01_crime_5_86\\0x1E1106DA.mp3", "A parking violation.", "crime_5_86"); } }
    //}
    public class crime_5_94
    {
        public static ScannerFile Maliciousmischief { get { return new ScannerFile("01_crime_5_94\\0x08494618.mp3", "Malicious mischief.", "crime_5_94"); } }
        public static ScannerFile Maliciousmischief1 { get { return new ScannerFile("01_crime_5_94\\0x0EA052C1.mp3", "Malicious mischief.", "crime_5_94"); } }
        public static ScannerFile A594 { get { return new ScannerFile("01_crime_5_94\\0x16BD22FD.mp3", "A 594.", "crime_5_94"); } }
    }
    //public class crime_6_53_mary
    //{
    //    public static ScannerFile Athreateningphonecall { get { return new ScannerFile("01_crime_6_53_mary\\0x04A45011.mp3", "A threatening phone call.", "crime_6_53_mary"); } }
    //    public static ScannerFile A653Mary { get { return new ScannerFile("01_crime_6_53_mary\\0x14332F31.mp3", "A 653-Mary.", "crime_6_53_mary"); } }
    //}
    public class crime_9_14a_attempted_suicide
    {
        public static ScannerFile Apossibleattemptedsuicide { get { return new ScannerFile("01_crime_9_14a_attempted_suicide\\0x037FB5C7.mp3", "A possible attempted suicide.", "crime_9_14a_attempted_suicide"); } }
        public static ScannerFile Anattemptedsuicide { get { return new ScannerFile("01_crime_9_14a_attempted_suicide\\0x0765BD91.mp3", "An attempted suicide.", "crime_9_14a_attempted_suicide"); } }
        public static ScannerFile Apossible914A { get { return new ScannerFile("01_crime_9_14a_attempted_suicide\\0x08A0C007.mp3", "A possible 914A.", "crime_9_14a_attempted_suicide"); } }
        public static ScannerFile A914A { get { return new ScannerFile("01_crime_9_14a_attempted_suicide\\0x1141114A.mp3", "A 914A.", "crime_9_14a_attempted_suicide"); } }
        public static ScannerFile A914Adam { get { return new ScannerFile("01_crime_9_14a_attempted_suicide\\0x1AE16488.mp3", "A 914-Adam.", "crime_9_14a_attempted_suicide"); } }
    }
    public class crime_9_25
    {
        public static ScannerFile Asuspiciousperson { get { return new ScannerFile("01_crime_9_25\\0x11BA9943.mp3", "A suspicious person.", "crime_9_25"); } }
        public static ScannerFile A925 { get { return new ScannerFile("01_crime_9_25\\0x1F38B43F.mp3", "A 925.", "crime_9_25"); } }
    }
    //public class crime_9_96
    //{
    //    public static ScannerFile A996 { get { return new ScannerFile("01_crime_9_96\\0x0BD091D7.mp3", "A 996.", "crime_9_96"); } }
    //    public static ScannerFile Acombustiblematerialincident { get { return new ScannerFile("01_crime_9_96\\0x11861D3A.mp3", "A combustible material incident.", "crime_9_96"); } }
    //}
    //public class crime_9_96_boy
    //{
    //    public static ScannerFile A996Boy { get { return new ScannerFile("01_crime_9_96_boy\\0x05AC6C07.mp3", "A 996-Boy.", "crime_9_96_boy"); } }
    //    public static ScannerFile Anexplosion { get { return new ScannerFile("01_crime_9_96_boy\\0x1BF8589E.mp3", "An explosion.", "crime_9_96_boy"); } }
    //}
   // public class crime_accident { public static ScannerFile Anaccident { get { return new ScannerFile("01_crime_accident\\0x0AC0DB4B.mp3", "An accident.", "crime_accident"); } } }
    //public class crime_airplane_crash
    //{
    //    public static ScannerFile Anaircraftcrash { get { return new ScannerFile("01_crime_airplane_crash\\0x04A51B94.mp3", "An aircraft crash.", "crime_airplane_crash"); } }
    //    public static ScannerFile AnAC { get { return new ScannerFile("01_crime_airplane_crash\\0x183EC2CD.mp3", "An AC.", "crime_airplane_crash"); } }
    //    public static ScannerFile Anairplanecrash { get { return new ScannerFile("01_crime_airplane_crash\\0x190D4464.mp3", "An airplane crash.", "crime_airplane_crash"); } }
    //}
    //public class crime_air_squad_down { public static ScannerFile Anairsquaddown { get { return new ScannerFile("01_crime_air_squad_down\\0x08895194.mp3", "An air squad down.", "crime_air_squad_down"); } } }
    //public class crime_air_unit_down { public static ScannerFile Anairunitdown { get { return new ScannerFile("01_crime_air_unit_down\\0x098D02C9.mp3", "An air unit down.", "crime_air_unit_down"); } } }
    //public class crime_ambulance_requested
    //{
    //    public static ScannerFile Anambulancecall { get { return new ScannerFile("01_crime_ambulance_requested\\0x01B705D3.mp3", "An ambulance call.", "crime_ambulance_requested"); } }
    //    public static ScannerFile Aninjuryincident { get { return new ScannerFile("01_crime_ambulance_requested\\0x0B58D917.mp3", "An injury incident.", "crime_ambulance_requested"); } }
    //    public static ScannerFile Anambulancerequestedinjuriesunknown { get { return new ScannerFile("01_crime_ambulance_requested\\0x1208E676.mp3", "An ambulance requested; injuries unknown.", "crime_ambulance_requested"); } }
    //}
    //public class crime_animal_cruelty
    //{
    //    public static ScannerFile Reportofanimalcruelty { get { return new ScannerFile("01_crime_animal_cruelty\\0x0383DAFA.mp3", "Report of animal cruelty.", "crime_animal_cruelty"); } }
    //    public static ScannerFile Reportsofanimalcruelty { get { return new ScannerFile("01_crime_animal_cruelty\\0x12BA7967.mp3", "Reports of animal cruelty.", "crime_animal_cruelty"); } }
    //    public static ScannerFile Reportsofanimalcruelty1 { get { return new ScannerFile("01_crime_animal_cruelty\\0x16DD41AE.mp3", "Reports of animal cruelty.", "crime_animal_cruelty"); } }
    //}
    //public class crime_animal_killed
    //{
    //    public static ScannerFile Animalkilledbyperson { get { return new ScannerFile("01_crime_animal_killed\\0x0BAACC73.mp3", "Animal killed by person.", "crime_animal_killed"); } }
    //    public static ScannerFile Animalkilled { get { return new ScannerFile("01_crime_animal_killed\\0x0F3A9393.mp3", "Animal killed.", "crime_animal_killed"); } }
    //}
    //public class crime_armored_car_robbery
    //{
    //    public static ScannerFile Anarmoredcarrobbery { get { return new ScannerFile("01_crime_armored_car_robbery\\0x0E8B5D1D.mp3", "An armored car robbery.", "crime_armored_car_robbery"); } }
    //    public static ScannerFile Apossiblearmoredcarrobbery { get { return new ScannerFile("01_crime_armored_car_robbery\\0x1D40BA88.mp3", "A possible armored car robbery.", "crime_armored_car_robbery"); } }
    //}
    //public class crime_arson
    //{
    //    public static ScannerFile Anarsonattack { get { return new ScannerFile("01_crime_arson\\0x040FE61D.mp3", "An arson attack.", "crime_arson"); } }
    //    public static ScannerFile Arson { get { return new ScannerFile("01_crime_arson\\0x124D0298.mp3", "Arson.", "crime_arson"); } }
    //}
    public class crime_assault
    {
        public static ScannerFile Apossibleassault { get { return new ScannerFile("01_crime_assault\\0x1009963F.mp3", "A possible assault.", "crime_assault"); } }
        public static ScannerFile Apossibleassault1 { get { return new ScannerFile("01_crime_assault\\0x1E4332B2.mp3", "A possible assault.", "crime_assault"); } }
    }
    public class crime_assault_and_battery
    {
        public static ScannerFile AnAE { get { return new ScannerFile("01_crime_assault_and_battery\\0x0C4A5075.mp3", "An A&E.", "crime_assault_and_battery"); } }
        public static ScannerFile Anassaultandbattery { get { return new ScannerFile("01_crime_assault_and_battery\\0x1AF12DC3.mp3", "An assault and battery.", "crime_assault_and_battery"); } }
    }
    public class crime_assault_on_an_officer
    {
        public static ScannerFile Anassaultonanofficer { get { return new ScannerFile("01_crime_assault_on_an_officer\\0x162AEAAA.mp3", "An assault on an officer.", "crime_assault_on_an_officer"); } }
        public static ScannerFile Anofficerassault { get { return new ScannerFile("01_crime_assault_on_an_officer\\0x1F80BD56.mp3", "An officer assault.", "crime_assault_on_an_officer"); } }
    }
    public class crime_assault_on_a_civilian { public static ScannerFile Anassaultonacivilian { get { return new ScannerFile("01_crime_assault_on_a_civilian\\0x058AC21E.mp3", "An assault on a civilian.", "crime_assault_on_a_civilian"); } } }
    public class crime_assault_with_a_deadly_weapon
    {
        public static ScannerFile AnADW { get { return new ScannerFile("01_crime_assault_with_a_deadly_weapon\\0x0B1C964E.mp3", "An ADW.", "crime_assault_with_a_deadly_weapon"); } }
        public static ScannerFile Assaultwithadeadlyweapon { get { return new ScannerFile("01_crime_assault_with_a_deadly_weapon\\0x1909F229.mp3", "Assault with a deadly weapon.", "crime_assault_with_a_deadly_weapon"); } }
    }
    //public class crime_association
    //{
    //    public static ScannerFile Associationwithanindividualengagedincriminalactivity { get { return new ScannerFile("01_crime_association\\0x047A56F7.mp3", "Association with an individual engaged in criminal activity.", "crime_association"); } }
    //    public static ScannerFile Associationwithaknownfelon { get { return new ScannerFile("01_crime_association\\0x11807101.mp3", "Association with a known felon.", "crime_association"); } }
    //    public static ScannerFile Associationwithaknowncriminal { get { return new ScannerFile("01_crime_association\\0x123BF27A.mp3", "Association with a known criminal.", "crime_association"); } }
    //    public static ScannerFile Associationwithanindividualengagedincriminalactivity1 { get { return new ScannerFile("01_crime_association\\0x16813B05.mp3", "Association with an individual engaged in criminal activity.", "crime_association"); } }
    //    public static ScannerFile Acivilianwantedforassociationwithaknownfelon { get { return new ScannerFile("01_crime_association\\0x1F598CB7.mp3", "A civilian wanted for association with a known felon.", "crime_association"); } }
    //}
    //public class crime_attack_on_an_endangered_species { public static ScannerFile Anattackonanendangeredspecies { get { return new ScannerFile("01_crime_attack_on_an_endangered_species\\0x1B784403.mp3", "An attack on an endangered species.", "crime_attack_on_an_endangered_species"); } } }
    // public class crime_attack_on_an_officer { public static ScannerFile Anattackonanofficer { get { return new ScannerFile("01_crime_attack_on_an_officer\\0x05D1A54E.mp3", "An attack on an officer.", "crime_attack_on_an_officer"); } } }
    // public class crime_attack_on_a_motor_vehicle { public static ScannerFile Anattackonamotorvehicle { get { return new ScannerFile("01_crime_attack_on_a_motor_vehicle\\0x05B29DBA.mp3", "An attack on a motor vehicle.", "crime_attack_on_a_motor_vehicle"); } } }
    //public class crime_attack_on_a_protected_species
    //{
    //    public static ScannerFile Anattackonaprotectedspecies { get { return new ScannerFile("01_crime_attack_on_a_protected_species\\0x07F5B9BF.mp3", "An attack on a protected species.", "crime_attack_on_a_protected_species"); } }
    //    public static ScannerFile Attackonaprotectedspecies { get { return new ScannerFile("01_crime_attack_on_a_protected_species\\0x19A71D22.mp3", "Attack on a protected species.", "crime_attack_on_a_protected_species"); } }
    //}
    //public class crime_attack_on_a_vehicle { public static ScannerFile Anattackonavehicle { get { return new ScannerFile("01_crime_attack_on_a_vehicle\\0x0BCD234E.mp3", "An attack on a vehicle.", "crime_attack_on_a_vehicle"); } } }
    //public class crime_attempted_homicide { public static ScannerFile Anattemptedhomicide { get { return new ScannerFile("01_crime_attempted_homicide\\0x137F395C.mp3", "An attempted homicide.", "crime_attempted_homicide"); } } }
    public class crime_bank_robbery
    {
        public static ScannerFile Abankrobbery { get { return new ScannerFile("01_crime_bank_robbery\\0x08797576.mp3", "A bank robbery.", "crime_bank_robbery"); } }
        public static ScannerFile Abankheist { get { return new ScannerFile("01_crime_bank_robbery\\0x0D703F9D.mp3", "A bank heist.", "crime_bank_robbery"); } }
        public static ScannerFile Abankrobbery1 { get { return new ScannerFile("01_crime_bank_robbery\\0x12590970.mp3", "A bank robbery.", "crime_bank_robbery"); } }
        public static ScannerFile Apossiblebankrobbery { get { return new ScannerFile("01_crime_bank_robbery\\0x18C2D609.mp3", "A possible bank robbery.", "crime_bank_robbery"); } }
        public static ScannerFile Apossiblebankrobbery1 { get { return new ScannerFile("01_crime_bank_robbery\\0x1B249B06.mp3", "A possible bank robbery.", "crime_bank_robbery"); } }
    }
    //public class crime_burglary { public static ScannerFile Apossibleburglary { get { return new ScannerFile("01_crime_burglary\\0x065CDE1D.mp3", "A possible burglary.", "crime_burglary"); } } }
    //public class crime_car_jacking
    //{
    //    public static ScannerFile Apossiblecarjacking { get { return new ScannerFile("01_crime_car_jacking\\0x0BFAF610.mp3", "A possible carjacking.", "crime_car_jacking"); } }
    //    public static ScannerFile Acarjacking { get { return new ScannerFile("01_crime_car_jacking\\0x1A6892EB.mp3", "A carjacking.", "crime_car_jacking"); } }
    //}
    public class crime_car_on_fire
    {
        public static ScannerFile Acarfire { get { return new ScannerFile("01_crime_car_on_fire\\0x065069D8.mp3", "A car fire.", "crime_car_on_fire"); } }
        public static ScannerFile Acaronfire { get { return new ScannerFile("01_crime_car_on_fire\\0x13964464.mp3", "A car on fire.", "crime_car_on_fire"); } }
        public static ScannerFile Anautomobileonfire { get { return new ScannerFile("01_crime_car_on_fire\\0x18138D5F.mp3", "An automobile on fire.", "crime_car_on_fire"); } }
    }
    public class crime_civilian_down { public static ScannerFile Aciviliandown { get { return new ScannerFile("01_crime_civilian_down\\0x0320C921.mp3", "A civilian down.", "crime_civilian_down"); } } }
    public class crime_civilian_fatality { public static ScannerFile Acivilianfatality { get { return new ScannerFile("01_crime_civilian_fatality\\0x00445298.mp3", "A civilian fatality.", "crime_civilian_fatality"); } } }
    public class crime_civilian_needing_assistance
    {
        public static ScannerFile Acivilianinneedofassistance { get { return new ScannerFile("01_crime_civilian_needing_assistance\\0x09EF3EE7.mp3", "A civilian in need of assistance.", "crime_civilian_needing_assistance"); } }
        public static ScannerFile Acivilianrequiringassistance { get { return new ScannerFile("01_crime_civilian_needing_assistance\\0x0B380179.mp3", "A civilian requiring assistance.", "crime_civilian_needing_assistance"); } }
    }
    public class crime_civillian_gsw
    {
        public static ScannerFile AcivilianGSW { get { return new ScannerFile("01_crime_civillian_gsw\\0x0382F686.mp3", "A civilian GSW.", "crime_civillian_gsw"); } }
        public static ScannerFile Agunshotwound { get { return new ScannerFile("01_crime_civillian_gsw\\0x11579233.mp3", "A gunshot wound.", "crime_civillian_gsw"); } }
        public static ScannerFile Acivilianshot { get { return new ScannerFile("01_crime_civillian_gsw\\0x15439A09.mp3", "A civilian shot.", "crime_civillian_gsw"); } }
    }
    //public class crime_civillian_on_fire { public static ScannerFile Acivilianonfire { get { return new ScannerFile("01_crime_civillian_on_fire\\0x0CCE003C.mp3", "A civilian on fire.", "crime_civillian_on_fire"); } } }
    //public class crime_civil_disturbance { public static ScannerFile Acivildisturbance { get { return new ScannerFile("01_crime_civil_disturbance\\0x16A9B4AA.mp3", "A civil disturbance.", "crime_civil_disturbance"); } } }
    //public class crime_code { public static ScannerFile 217 { get {return new ScannerFile("01_crime_code\\0x00FB6351.mp3","217","crime_code"); } }
    //public static ScannerFile 10851 { get {return new ScannerFile("01_crime_code\\0x0103395C.mp3","10-851.","crime_code"); } }
    //public static ScannerFile 488 { get {return new ScannerFile("01_crime_code\\0x0188BBA3.mp3","488","crime_code"); } }
    //public static ScannerFile 904Ita { get {return new ScannerFile("01_crime_code\\0x030753BA.mp3","904-Ita.","crime_code"); } }
    //public static ScannerFile 901 { get {return new ScannerFile("01_crime_code\\0x030C3584.mp3","901","crime_code"); } }
    //public static ScannerFile 487 { get {return new ScannerFile("01_crime_code\\0x0310EC28.mp3","487","crime_code"); } }
    //public static ScannerFile 419 { get {return new ScannerFile("01_crime_code\\0x03243366.mp3","419","crime_code"); } }
    //public static ScannerFile 207 { get {return new ScannerFile("01_crime_code\\0x038A9512.mp3","207","crime_code"); } }
    //public static ScannerFile 417King { get {return new ScannerFile("01_crime_code\\0x03EB0FF6.mp3","417-King.","crime_code"); } }
    //public static ScannerFile 245 { get {return new ScannerFile("01_crime_code\\0x0401D618.mp3","245","crime_code"); } }
    //public static ScannerFile 903Lincoln { get {return new ScannerFile("01_crime_code\\0x04D4AD2D.mp3","903-Lincoln.","crime_code"); } }
    //public static ScannerFile 914Adam { get {return new ScannerFile("01_crime_code\\0x04EF35D7.mp3","914-Adam.","crime_code"); } }
    //public static ScannerFile 907 { get {return new ScannerFile("01_crime_code\\0x05065437.mp3","907","crime_code"); } }
    //public static ScannerFile 480 { get {return new ScannerFile("01_crime_code\\0x06093E1B.mp3","480","crime_code"); } }
    //public static ScannerFile 996 { get {return new ScannerFile("01_crime_code\\0x06368CB0.mp3","996","crime_code"); } }
    //public static ScannerFile 902Mary { get {return new ScannerFile("01_crime_code\\0x06736F2D.mp3","902-Mary.","crime_code"); } }
    //public static ScannerFile 904Sam { get {return new ScannerFile("01_crime_code\\0x069F3F90.mp3","904-Sam.","crime_code"); } }
    //public static ScannerFile 929 { get {return new ScannerFile("01_crime_code\\0x06B2322F.mp3","929","crime_code"); } }
    //public static ScannerFile 484 { get {return new ScannerFile("01_crime_code\\0x06DFA11C.mp3","484","crime_code"); } }
    //public static ScannerFile 902 { get {return new ScannerFile("01_crime_code\\0x06EA9253.mp3","902","crime_code"); } }
    //public static ScannerFile 502 { get {return new ScannerFile("01_crime_code\\0x0746316D.mp3","502","crime_code"); } }
    //public static ScannerFile 904Charles { get {return new ScannerFile("01_crime_code\\0x07A4EF29.mp3","904-Charles.","crime_code"); } }
    //public static ScannerFile 927David { get {return new ScannerFile("01_crime_code\\0x07D4794C.mp3","927-David.","crime_code"); } }
    //public static ScannerFile 414 { get {return new ScannerFile("01_crime_code\\0x0808B6D4.mp3","414","crime_code"); } }
    //public static ScannerFile 966 { get {return new ScannerFile("01_crime_code\\0x0863A7EE.mp3","966","crime_code"); } }
    //public static ScannerFile 909Boy { get {return new ScannerFile("01_crime_code\\0x09135B68.mp3","909-Boy.","crime_code"); } }
    //public static ScannerFile 311 { get {return new ScannerFile("01_crime_code\\0x094F689E.mp3","311","crime_code"); } }
    //public static ScannerFile 11351 { get {return new ScannerFile("01_crime_code\\0x0996DA87.mp3","11-351.","crime_code"); } }
    //public static ScannerFile 240 { get {return new ScannerFile("01_crime_code\\0x09D448E7.mp3","240","crime_code"); } }
    //public static ScannerFile 594 { get {return new ScannerFile("01_crime_code\\0x09F3C77B.mp3","594","crime_code"); } }
    //public static ScannerFile 510 { get {return new ScannerFile("01_crime_code\\0x0BC94D46.mp3","510","crime_code"); } }
    //public static ScannerFile 148 { get {return new ScannerFile("01_crime_code\\0x0BF24A76.mp3","148","crime_code"); } }
    //public static ScannerFile 904Adam { get {return new ScannerFile("01_crime_code\\0x0C36AD40.mp3","904-Adam.","crime_code"); } }
    //public static ScannerFile 390 { get {return new ScannerFile("01_crime_code\\0x0C381C87.mp3","390","crime_code"); } }
    //public static ScannerFile 507 { get {return new ScannerFile("01_crime_code\\0x0D2C6CAE.mp3","507","crime_code"); } }
    //public static ScannerFile 187 { get {return new ScannerFile("01_crime_code\\0x0DA299B4.mp3","187","crime_code"); } }
    //public static ScannerFile 484PaulSam { get {return new ScannerFile("01_crime_code\\0x0DC9BC8D.mp3","484-Paul-Sam.","crime_code"); } }
    //public static ScannerFile 444 { get {return new ScannerFile("01_crime_code\\0x0DF44376.mp3","444","crime_code"); } }
    //public static ScannerFile 211 { get {return new ScannerFile("01_crime_code\\0x0E7FA39E.mp3","211","crime_code"); } }
    //public static ScannerFile 417 { get {return new ScannerFile("01_crime_code\\0x0FAE97B7.mp3","417","crime_code"); } }
    //public static ScannerFile 288 { get {return new ScannerFile("01_crime_code\\0x10FAE4CB.mp3","288","crime_code"); } }
    //public static ScannerFile 213 { get {return new ScannerFile("01_crime_code\\0x11F9EB28.mp3","213","crime_code"); } }
    //public static ScannerFile 983 { get {return new ScannerFile("01_crime_code\\0x13DE7588.mp3","983","crime_code"); } }
    //public static ScannerFile 481 { get {return new ScannerFile("01_crime_code\\0x142813A7.mp3","481","crime_code"); } }
    //public static ScannerFile 905Victor { get {return new ScannerFile("01_crime_code\\0x143869C1.mp3","905-Victor.","crime_code"); } }
    //public static ScannerFile 967 { get {return new ScannerFile("01_crime_code\\0x1438833D.mp3","967","crime_code"); } }
    //public static ScannerFile 504 { get {return new ScannerFile("01_crime_code\\0x1605163B.mp3","504","crime_code"); } }
    //public static ScannerFile 903 { get {return new ScannerFile("01_crime_code\\0x160BB4CD.mp3","903","crime_code"); } }
    //public static ScannerFile 246 { get {return new ScannerFile("01_crime_code\\0x1630735E.mp3","246","crime_code"); } }
    //public static ScannerFile 406 { get {return new ScannerFile("01_crime_code\\0x1692A6C2.mp3","406","crime_code"); } }
    //public static ScannerFile 11357 { get {return new ScannerFile("01_crime_code\\0x18D16FE2.mp3","11-357.","crime_code"); } }
    //public static ScannerFile 925 { get {return new ScannerFile("01_crime_code\\0x18ED7E1A.mp3","925","crime_code"); } }
    //public static ScannerFile 1024 { get {return new ScannerFile("01_crime_code\\0x192D5BC6.mp3","10-24.","crime_code"); } }
    //public static ScannerFile 921 { get {return new ScannerFile("01_crime_code\\0x1AAFC639.mp3","921","crime_code"); } }
    //public static ScannerFile 653Mary { get {return new ScannerFile("01_crime_code\\0x1AF30F89.mp3","653-Mary.","crime_code"); } }
    //public static ScannerFile 586 { get {return new ScannerFile("01_crime_code\\0x1B01B8D9.mp3","586","crime_code"); } }
    //public static ScannerFile 999 { get {return new ScannerFile("01_crime_code\\0x1B880933.mp3","999","crime_code"); } }
    //public static ScannerFile 503 { get {return new ScannerFile("01_crime_code\\0x1B94ADAB.mp3","503","crime_code"); } }
    //public static ScannerFile 505 { get {return new ScannerFile("01_crime_code\\0x1D3FB67D.mp3","505","crime_code"); } }
    //public static ScannerFile 242 { get {return new ScannerFile("01_crime_code\\0x1E6525C5.mp3","242","crime_code"); } }
    //public static ScannerFile 415George { get {return new ScannerFile("01_crime_code\\0x1E7426F9.mp3","415-George.","crime_code"); } }
    //public static ScannerFile 459 { get {return new ScannerFile("01_crime_code\\0x1E8F076F.mp3","459","crime_code"); } }
    //public static ScannerFile 604 { get {return new ScannerFile("01_crime_code\\0x1F2EBBEC.mp3","604","crime_code"); } }}
    public class crime_criminal_activity
    {
        public static ScannerFile Areportofillegalactivity { get { return new ScannerFile("01_crime_criminal_activity\\0x02EE6B4D.mp3", "A report of illegal activity.", "crime_criminal_activity"); } }
        public static ScannerFile Illegalactivity { get { return new ScannerFile("01_crime_criminal_activity\\0x09E0F933.mp3", "Illegal activity.", "crime_criminal_activity"); } }
        public static ScannerFile Prohibitedactivity { get { return new ScannerFile("01_crime_criminal_activity\\0x112987C5.mp3", "Prohibited activity.", "crime_criminal_activity"); } }
        public static ScannerFile Areportofcriminalactivity { get { return new ScannerFile("01_crime_criminal_activity\\0x1160C832.mp3", "A report of criminal activity.", "crime_criminal_activity"); } }
        public static ScannerFile Criminalactivity { get { return new ScannerFile("01_crime_criminal_activity\\0x1B755C5C.mp3", "Criminal activity.", "crime_criminal_activity"); } }
        public static ScannerFile Areportofacriminalactivity { get { return new ScannerFile("01_crime_criminal_activity\\0x1E7A2266.mp3", "A report of a criminal activity.", "crime_criminal_activity"); } }
    }
    //public class crime_dangerous_driving
    //{
    //    public static ScannerFile Dangerousdriving { get { return new ScannerFile("01_crime_dangerous_driving\\0x0129A4E4.mp3", "Dangerous driving.", "crime_dangerous_driving"); } }
    //    public static ScannerFile Dangerousdriving1 { get { return new ScannerFile("01_crime_dangerous_driving\\0x1B6C996A.mp3", "Dangerous driving.", "crime_dangerous_driving"); } }
    //}
    //public class crime_dead_body { public static ScannerFile Adeadbody { get { return new ScannerFile("01_crime_dead_body\\0x1567C297.mp3", "A dead body.", "crime_dead_body"); } } }
    public class crime_disturbance
    {
        public static ScannerFile Apossibledisturbance { get { return new ScannerFile("01_crime_disturbance\\0x06A8CC92.mp3", "A possible disturbance.", "crime_disturbance"); } }
        public static ScannerFile Adisturbance { get { return new ScannerFile("01_crime_disturbance\\0x146B2817.mp3", "A disturbance.", "crime_disturbance"); } }
        public static ScannerFile Adisturbance1 { get { return new ScannerFile("01_crime_disturbance\\0x14AEA8AC.mp3", "A disturbance.", "crime_disturbance"); } }
        public static ScannerFile A415 { get { return new ScannerFile("01_crime_disturbance\\0x19F7733E.mp3", "A 415.", "crime_disturbance"); } }
    }
    //public class crime_domestic_disturbance
    //{
    //    public static ScannerFile Adomesticdisturbance { get { return new ScannerFile("01_crime_domestic_disturbance\\0x0BECC465.mp3", "A domestic disturbance.", "crime_domestic_disturbance"); } }
    //    public static ScannerFile Apossibledomesticdisturbance { get { return new ScannerFile("01_crime_domestic_disturbance\\0x1A19A0BE.mp3", "A possible domestic disturbance.", "crime_domestic_disturbance"); } }
    //}
    //public class crime_domestic_violence_incident { public static ScannerFile Domesticviolenceincident { get { return new ScannerFile("01_crime_domestic_violence_incident\\0x0533758F.mp3", "Domestic violence incident.", "crime_domestic_violence_incident"); } } }
    //public class crime_driveby_shooting { public static ScannerFile Adrivebyshooting { get { return new ScannerFile("01_crime_driveby_shooting\\0x1C66805E.mp3", "A driveby shooting.", "crime_driveby_shooting"); } } }
    public class crime_drug_deal
    {
        public static ScannerFile Narcoticstrafficking { get { return new ScannerFile("01_crime_drug_deal\\0x043280CC.mp3", "Narcotics trafficking.", "crime_drug_deal"); } }
        public static ScannerFile Adrugdeal { get { return new ScannerFile("01_crime_drug_deal\\0x0EB8D5D8.mp3", "A drug deal.", "crime_drug_deal"); } }
        public static ScannerFile Adrugdealinprogress { get { return new ScannerFile("01_crime_drug_deal\\0x15D9E419.mp3", "A drug deal in progress.", "crime_drug_deal"); } }
        public static ScannerFile Apossibledrugdeal { get { return new ScannerFile("01_crime_drug_deal\\0x18F3AA4E.mp3", "A possible drug deal.", "crime_drug_deal"); } }
    }
    public class crime_drug_overdose
    {
        public static ScannerFile An11357PossibleOD { get { return new ScannerFile("01_crime_drug_overdose\\0x053AC7E1.mp3", "An 11-357. Possible OD.", "crime_drug_overdose"); } }
        public static ScannerFile AnODvictim { get { return new ScannerFile("01_crime_drug_overdose\\0x0FF49D54.mp3", "An OD victim.", "crime_drug_overdose"); } }
        public static ScannerFile AnOD { get { return new ScannerFile("01_crime_drug_overdose\\0x1217E179.mp3", "An OD.", "crime_drug_overdose"); } }
        public static ScannerFile Adrugoverdose { get { return new ScannerFile("01_crime_drug_overdose\\0x195AF020.mp3", "A drug overdose.", "crime_drug_overdose"); } }
        public static ScannerFile Anoverdosedcivilian { get { return new ScannerFile("01_crime_drug_overdose\\0x1D563817.mp3", "An overdosed civilian.", "crime_drug_overdose"); } }
    }
    public class crime_firearms_incident
    {
        public static ScannerFile AfirearmsincidentShotsfired { get { return new ScannerFile("01_crime_firearms_incident\\0x054E27A4.mp3", "A firearms incident. Shots fired.", "crime_firearms_incident"); } }
        public static ScannerFile Anincidentinvolvingshotsfired { get { return new ScannerFile("01_crime_firearms_incident\\0x0684AA0E.mp3", "An incident involving shots fired.", "crime_firearms_incident"); } }
        public static ScannerFile AweaponsincidentShotsfired { get { return new ScannerFile("01_crime_firearms_incident\\0x193ACF7B.mp3", "A weapons incident. Shots fired.", "crime_firearms_incident"); } }
    }
    public class crime_firearms_possession { public static ScannerFile Afirearmspossession { get { return new ScannerFile("01_crime_firearms_possession\\0x0C2145BC.mp3", "A firearms possession.", "crime_firearms_possession"); } } }
   // public class crime_firearm_discharged_in_a_public_place { public static ScannerFile Afirearmdischargedinapublicplace { get { return new ScannerFile("01_crime_firearm_discharged_in_a_public_place\\0x085D09EB.mp3", "A firearm discharged in a public place.", "crime_firearm_discharged_in_a_public_place"); } } }
   // public class crime_fire_alarm { public static ScannerFile Afirealarm { get { return new ScannerFile("01_crime_fire_alarm\\0x0B3DC516.mp3", "A fire alarm.", "crime_fire_alarm"); } } }
  //  public class crime_gang_activity_incident { public static ScannerFile Agangactivityincident { get { return new ScannerFile("01_crime_gang_activity_incident\\0x18F48FFD.mp3", "A gang activity incident.", "crime_gang_activity_incident"); } } }
    //public class crime_gang_related_violence
    //{
    //    public static ScannerFile Gangrelatedviolence { get { return new ScannerFile("01_crime_gang_related_violence\\0x0092E590.mp3", "Gang-related violence.", "crime_gang_related_violence"); } }
    //    public static ScannerFile Gangrelatedviolence1 { get { return new ScannerFile("01_crime_gang_related_violence\\0x0EB801DB.mp3", "Gang-related violence.", "crime_gang_related_violence"); } }
    //}
    public class crime_grand_theft_auto
    {
        public static ScannerFile AGTAinprogress { get { return new ScannerFile("01_crime_grand_theft_auto\\0x008EDFEF.mp3", "A GTA in progress.", "crime_grand_theft_auto"); } }
        public static ScannerFile Agrandtheftautoinprogress { get { return new ScannerFile("01_crime_grand_theft_auto\\0x0A4D736D.mp3", "A grand theft auto in progress.", "crime_grand_theft_auto"); } }
        public static ScannerFile AGTAinprogress1 { get { return new ScannerFile("01_crime_grand_theft_auto\\0x0AA4B41B.mp3", "A GTA in progress.", "crime_grand_theft_auto"); } }
        public static ScannerFile Agrandtheftauto { get { return new ScannerFile("01_crime_grand_theft_auto\\0x1C0316D8.mp3", "A grand theft auto.", "crime_grand_theft_auto"); } }
    }
   // public class crime_gsw_driveby_attack { public static ScannerFile Adrivebyattack { get { return new ScannerFile("01_crime_gsw_driveby_attack\\0x0AC6744D.mp3", "A driveby attack.", "crime_gsw_driveby_attack"); } } }
    //public class crime_helicopter_down
    //{
    //    public static ScannerFile Ahelicopterdown { get { return new ScannerFile("01_crime_helicopter_down\\0x1DB63742.mp3", "A helicopter down.", "crime_helicopter_down"); } }
    //    public static ScannerFile Achopperdown { get { return new ScannerFile("01_crime_helicopter_down\\0x1F6ABAA8.mp3", "A chopper down.", "crime_helicopter_down"); } }
    //}
  //  public class crime_high_ranking_gang_member_in_transit { public static ScannerFile Ahighrankinggangmemberintransit { get { return new ScannerFile("01_crime_high_ranking_gang_member_in_transit\\0x0920EE1F.mp3", "A high-ranking gang member in transit.", "crime_high_ranking_gang_member_in_transit"); } } }
    public class crime_hijacked_aircraft { public static ScannerFile Ahijackedaircraft { get { return new ScannerFile("01_crime_hijacked_aircraft\\0x1CFA777C.mp3", "A hijacked aircraft.", "crime_hijacked_aircraft"); } } }
    public class crime_hijacked_vehicle { public static ScannerFile Ahijackedvehicle { get { return new ScannerFile("01_crime_hijacked_vehicle\\0x0E518420.mp3", "A hijacked vehicle.", "crime_hijacked_vehicle"); } } }
    public class crime_hold_up { public static ScannerFile Aholdup { get { return new ScannerFile("01_crime_hold_up\\0x162A5F2D.mp3", "A hold-up.", "crime_hold_up"); } } }
    //public class crime_hunting_an_endangered_species { public static ScannerFile Huntinganendangeredspecies { get { return new ScannerFile("01_crime_hunting_an_endangered_species\\0x1AFDD2BB.mp3", "Hunting an endangered species.", "crime_hunting_an_endangered_species"); } } }
    //public class crime_hunting_without_a_permit
    //{
    //    public static ScannerFile Personhuntingwithoutapermit { get { return new ScannerFile("01_crime_hunting_without_a_permit\\0x08CC0434.mp3", "Person hunting without a permit.", "crime_hunting_without_a_permit"); } }
    //    public static ScannerFile Huntingwithoutapermit { get { return new ScannerFile("01_crime_hunting_without_a_permit\\0x19FEA699.mp3", "Hunting without a permit.", "crime_hunting_without_a_permit"); } }
    //}
    //public class crime_illegal_burning
    //{
    //    public static ScannerFile Anillegalfire { get { return new ScannerFile("01_crime_illegal_burning\\0x1802EBFB.mp3", "An illegal fire.", "crime_illegal_burning"); } }
    //    public static ScannerFile Illegalburning { get { return new ScannerFile("01_crime_illegal_burning\\0x1ED03998.mp3", "Illegal burning.", "crime_illegal_burning"); } }
    //}
    public class crime_injured_civilian { public static ScannerFile Aninjuredcivilian { get { return new ScannerFile("01_crime_injured_civilian\\0x1AF8CB2D.mp3", "An injured civilian.", "crime_injured_civilian"); } } }
   // public class crime_killing_animals { public static ScannerFile Killinganimals { get { return new ScannerFile("01_crime_killing_animals\\0x0651B03C.mp3", "Killing animals.", "crime_killing_animals"); } } }
    //public class crime_kinfe_assault_on_an_officer { public static ScannerFile Aknifeassaultonanofficer { get { return new ScannerFile("01_crime_kinfe_assault_on_an_officer\\0x18674968.mp3", "A knife assault on an officer.", "crime_kinfe_assault_on_an_officer"); } } }
    //public class crime_low_flying_aircraft
    //{
    //    public static ScannerFile Alowflyingaircraft { get { return new ScannerFile("01_crime_low_flying_aircraft\\0x0ED60811.mp3", "A low-flying aircraft.", "crime_low_flying_aircraft"); } }
    //    public static ScannerFile Lowflyingaircraft { get { return new ScannerFile("01_crime_low_flying_aircraft\\0x1D91E58B.mp3", "Low-flying aircraft.", "crime_low_flying_aircraft"); } }
    //}
   // public class crime_malicious_damage_to_property { public static ScannerFile Maliciousdamagetoproperty { get { return new ScannerFile("01_crime_malicious_damage_to_property\\0x0E66D16B.mp3", "Malicious damage to property.", "crime_malicious_damage_to_property"); } } }
    public class crime_malicious_vehicle_damage { public static ScannerFile Maliciousvehicledamage { get { return new ScannerFile("01_crime_malicious_vehicle_damage\\0x13B65F4F.mp3", "Malicious vehicle damage.", "crime_malicious_vehicle_damage"); } } }
  // public class crime_mdv { public static ScannerFile MDV { get { return new ScannerFile("01_crime_mdv\\0x0419EF0A.mp3", "MDV.", "crime_mdv"); } } }
    public class crime_medical_aid_requested { public static ScannerFile Medicalaidrequested { get { return new ScannerFile("01_crime_medical_aid_requested\\0x0BB0BD5B.mp3", "Medical aid requested.", "crime_medical_aid_requested"); } } }
    //public class crime_motorcycle_rider_without_a_helmet
    //{
    //    public static ScannerFile Amotorcycleridersseenwithoutahelmet { get { return new ScannerFile("01_crime_motorcycle_rider_without_a_helmet\\0x0563B805.mp3", "A motorcycle rider(s) seen without a helmet.", "crime_motorcycle_rider_without_a_helmet"); } }
    //    public static ScannerFile Ridingamotorcyclewithoutahelmet { get { return new ScannerFile("01_crime_motorcycle_rider_without_a_helmet\\0x139E947B.mp3", "Riding a motorcycle without a helmet.", "crime_motorcycle_rider_without_a_helmet"); } }
    //    public static ScannerFile Amotorcycleriderwithoutahelmet { get { return new ScannerFile("01_crime_motorcycle_rider_without_a_helmet\\0x13D5D4E1.mp3", "A motorcycle rider without a helmet.", "crime_motorcycle_rider_without_a_helmet"); } }
    //}
    public class crime_motor_vehicle_accident
    {
        public static ScannerFile Amotorvehicleaccident { get { return new ScannerFile("01_crime_motor_vehicle_accident\\0x0305104D.mp3", "A motor vehicle accident.", "crime_motor_vehicle_accident"); } }
        public static ScannerFile AnAEincident { get { return new ScannerFile("01_crime_motor_vehicle_accident\\0x0829DA96.mp3", "An A&E incident.", "crime_motor_vehicle_accident"); } }
        public static ScannerFile AseriousMVA { get { return new ScannerFile("01_crime_motor_vehicle_accident\\0x1E710726.mp3", "A serious MVA.", "crime_motor_vehicle_accident"); } }
    }
    //public class crime_moving_violation { public static ScannerFile Amovingviolation { get { return new ScannerFile("01_crime_moving_violation\\0x13C84BC4.mp3", "A moving violation.", "crime_moving_violation"); } } }
    public class crime_mugging { public static ScannerFile Apossiblemugging { get { return new ScannerFile("01_crime_mugging\\0x195CFE4E.mp3", "A possible mugging.", "crime_mugging"); } } }
    //public class crime_multiple_injuries { public static ScannerFile Multipleinjuries { get { return new ScannerFile("01_crime_multiple_injuries\\0x03841223.mp3", "Multiple injuries.", "crime_multiple_injuries"); } } }
    //public class crime_narcotics_activity { public static ScannerFile Narcoticsactivity { get { return new ScannerFile("01_crime_narcotics_activity\\0x060CE903.mp3", "Narcotics activity.", "crime_narcotics_activity"); } } }
    //public class crime_narcotics_in_transit { public static ScannerFile Narcoticsintransit { get { return new ScannerFile("01_crime_narcotics_in_transit\\0x0E83D176.mp3", "Narcotics in transit.", "crime_narcotics_in_transit"); } } }
    public class crime_officers_down
    {
        public static ScannerFile Severalofficersdown { get { return new ScannerFile("01_crime_officers_down\\0x10A785B3.mp3", "Several officers down.", "crime_officers_down"); } }
        public static ScannerFile Multipleofficersdown { get { return new ScannerFile("01_crime_officers_down\\0x1FF1244F.mp3", "Multiple officers down.", "crime_officers_down"); } }
    }
    //public class crime_officer_assault { public static ScannerFile Anofficerassault { get { return new ScannerFile("01_crime_officer_assault\\0x11374E1D.mp3", "An officer assault.", "crime_officer_assault"); } } }
    public class crime_officer_down
    {
        public static ScannerFile Anofficerdownconditionunknown { get { return new ScannerFile("01_crime_officer_down\\0x01FDB341.mp3", "An officer down; condition unknown.", "crime_officer_down"); } }
        public static ScannerFile Anofficerdown { get { return new ScannerFile("01_crime_officer_down\\0x05AFFAAA.mp3", "An officer down.", "crime_officer_down"); } }
        public static ScannerFile AnofferdownpossiblyKIA { get { return new ScannerFile("01_crime_officer_down\\0x143757B4.mp3", "An offer down, possibly KIA.", "crime_officer_down"); } }
        public static ScannerFile AcriticalsituationOfficerdown { get { return new ScannerFile("01_crime_officer_down\\0x17C49ECF.mp3", "A critical situation: Officer down.", "crime_officer_down"); } }
    }
    //public class crime_officer_fatality
    //{
    //    public static ScannerFile Anofficerhomicide { get { return new ScannerFile("01_crime_officer_fatality\\0x06FE2FC0.mp3", "An officer homicide.", "crime_officer_fatality"); } }
    //    public static ScannerFile Anofficerfatality { get { return new ScannerFile("01_crime_officer_fatality\\0x1844124C.mp3", "An officer fatality.", "crime_officer_fatality"); } }
    //}
    //public class crime_officer_homicide { public static ScannerFile Anofficerhomicide { get { return new ScannerFile("01_crime_officer_homicide\\0x146BDE45.mp3", "An officer homicide.", "crime_officer_homicide"); } } }
    //public class crime_officer_injured { public static ScannerFile Anofficerinjured { get { return new ScannerFile("01_crime_officer_injured\\0x095FEC28.mp3", "An officer injured.", "crime_officer_injured"); } } }
    public class crime_officer_in_danger { public static ScannerFile Anofficerindanger { get { return new ScannerFile("01_crime_officer_in_danger\\0x0E2B57AB.mp3", "An officer in danger.", "crime_officer_in_danger"); } } }
    public class crime_officer_in_need_of_assistance
    {
        public static ScannerFile Anofficerrequiringassistance { get { return new ScannerFile("01_crime_officer_in_need_of_assistance\\0x04B233C3.mp3", "An officer requiring assistance.", "crime_officer_in_need_of_assistance"); } }
        public static ScannerFile Anofficerinneedofassistance { get { return new ScannerFile("01_crime_officer_in_need_of_assistance\\0x1AA91FB1.mp3", "An officer in need of assistance.", "crime_officer_in_need_of_assistance"); } }
    }
    //public class crime_officer_on_fire
    //{
    //    public static ScannerFile Anofficeronfire { get { return new ScannerFile("01_crime_officer_on_fire\\0x0D64C020.mp3", "An officer on fire.", "crime_officer_on_fire"); } }
    //    public static ScannerFile Anofficersetonfire { get { return new ScannerFile("01_crime_officer_on_fire\\0x1FADA4B3.mp3", "An officer set on fire.", "crime_officer_on_fire"); } }
    //}
    //public class crime_officer_stabbed { public static ScannerFile Anofficerstabbed { get { return new ScannerFile("01_crime_officer_stabbed\\0x16DAE516.mp3", "An officer stabbed.", "crime_officer_stabbed"); } } }
    //public class crime_officer_struck_by_vehicle
    //{
    //    public static ScannerFile Anofficerstruckbyavehicle { get { return new ScannerFile("01_crime_officer_struck_by_vehicle\\0x05861C4A.mp3", "An officer struck by a vehicle.", "crime_officer_struck_by_vehicle"); } }
    //    public static ScannerFile Apedestrianstruckbyavehicle { get { return new ScannerFile("01_crime_officer_struck_by_vehicle\\0x0F91B046.mp3", "A pedestrian struck by a vehicle.", "crime_officer_struck_by_vehicle"); } }
    //}
    //public class crime_officer_wounded { public static ScannerFile Anofficerwounded { get { return new ScannerFile("01_crime_officer_wounded\\0x15E81134.mp3", "An officer wounded.", "crime_officer_wounded"); } } }
    //public class crime_pedestrian_involved_accident { public static ScannerFile Apedestrianinvolvedaccident { get { return new ScannerFile("01_crime_pedestrian_involved_accident\\0x1933F786.mp3", "A pedestrian-involved accident.", "crime_pedestrian_involved_accident"); } } }
    public class crime_ped_struck_by_veh
    {
        public static ScannerFile Apedestrianstruck { get { return new ScannerFile("01_crime_ped_struck_by_veh\\0x0366CCA6.mp3", "A pedestrian struck.", "crime_ped_struck_by_veh"); } }
        public static ScannerFile Apedestrianstruckbyavehicle { get { return new ScannerFile("01_crime_ped_struck_by_veh\\0x071DD422.mp3", "A pedestrian struck by a vehicle.", "crime_ped_struck_by_veh"); } }
        public static ScannerFile Apedestrianstruckbyavehicle1 { get { return new ScannerFile("01_crime_ped_struck_by_veh\\0x0BB09D49.mp3", "A pedestrian struck by a vehicle.", "crime_ped_struck_by_veh"); } }
        public static ScannerFile Apedestrianstruck1 { get { return new ScannerFile("01_crime_ped_struck_by_veh\\0x1AD73B96.mp3", "A pedestrian struck.", "crime_ped_struck_by_veh"); } }
    }
    //public class crime_person_attempting_to_steal_a_car { public static ScannerFile Apersonattemptingtostealacar { get { return new ScannerFile("01_crime_person_attempting_to_steal_a_car\\0x0EA0B0C9.mp3", "A person attempting to steal a car.", "crime_person_attempting_to_steal_a_car"); } } }
    //public class crime_person_down { public static ScannerFile Apersondown { get { return new ScannerFile("01_crime_person_down\\0x084DB426.mp3", "A person down.", "crime_person_down"); } } }
    //public class crime_person_fleeing_a_crime_scene { public static ScannerFile Apersonfleeingacrimescene { get { return new ScannerFile("01_crime_person_fleeing_a_crime_scene\\0x13FA7AA2.mp3", "A person fleeing a crime scene.", "crime_person_fleeing_a_crime_scene"); } } }
    public class crime_person_in_a_stolen_car { public static ScannerFile Apersoninastolencar { get { return new ScannerFile("01_crime_person_in_a_stolen_car\\0x06ECE5BE.mp3", "A person in a stolen car.", "crime_person_in_a_stolen_car"); } } }
    public class crime_person_in_a_stolen_vehicle { public static ScannerFile Apersoninastolenvehicle { get { return new ScannerFile("01_crime_person_in_a_stolen_vehicle\\0x0C290C9F.mp3", "A person in a stolen vehicle.", "crime_person_in_a_stolen_vehicle"); } } }
    public class crime_person_resisting_arrest { public static ScannerFile Apersonresistingarrest { get { return new ScannerFile("01_crime_person_resisting_arrest\\0x04A12B61.mp3", "A person resisting arrest.", "crime_person_resisting_arrest"); } } }
    public class crime_person_running_a_red_light { public static ScannerFile Apersonrunningaredlight { get { return new ScannerFile("01_crime_person_running_a_red_light\\0x0BFCA53A.mp3", "A person running a red light.", "crime_person_running_a_red_light"); } } }
    //public class crime_person_stealing_a_car { public static ScannerFile Apersonstealingacar { get { return new ScannerFile("01_crime_person_stealing_a_car\\0x03CBA5DC.mp3", "A person stealing a car.", "crime_person_stealing_a_car"); } } }
    //public class crime_person_transporting_narcotics { public static ScannerFile Apersonorpersonstransportingnarcotics { get { return new ScannerFile("01_crime_person_transporting_narcotics\\0x02CFBABE.mp3", "A person or persons transporting narcotics.", "crime_person_transporting_narcotics"); } } }
    //public class crime_perverting_justice
    //{
    //    public static ScannerFile Acivilianpervertingthecourseofjustice { get { return new ScannerFile("01_crime_perverting_justice\\0x08AFAEFF.mp3", "A civilian perverting the course of justice.", "crime_perverting_justice"); } }
    //    public static ScannerFile Obstructionofanofficer { get { return new ScannerFile("01_crime_perverting_justice\\0x15400820.mp3", "Obstruction of an officer.", "crime_perverting_justice"); } }
    //}
    //public class crime_pimping_and_solicitation { public static ScannerFile Pimpingandsolicitation { get { return new ScannerFile("01_crime_pimping_and_solicitation\\0x1436A1CD.mp3", "Pimping and solicitation.", "crime_pimping_and_solicitation"); } } }
    //public class crime_police_convoy_under_attack
    //{
    //    public static ScannerFile Apolicetransportunderattack { get { return new ScannerFile("01_crime_police_convoy_under_attack\\0x0831006A.mp3", "A police transport under attack.", "crime_police_convoy_under_attack"); } }
    //    public static ScannerFile Apoliceconvoyunderattack { get { return new ScannerFile("01_crime_police_convoy_under_attack\\0x1A6FA4E7.mp3", "A police convoy under attack.", "crime_police_convoy_under_attack"); } }
    //}
    //public class crime_property_damage
    //{
    //    public static ScannerFile Damagetoproperty { get { return new ScannerFile("01_crime_property_damage\\0x009DAE97.mp3", "Damage to property.", "crime_property_damage"); } }
    //    public static ScannerFile Propertydamage { get { return new ScannerFile("01_crime_property_damage\\0x020A316D.mp3", "Property damage.", "crime_property_damage"); } }
    //    public static ScannerFile Areportofpropertydamage { get { return new ScannerFile("01_crime_property_damage\\0x13A2949E.mp3", "A report of property damage.", "crime_property_damage"); } }
    //}
    //public class crime_prowler { public static ScannerFile Aprowler { get { return new ScannerFile("01_crime_prowler\\0x05EF2A48.mp3", "A prowler.", "crime_prowler"); } } }
    public class crime_reckless_driver { public static ScannerFile Arecklessdriver { get { return new ScannerFile("01_crime_reckless_driver\\0x06F0317A.mp3", "A reckless driver.", "crime_reckless_driver"); } } }
    //public class crime_road_blockade
    //{
    //    public static ScannerFile Aroadwayblocked { get { return new ScannerFile("01_crime_road_blockade\\0x01CE4B75.mp3", "A roadway blocked.", "crime_road_blockade"); } }
    //    public static ScannerFile Aroadblockade { get { return new ScannerFile("01_crime_road_blockade\\0x0B3C5E40.mp3", "A road blockade.", "crime_road_blockade"); } }
    //    public static ScannerFile Aroadblock { get { return new ScannerFile("01_crime_road_blockade\\0x1D348242.mp3", "A roadblock.", "crime_road_blockade"); } }
    //}
    public class crime_robbery
    {
        public static ScannerFile Arobbery { get { return new ScannerFile("01_crime_robbery\\0x0A677E12.mp3", "A robbery.", "crime_robbery"); } }
        public static ScannerFile Apossiblerobbery { get { return new ScannerFile("01_crime_robbery\\0x149A5278.mp3", "A possible robbery.", "crime_robbery"); } }
    }
    public class crime_robbery_with_a_firearm { public static ScannerFile Arobberywithafirearm { get { return new ScannerFile("01_crime_robbery_with_a_firearm\\0x146F5EF1.mp3", "A robbery with a firearm.", "crime_robbery_with_a_firearm"); } } }
    public class crime_shooting
    {
        public static ScannerFile Aweaponsincidentshotsfired { get { return new ScannerFile("01_crime_shooting\\0x01AC508D.mp3", "A weapons incident; shots fired.", "crime_shooting"); } }
        public static ScannerFile Afirearmssituationseveralshotsfired { get { return new ScannerFile("01_crime_shooting\\0x1F5D8BEF.mp3", "A firearms situation; several shots fired.", "crime_shooting"); } }
    }
    //public class crime_shooting_at_animals { public static ScannerFile Personshootingatanimals { get { return new ScannerFile("01_crime_shooting_at_animals\\0x0EC4903B.mp3", "Person shooting at animals.", "crime_shooting_at_animals"); } } }
    //public class crime_shooting_a_protected_bird
    //{
    //    public static ScannerFile Reportsofsuspectshootingaprotectedbird { get { return new ScannerFile("01_crime_shooting_a_protected_bird\\0x0CBF96A2.mp3", "Reports of suspect shooting a protected bird.", "crime_shooting_a_protected_bird"); } }
    //    public static ScannerFile Suspectshootingaprotectedbird { get { return new ScannerFile("01_crime_shooting_a_protected_bird\\0x195A6FDB.mp3", "Suspect shooting a protected bird.", "crime_shooting_a_protected_bird"); } }
    //    public static ScannerFile Reportsofsomeoneshootingaprotectedbird { get { return new ScannerFile("01_crime_shooting_a_protected_bird\\0x1A94324F.mp3", "Reports of someone shooting a protected bird.", "crime_shooting_a_protected_bird"); } }
    //}
    //public class crime_shooting_wildlife { public static ScannerFile Suspectshootingwildlife { get { return new ScannerFile("01_crime_shooting_wildlife\\0x03E5D09E.mp3", "Suspect shooting wildlife.", "crime_shooting_wildlife"); } } }
    public class crime_shoot_out { public static ScannerFile Ashootout { get { return new ScannerFile("01_crime_shoot_out\\0x09B682AC.mp3", "A shoot-out.", "crime_shoot_out"); } } }
    //public class crime_shots_fired
    //{
    //    public static ScannerFile Shotsfired { get { return new ScannerFile("01_crime_shots_fired\\0x0EADE575.mp3", "Shots fired.", "crime_shots_fired"); } }
    //    public static ScannerFile Gunfirereported { get { return new ScannerFile("01_crime_shots_fired\\0x1A7C3D10.mp3", "Gunfire reported.", "crime_shots_fired"); } }
    //    public static ScannerFile Gunshotsreported { get { return new ScannerFile("01_crime_shots_fired\\0x1D3E4296.mp3", "Gunshots reported.", "crime_shots_fired"); } }
    //}
    public class crime_shots_fired_at_an_officer { public static ScannerFile Shotsfiredatanofficer { get { return new ScannerFile("01_crime_shots_fired_at_an_officer\\0x0B6ECE66.mp3", "Shots fired at an officer.", "crime_shots_fired_at_an_officer"); } } }
    public class crime_shots_fired_at_officer
    {
        public static ScannerFile Anofficershot { get { return new ScannerFile("01_crime_shots_fired_at_officer\\0x0237C6BB.mp3", "An officer shot.", "crime_shots_fired_at_officer"); } }
        public static ScannerFile Shotsfiredatanofficer { get { return new ScannerFile("01_crime_shots_fired_at_officer\\0x06D48FF4.mp3", "Shots fired at an officer.", "crime_shots_fired_at_officer"); } }
        public static ScannerFile Anofficerunderfire { get { return new ScannerFile("01_crime_shots_fired_at_officer\\0x0802D252.mp3", "An officer under fire.", "crime_shots_fired_at_officer"); } }
        public static ScannerFile Afirearmattackonanofficer { get { return new ScannerFile("01_crime_shots_fired_at_officer\\0x0C669B19.mp3", "A firearm attack on an officer.", "crime_shots_fired_at_officer"); } }
    }
   // public class crime_solicitation { public static ScannerFile Solicitation { get { return new ScannerFile("01_crime_solicitation\\0x0DFDDC04.mp3", "Solicitation.", "crime_solicitation"); } } }
    //public class crime_sos_call
    //{
    //    public static ScannerFile AnSOScall { get { return new ScannerFile("01_crime_sos_call\\0x04F36BF2.mp3", "An SOS call.", "crime_sos_call"); } }
    //    public static ScannerFile AnSOSdistresssignal { get { return new ScannerFile("01_crime_sos_call\\0x123D0686.mp3", "An SOS distress signal.", "crime_sos_call"); } }
    //}
    public class crime_speeding { public static ScannerFile Speeding { get { return new ScannerFile("01_crime_speeding\\0x1C912AD5.mp3", "Speeding.", "crime_speeding"); } } }
    public class crime_speeding_felony { public static ScannerFile Aspeedingfelony { get { return new ScannerFile("01_crime_speeding_felony\\0x01C16921.mp3", "A speeding felony.", "crime_speeding_felony"); } } }
    public class crime_speeding_incident { public static ScannerFile Aspeedingincident { get { return new ScannerFile("01_crime_speeding_incident\\0x00BA5D8E.mp3", "A speeding incident.", "crime_speeding_incident"); } } }
    //public class crime_stabbing
    //{
    //    public static ScannerFile Apossiblestabbing { get { return new ScannerFile("01_crime_stabbing\\0x10112C89.mp3", "A possible stabbing.", "crime_stabbing"); } }
    //    public static ScannerFile Astabbing { get { return new ScannerFile("01_crime_stabbing\\0x1280B178.mp3", "A stabbing.", "crime_stabbing"); } }
    //    public static ScannerFile Astabbing1 { get { return new ScannerFile("01_crime_stabbing\\0x1DDB481E.mp3", "A stabbing.", "crime_stabbing"); } }
    //}
    public class crime_stolen_aircraft { public static ScannerFile Astolenaircraft { get { return new ScannerFile("01_crime_stolen_aircraft\\0x11D9B7A5.mp3", "A stolen aircraft.", "crime_stolen_aircraft"); } } }
    public class crime_stolen_cop_car
    {
        public static ScannerFile Astolenpolicecar { get { return new ScannerFile("01_crime_stolen_cop_car\\0x00EA9A63.mp3", "A stolen police car.", "crime_stolen_cop_car"); } }
        public static ScannerFile Astolenpolicevehicle { get { return new ScannerFile("01_crime_stolen_cop_car\\0x063C24EB.mp3", "A stolen police vehicle.", "crime_stolen_cop_car"); } }
        public static ScannerFile Astolenpolicevehicle1 { get { return new ScannerFile("01_crime_stolen_cop_car\\0x073466F5.mp3", "A stolen police vehicle.", "crime_stolen_cop_car"); } }
        public static ScannerFile Defectivepolicevehicle { get { return new ScannerFile("01_crime_stolen_cop_car\\0x0FEBF849.mp3", "Defective police vehicle.", "crime_stolen_cop_car"); } }
    }
   // public class crime_stolen_helicopter { public static ScannerFile Astolenhelicopter { get { return new ScannerFile("01_crime_stolen_helicopter\\0x1D5AF1B0.mp3", "A stolen helicopter.", "crime_stolen_helicopter"); } } }
    public class crime_stolen_vehicle { public static ScannerFile Apossiblestolenvehicle { get { return new ScannerFile("01_crime_stolen_vehicle\\0x09CEE854.mp3", "A possible stolen vehicle.", "crime_stolen_vehicle"); } } }
    //public class crime_structure_on_fire
    //{
    //    public static ScannerFile Astructureonfire { get { return new ScannerFile("01_crime_structure_on_fire\\0x067D94A5.mp3", "A structure on fire.", "crime_structure_on_fire"); } }
    //    public static ScannerFile Astructureonfire1 { get { return new ScannerFile("01_crime_structure_on_fire\\0x1E35841E.mp3", "A structure on fire.", "crime_structure_on_fire"); } }
    //}
    public class crime_suspect_armed_and_dangerous { public static ScannerFile Asuspectarmedanddangerous { get { return new ScannerFile("01_crime_suspect_armed_and_dangerous\\0x08E2DF46.mp3", "A suspect...armed and dangerous.", "crime_suspect_armed_and_dangerous"); } } }
    public class crime_suspect_resisting_arrest { public static ScannerFile Asuspectresistingarrest { get { return new ScannerFile("01_crime_suspect_resisting_arrest\\0x04DE3185.mp3", "A suspect resisting arrest.", "crime_suspect_resisting_arrest"); } } }
    public class crime_suspect_threatening_an_officer_with_a_firearm { public static ScannerFile Asuspectthreateninganofficerwithafirearm { get { return new ScannerFile("01_crime_suspect_threatening_an_officer_with_a_firearm\\0x05A09EE6.mp3", "A suspect threatening an officer with a firearm.", "crime_suspect_threatening_an_officer_with_a_firearm"); } } }
    public class crime_suspicious_activity { public static ScannerFile Suspiciousactivity { get { return new ScannerFile("01_crime_suspicious_activity\\0x092DAC4A.mp3", "Suspicious activity.", "crime_suspicious_activity"); } } }
    public class crime_suspicious_offshore_activity { public static ScannerFile Suspiciousoffshoreactivity { get { return new ScannerFile("01_crime_suspicious_offshore_activity\\0x1891C188.mp3", "Suspicious offshore activity.", "crime_suspicious_offshore_activity"); } } }
    public class crime_suspicious_persons_loitering { public static ScannerFile Agroupofsuspiciouspersonsloitering { get { return new ScannerFile("01_crime_suspicious_persons_loitering\\0x14C10DE0.mp3", "A group of suspicious persons loitering.", "crime_suspicious_persons_loitering"); } } }
    public class crime_suspicious_vehicle { public static ScannerFile Asuspiciousvehicle { get { return new ScannerFile("01_crime_suspicious_vehicle\\0x08C22EB1.mp3", "A suspicious vehicle.", "crime_suspicious_vehicle"); } } }
    public class crime_terrorist_activity
    {
        public static ScannerFile Possibleterroristactivity { get { return new ScannerFile("01_crime_terrorist_activity\\0x01AD7615.mp3", "Possible terrorist activity.", "crime_terrorist_activity"); } }
        public static ScannerFile Possibleterroristactivity1 { get { return new ScannerFile("01_crime_terrorist_activity\\0x0B7D09B8.mp3", "Possible terrorist activity.", "crime_terrorist_activity"); } }
        public static ScannerFile Terroristactivity { get { return new ScannerFile("01_crime_terrorist_activity\\0x117ED5B8.mp3", "Terrorist activity.", "crime_terrorist_activity"); } }
        public static ScannerFile Possibleterroristactivity2 { get { return new ScannerFile("01_crime_terrorist_activity\\0x1C8DABD5.mp3", "Possible terrorist activity.", "crime_terrorist_activity"); } }
    }
    public class crime_theft { public static ScannerFile Apossibletheft { get { return new ScannerFile("01_crime_theft\\0x0536E1CD.mp3", "A possible theft.", "crime_theft"); } } }
    public class crime_theft_of_an_aircraft { public static ScannerFile Theftofanaircraft { get { return new ScannerFile("01_crime_theft_of_an_aircraft\\0x045DD97F.mp3", "Theft of an aircraft.", "crime_theft_of_an_aircraft"); } } }
    //public class crime_torturing_an_animal { public static ScannerFile Persontorturingananimal { get { return new ScannerFile("01_crime_torturing_an_animal\\0x0BB248B5.mp3", "Person torturing an animal.", "crime_torturing_an_animal"); } } }
    //public class crime_traffic_alert { public static ScannerFile Atrafficalert { get { return new ScannerFile("01_crime_traffic_alert\\0x1C20369B.mp3", "A traffic alert.", "crime_traffic_alert"); } } }
    //public class crime_traffic_felony { public static ScannerFile Atrafficfelony { get { return new ScannerFile("01_crime_traffic_felony\\0x19F600A8.mp3", "A traffic felony.", "crime_traffic_felony"); } } }
    //public class crime_traffic_violation { public static ScannerFile Atrafficviolation { get { return new ScannerFile("01_crime_traffic_violation\\0x10D7F5BC.mp3", "A traffic violation.", "crime_traffic_violation"); } } }
    //public class crime_transporting_narcotics { public static ScannerFile Apersonorpersonstransportingnarcotics { get { return new ScannerFile("01_crime_transporting_narcotics\\0x0CA3A65C.mp3", "A person or persons transporting narcotics.", "crime_transporting_narcotics"); } } }
    public class crime_trespassing
    {
        public static ScannerFile Trespassing { get { return new ScannerFile("01_crime_trespassing\\0x05C3CC3B.mp3", "Trespassing.", "crime_trespassing"); } }
        public static ScannerFile Possibletrespassing { get { return new ScannerFile("01_crime_trespassing\\0x1071E197.mp3", "Possible trespassing.", "crime_trespassing"); } }
    }
    public class crime_trespassing_on_government_property { public static ScannerFile Trespassingongovernmentproperty { get { return new ScannerFile("01_crime_trespassing_on_government_property\\0x11228580.mp3", "Trespassing on government property.", "crime_trespassing_on_government_property"); } } }
    //public class crime_unauthorized_hunting { public static ScannerFile Unauthorizedhunting { get { return new ScannerFile("01_crime_unauthorized_hunting\\0x0D93CE7F.mp3", "Unauthorized hunting.", "crime_unauthorized_hunting"); } } }
    public class crime_unconscious_civilian { public static ScannerFile Anunconsciouscivilian { get { return new ScannerFile("01_crime_unconscious_civilian\\0x0839AE65.mp3", "An unconscious civilian.", "crime_unconscious_civilian"); } } }
    //public class crime_unconscious_female { public static ScannerFile Anunconsciousfemale { get { return new ScannerFile("01_crime_unconscious_female\\0x19D87B01.mp3", "An unconscious female.", "crime_unconscious_female"); } } }
    //public class crime_unconscious_male { public static ScannerFile Anunconsciousmale { get { return new ScannerFile("01_crime_unconscious_male\\0x106D54AF.mp3", "An unconscious male.", "crime_unconscious_male"); } } }
    //public class crime_unit_under_fire { public static ScannerFile Aunitunderfire { get { return new ScannerFile("01_crime_unit_under_fire\\0x1EC3B6A6.mp3", "A unit under fire.", "crime_unit_under_fire"); } } }
    //public class crime_vehicle_explosion { public static ScannerFile Avehicleexplosion { get { return new ScannerFile("01_crime_vehicle_explosion\\0x00ACF28E.mp3", "A vehicle explosion.", "crime_vehicle_explosion"); } } }
    public class crime_vehicle_on_fire { public static ScannerFile Avehicleonfire { get { return new ScannerFile("01_crime_vehicle_on_fire\\0x0CF82D90.mp3", "A vehicle on fire.", "crime_vehicle_on_fire"); } } }
    //public class crime_vehicle_theft { public static ScannerFile Avehicletheft { get { return new ScannerFile("01_crime_vehicle_theft\\0x126934E4.mp3", "A vehicle theft.", "crime_vehicle_theft"); } } }
    //public class crime_vehicular_homicide { public static ScannerFile Avehicularhomicide { get { return new ScannerFile("01_crime_vehicular_homicide\\0x08687686.mp3", "A vehicular homicide.", "crime_vehicular_homicide"); } } }
    //public class crime_vessel_in_distress { public static ScannerFile Avesselindistress { get { return new ScannerFile("01_crime_vessel_in_distress\\0x0FE8B7D8.mp3", "A vessel in distress.", "crime_vessel_in_distress"); } } }
    //public class crime_vicious_animal
    //{
    //    public static ScannerFile Aviciousanimalontheloose { get { return new ScannerFile("01_crime_vicious_animal\\0x00029C1B.mp3", "A vicious animal on the loose.", "crime_vicious_animal"); } }
    //    public static ScannerFile Aviciousanimal { get { return new ScannerFile("01_crime_vicious_animal\\0x03A4A365.mp3", "A vicious animal.", "crime_vicious_animal"); } }
    //}
    //public class crime_violation_of_a_non_kill_order { public static ScannerFile Violationofanonkillorder { get { return new ScannerFile("01_crime_violation_of_a_non_kill_order\\0x0FCF6888.mp3", "Violation of a non-kill order.", "crime_violation_of_a_non_kill_order"); } } }
    //public class crime_violation_of_a_no_kill_order
    //{
    //    public static ScannerFile Violationofanokillmandate { get { return new ScannerFile("01_crime_violation_of_a_no_kill_order\\0x09EE350E.mp3", "Violation of a no-kill mandate.", "crime_violation_of_a_no_kill_order"); } }
    //    public static ScannerFile Violationofanokillorder { get { return new ScannerFile("01_crime_violation_of_a_no_kill_order\\0x183F91B1.mp3", "Violation of a no-kill order.", "crime_violation_of_a_no_kill_order"); } }
    //}
    public class crime_wanted_felon_on_the_loose { public static ScannerFile Awantedfelonontheloose { get { return new ScannerFile("01_crime_wanted_felon_on_the_loose\\0x17CA8289.mp3", "A wanted felon on the loose.", "crime_wanted_felon_on_the_loose"); } } }
    //public class crime_warrant_issued { public static ScannerFile Awarrantissued { get { return new ScannerFile("01_crime_warrant_issued\\0x09926678.mp3", "A warrant issued.", "crime_warrant_issued"); } } }
    //public class crooks_arrested
    //{
    //    public static ScannerFile Multiplesuspectsarrested { get { return new ScannerFile("01_crooks_arrested\\0x03169622.mp3", "Multiple suspects arrested.", "crooks_arrested"); } }
    //    public static ScannerFile Officershaveapprehendedallsuspects { get { return new ScannerFile("01_crooks_arrested\\0x07A25F39.mp3", "Officers have apprehended all suspects.", "crooks_arrested"); } }
    //    public static ScannerFile Suspectsincustody { get { return new ScannerFile("01_crooks_arrested\\0x0C75E8E3.mp3", "Suspects in custody.", "crooks_arrested"); } }
    //    public static ScannerFile Officershaveapprehendedmultiplesuspects { get { return new ScannerFile("01_crooks_arrested\\0x10166FB6.mp3", "Officers have apprehended multiple suspects.", "crooks_arrested"); } }
    //    public static ScannerFile Unitshavesuspectsincustody { get { return new ScannerFile("01_crooks_arrested\\0x139936BB.mp3", "Units have suspects in custody.", "crooks_arrested"); } }
    //    public static ScannerFile Suspectsincustody1 { get { return new ScannerFile("01_crooks_arrested\\0x151DBA30.mp3", "Suspects in custody.", "crooks_arrested"); } }
    //    public static ScannerFile Multiplesuspectsincustody { get { return new ScannerFile("01_crooks_arrested\\0x19D883A9.mp3", "Multiple suspects in custody.", "crooks_arrested"); } }
    //    public static ScannerFile Suspectsare1015 { get { return new ScannerFile("01_crooks_arrested\\0x1CFC0672.mp3", "Suspects are 10-15.", "crooks_arrested"); } }
    //    public static ScannerFile Unitshaveapprehendedsuspects { get { return new ScannerFile("01_crooks_arrested\\0x1E69CC5D.mp3", "Units have apprehended suspects.", "crooks_arrested"); } }
    //    public static ScannerFile Suspectsapprehended { get { return new ScannerFile("01_crooks_arrested\\0x1EC68D84.mp3", "Suspects apprehended.", "crooks_arrested"); } }
    //}
    //public class crooks_escaped
    //{
    //    public static ScannerFile Suspectshaveevadedpursuit { get { return new ScannerFile("01_crooks_escaped\\0x062BA4E6.mp3", "Suspects have evaded pursuit.", "crooks_escaped"); } }
    //    public static ScannerFile Suspectsevadedofficers { get { return new ScannerFile("01_crooks_escaped\\0x0B21EED1.mp3", "Suspects evaded officers.", "crooks_escaped"); } }
    //    public static ScannerFile Targetshaveevadedcapture { get { return new ScannerFile("01_crooks_escaped\\0x11987BBF.mp3", "Targets have evaded capture.", "crooks_escaped"); } }
    //    public static ScannerFile Criminalshaveevadedpursuit { get { return new ScannerFile("01_crooks_escaped\\0x14430115.mp3", "Criminals have evaded pursuit.", "crooks_escaped"); } }
    //    public static ScannerFile Targetsevadedpursuingofficers { get { return new ScannerFile("01_crooks_escaped\\0x18F84A7E.mp3", "Targets evaded pursuing officers.", "crooks_escaped"); } }
    //    public static ScannerFile Suspectslost { get { return new ScannerFile("01_crooks_escaped\\0x1FAF17EC.mp3", "Suspects lost.", "crooks_escaped"); } }
    //    public static ScannerFile Suspectshaveeludedofficers { get { return new ScannerFile("01_crooks_escaped\\0x1FE8D860.mp3", "Suspects have eluded officers.", "crooks_escaped"); } }
    //}
    //public class crooks_killed
    //{
    //    public static ScannerFile Unitshaveneutralizedsuspects { get { return new ScannerFile("01_crooks_killed\\0x065E8858.mp3", "Units have neutralized suspects.", "crooks_killed"); } }
    //    public static ScannerFile Suspectsneutralized { get { return new ScannerFile("01_crooks_killed\\0x083B4D1C.mp3", "Suspects neutralized.", "crooks_killed"); } }
    //    public static ScannerFile Suspectsdown { get { return new ScannerFile("01_crooks_killed\\0x0F5A9A4F.mp3", "Suspects down.", "crooks_killed"); } }
    //    public static ScannerFile Officershavepacifiedsuspects { get { return new ScannerFile("01_crooks_killed\\0x11ADDEF5.mp3", "Officers have pacified suspects.", "crooks_killed"); } }
    //    public static ScannerFile Suspectspacified { get { return new ScannerFile("01_crooks_killed\\0x11FE60A2.mp3", "Suspects pacified.", "crooks_killed"); } }
    //    public static ScannerFile Unitshavepacifiedsuspects { get { return new ScannerFile("01_crooks_killed\\0x1BDB3351.mp3", "Units have pacified suspects.", "crooks_killed"); } }
    //    public static ScannerFile Officershaveneutralizedsuspects { get { return new ScannerFile("01_crooks_killed\\0x1F707A7A.mp3", "Officers have neutralized suspects.", "crooks_killed"); } }
    //}
    public class crook_arrested
    {
        public static ScannerFile Asuspectincustody { get { return new ScannerFile("01_crook_arrested\\0x02B3621C.mp3", "A suspect in custody.", "crook_arrested"); } }
        public static ScannerFile Suspectis1015 { get { return new ScannerFile("01_crook_arrested\\0x04D9A179.mp3", "Suspect is 10-15.", "crook_arrested"); } }
        public static ScannerFile Officershaveapprehendedsuspect { get { return new ScannerFile("01_crook_arrested\\0x0829E81B.mp3", "Officers have apprehended suspect.", "crook_arrested"); } }
        public static ScannerFile Suspectplaceunderarrest { get { return new ScannerFile("01_crook_arrested\\0x0A696B9D.mp3", "Suspect place under arrest.", "crook_arrested"); } }
        public static ScannerFile Asuspectarrested { get { return new ScannerFile("01_crook_arrested\\0x0BC9F44A.mp3", "A suspect arrested.", "crook_arrested"); } }
        public static ScannerFile Suspectapprehended { get { return new ScannerFile("01_crook_arrested\\0x0CC1715C.mp3", "Suspect apprehended.", "crook_arrested"); } }
        public static ScannerFile Suspectincustody { get { return new ScannerFile("01_crook_arrested\\0x0DC8B356.mp3", "Suspect in custody.", "crook_arrested"); } }
        public static ScannerFile suspectincustody1015 { get { return new ScannerFile("01_crook_arrested\\0x11D3FB6C.mp3", "10-15; suspect in custody.", "crook_arrested"); } }
        public static ScannerFile Asuspectapprehended { get { return new ScannerFile("01_crook_arrested\\0x13C98449.mp3", "A suspect apprehended.", "crook_arrested"); } }
        public static ScannerFile Officershaveapprehendedsuspect1 { get { return new ScannerFile("01_crook_arrested\\0x170FC5E7.mp3", "Officers have apprehended suspect.", "crook_arrested"); } }
        public static ScannerFile Unitshavesuspectincustody { get { return new ScannerFile("01_crook_arrested\\0x171345EC.mp3", "Units have suspect in custody.", "crook_arrested"); } }
        public static ScannerFile Asuspectincustody1 { get { return new ScannerFile("01_crook_arrested\\0x1729CB0B.mp3", "A suspect in custody.", "crook_arrested"); } }
        public static ScannerFile suspectapprehended1015 { get { return new ScannerFile("01_crook_arrested\\0x17BB4641.mp3", "10-15; suspect apprehended.", "crook_arrested"); } }
        public static ScannerFile Asuspect10151 { get { return new ScannerFile("01_crook_arrested\\0x18EE4E92.mp3", "A suspect 10-15.", "crook_arrested"); } }
        public static ScannerFile Suspectarrested1 { get { return new ScannerFile("01_crook_arrested\\0x1A818CC8.mp3", "Suspect arrested.", "crook_arrested"); } }
        public static ScannerFile Suspectapprehended1 { get { return new ScannerFile("01_crook_arrested\\0x1B044DE2.mp3", "Suspect apprehended.", "crook_arrested"); } }
        public static ScannerFile Asuspectplacedunderarrest { get { return new ScannerFile("01_crook_arrested\\0x1D74179F.mp3", "A suspect placed under arrest.", "crook_arrested"); } }
    }
    public class crook_killed
    {
        public static ScannerFile Suspectdown { get { return new ScannerFile("01_crook_killed\\0x0269B41C.mp3", "Suspect down.", "crook_killed"); } }
        public static ScannerFile Asuspectdown { get { return new ScannerFile("01_crook_killed\\0x03FCE3D3.mp3", "A suspect down.", "crook_killed"); } }
        public static ScannerFile Suspectdowncoronerenroute { get { return new ScannerFile("01_crook_killed\\0x064FBBE9.mp3", "Suspect down; coroner en route.", "crook_killed"); } }
        public static ScannerFile Asuspectdown1 { get { return new ScannerFile("01_crook_killed\\0x0A22B024.mp3", "A suspect down.", "crook_killed"); } }
        public static ScannerFile Criminaldown { get { return new ScannerFile("01_crook_killed\\0x0B868657.mp3", "Criminal down.", "crook_killed"); } }
        public static ScannerFile Asuspectdown2 { get { return new ScannerFile("01_crook_killed\\0x0D96770A.mp3", "A suspect down.", "crook_killed"); } }
        public static ScannerFile Suspectneutralized { get { return new ScannerFile("01_crook_killed\\0x10088F5D.mp3", "Suspect neutralized.", "crook_killed"); } }
        public static ScannerFile Suspectdownmedicalexaminerenroute { get { return new ScannerFile("01_crook_killed\\0x14FC5942.mp3", "Suspect down; medical examiner en route.", "crook_killed"); } }
        public static ScannerFile Acriminaldown { get { return new ScannerFile("01_crook_killed\\0x1C44D467.mp3", "A criminal down.", "crook_killed"); } }
        public static ScannerFile Officershavepacifiedsuspect { get { return new ScannerFile("01_crook_killed\\0x1E57EBF8.mp3", "Officers have pacified suspect.", "crook_killed"); } }
    }
    //public class custom_player_flow
    //{
    //    public static ScannerFile WantedinconnectionwiththeRichmanJewelryStoreHeist { get { return new ScannerFile("01_custom_player_flow\\0x005719B7.mp3", "Wanted in connection with theRichman Jewelry Store Heist.", "custom_player_flow"); } }
    //    public static ScannerFile WantedinconnectionwiththeRobberyofthePaletoBayBank { get { return new ScannerFile("01_custom_player_flow\\0x018DF534.mp3", "Wanted in connection with theRobbery of the Paleto Bay Bank.", "custom_player_flow"); } }
    //    public static ScannerFile OfficersreportsightingofTrevorPhilips { get { return new ScannerFile("01_custom_player_flow\\0x01A271E2.mp3", "Officers report sighting of Trevor Philips.", "custom_player_flow"); } }
    //    public static ScannerFile SuspectisFranklinClinton { get { return new ScannerFile("01_custom_player_flow\\0x02D9EA4C.mp3", "Suspect is Franklin Clinton.", "custom_player_flow"); } }
    //    public static ScannerFile WantedforquestioningabouttheHumaneLabsRobbery { get { return new ScannerFile("01_custom_player_flow\\0x076EFD5F.mp3", "Wanted for questioning about theHumane Labs Robbery.", "custom_player_flow"); } }
    //    public static ScannerFile FornumerousviolationsinthemiddleLosSantosarea { get { return new ScannerFile("01_custom_player_flow\\0x079A4471.mp3", "For numerous violations in the middle(?) Los Santos area.", "custom_player_flow"); } }
    //    public static ScannerFile Attentionallunitssuspectisamiddleagedwhitemale { get { return new ScannerFile("01_custom_player_flow\\0x0C8FA2D3.mp3", "Attention all units, suspect is a middle-aged white male.", "custom_player_flow"); } }
    //    public static ScannerFile Suspectsarereportedtobethegroupwanted { get { return new ScannerFile("01_custom_player_flow\\0x10D916E2.mp3", "Suspects are reported to be the group wanted.", "custom_player_flow"); } }
    //    public static ScannerFile Wantedinconnectionwithmultiplehomicides { get { return new ScannerFile("01_custom_player_flow\\0x119211C1.mp3", "Wanted in connection with multiple homicides.", "custom_player_flow"); } }
    //    public static ScannerFile WantedforquestioningabouttheHumaneLabsRobbery1 { get { return new ScannerFile("01_custom_player_flow\\0x129809C9.mp3", "Wanted for questioning about theHumane Labs Robbery.", "custom_player_flow"); } }
    //    public static ScannerFile WantedinconnectionwiththeRichmanJewelryStoreHeist1 { get { return new ScannerFile("01_custom_player_flow\\0x1343B038.mp3", "Wanted in connection with theRichman Jewelry Store Heist.", "custom_player_flow"); } }
    //    public static ScannerFile Suspectisayoungafricanamericanmale { get { return new ScannerFile("01_custom_player_flow\\0x15BC99FA.mp3", "Suspect is a young, african-american male.", "custom_player_flow"); } }
    //    public static ScannerFile Officersreportsightingofaheavysetwhitemale { get { return new ScannerFile("01_custom_player_flow\\0x17EE21F7.mp3", "Officers report sighting of a heavyset white male.", "custom_player_flow"); } }
    //    public static ScannerFile AttentionallunitssuspectissupportedasMichaeldeSanto { get { return new ScannerFile("01_custom_player_flow\\0x1B360F7C.mp3", "Attention all units, suspect is supported as Michael de Santo.", "custom_player_flow"); } }
    //}
    public class custom_wanted_level_line
    {
        public static ScannerFile OfficersauthorizedtousetasersCodeTom { get { return new ScannerFile("01_custom_wanted_level_line\\0x00381DCD.mp3", "Officers authorized to use tasers; Code Tom.", "custom_wanted_level_line"); } }
        public static ScannerFile Officerdownairsupportenroute { get { return new ScannerFile("01_custom_wanted_level_line\\0x02484600.mp3", "Officer down; air support en route.", "custom_wanted_level_line"); } }
        public static ScannerFile Officerdownsituationiscode99 { get { return new ScannerFile("01_custom_wanted_level_line\\0x05180BA0.mp3", "Officer down; situation is code 99.", "custom_wanted_level_line"); } }
        public static ScannerFile Code99officersrequireimmediateassistance { get { return new ScannerFile("01_custom_wanted_level_line\\0x0849C003.mp3", "Code 99; officers require immediate assistance.", "custom_wanted_level_line"); } }
        public static ScannerFile HelicopterdownallDavidunitsonalert { get { return new ScannerFile("01_custom_wanted_level_line\\0x08B4DF2A.mp3", "Helicopter down, all David units on alert.", "custom_wanted_level_line"); } }
        public static ScannerFile Officersauthorizedtousetasers { get { return new ScannerFile("01_custom_wanted_level_line\\0x0E02B962.mp3", "Officers authorized to use tasers.", "custom_wanted_level_line"); } }
        public static ScannerFile Shotsfiredatanofficeruseoflethalforceisauthorized { get { return new ScannerFile("01_custom_wanted_level_line\\0x0EAD1ECA.mp3", "Shots fired at an officer, use of lethal force is authorized.", "custom_wanted_level_line"); } }
        public static ScannerFile Officersdownairsupportenroute { get { return new ScannerFile("01_custom_wanted_level_line\\0x1107E37F.mp3", "Officers down; air support en route.", "custom_wanted_level_line"); } }
        public static ScannerFile Wehavea1099allavailableunitsrespond { get { return new ScannerFile("01_custom_wanted_level_line\\0x12A7D458.mp3", "We have a 10-99, all available units respond.", "custom_wanted_level_line"); } }
        public static ScannerFile Code99allavailableunitsconvergeonsuspect { get { return new ScannerFile("01_custom_wanted_level_line\\0x14577671.mp3", "Code 99; all available units converge on suspect.", "custom_wanted_level_line"); } }
        public static ScannerFile Apprehendsuspectwithoutexcessiveforce { get { return new ScannerFile("01_custom_wanted_level_line\\0x1487C663.mp3", "Apprehend suspect without excessive force.", "custom_wanted_level_line"); } }
        public static ScannerFile Apprehendsuspectandreturntothestationforquestioning { get { return new ScannerFile("01_custom_wanted_level_line\\0x14C346E4.mp3", "Apprehend suspect and return to the station for questioning.", "custom_wanted_level_line"); } }
        public static ScannerFile HelicopterdownallavailableDavidunitsonalert { get { return new ScannerFile("01_custom_wanted_level_line\\0x196A0098.mp3", "Helicopter down, all available David units on alert.", "custom_wanted_level_line"); } }
        public static ScannerFile Suspectisarmedanddangerousweaponsfree { get { return new ScannerFile("01_custom_wanted_level_line\\0x1B146598.mp3", "Suspect is armed and dangerous; weapons free.", "custom_wanted_level_line"); } }
        public static ScannerFile Code13militaryunitsrequested { get { return new ScannerFile("01_custom_wanted_level_line\\0x1E4F9A87.mp3", "Code 13; military units requested.", "custom_wanted_level_line"); } }
    }
    //public class direction_bound
    //{
    //    public static ScannerFile Southbound { get { return new ScannerFile("01_direction_bound\\0x02F43627.mp3", "Southbound.", "direction_bound"); } }
    //    public static ScannerFile Westbound { get { return new ScannerFile("01_direction_bound\\0x089A1D9B.mp3", "Westbound.", "direction_bound"); } }
    //    public static ScannerFile Northbound { get { return new ScannerFile("01_direction_bound\\0x0F00AAE2.mp3", "Northbound.", "direction_bound"); } }
    //    public static ScannerFile Eastbound { get { return new ScannerFile("01_direction_bound\\0x15D27B32.mp3", "Eastbound.", "direction_bound"); } }
    //}
    public class direction_heading
    {
        public static ScannerFile South { get { return new ScannerFile("01_direction_heading\\0x0BB197C4.mp3", "South.", "direction_heading"); } }
        public static ScannerFile East { get { return new ScannerFile("01_direction_heading\\0x0E70541A.mp3", "East.", "direction_heading"); } }
        public static ScannerFile North { get { return new ScannerFile("01_direction_heading\\0x168FB5D8.mp3", "North.", "direction_heading"); } }
        public static ScannerFile West { get { return new ScannerFile("01_direction_heading\\0x1E1242F0.mp3", "West.", "direction_heading"); } }
    }
    //public class dispatch_custom_field_report_response
    //{
    //    public static ScannerFile copythat104 { get { return new ScannerFile("01_dispatch_custom_field_report_response\\0x01A472D4.mp3", "10-4, copy that.", "dispatch_custom_field_report_response"); } }
    //    public static ScannerFile Copythat1041 { get { return new ScannerFile("01_dispatch_custom_field_report_response\\0x06283BDB.mp3", "Copy that, 10-4.", "dispatch_custom_field_report_response"); } }
    //    public static ScannerFile Rogerthat { get { return new ScannerFile("01_dispatch_custom_field_report_response\\0x0DD40B1E.mp3", "Roger that.", "dispatch_custom_field_report_response"); } }
    //    public static ScannerFile Acknowledged { get { return new ScannerFile("01_dispatch_custom_field_report_response\\0x1356D639.mp3", "Acknowledged.", "dispatch_custom_field_report_response"); } }
    //    public static ScannerFile Number104 { get { return new ScannerFile("01_dispatch_custom_field_report_response\\0x1460D84C.mp3", "10-4.", "dispatch_custom_field_report_response"); } }
    //    public static ScannerFile Number104copy { get { return new ScannerFile("01_dispatch_custom_field_report_response\\0x17D59F36.mp3", "10-4, copy.", "dispatch_custom_field_report_response"); } }
    //    public static ScannerFile Roger { get { return new ScannerFile("01_dispatch_custom_field_report_response\\0x1E802C76.mp3", "Roger.", "dispatch_custom_field_report_response"); } }
    //}
    public class dispatch_respond_code
    {
        public static ScannerFile UnitsrespondCode2 { get { return new ScannerFile("01_dispatch_respond_code\\0x00B0B158.mp3", "Units respond; Code 2.", "dispatch_respond_code"); } }
        public static ScannerFile AllunitsrespondCode99 { get { return new ScannerFile("01_dispatch_respond_code\\0x067E6E48.mp3", "All units respond; Code 99.", "dispatch_respond_code"); } }
        public static ScannerFile Code99allunitsrespond { get { return new ScannerFile("01_dispatch_respond_code\\0x09BEB4C8.mp3", "Code 99; all units respond.", "dispatch_respond_code"); } }
        public static ScannerFile RespondCode2 { get { return new ScannerFile("01_dispatch_respond_code\\0x0B6786C0.mp3", "Respond; Code 2.", "dispatch_respond_code"); } }
        public static ScannerFile UnitsrespondCode3 { get { return new ScannerFile("01_dispatch_respond_code\\0x0DD15A9F.mp3", "Units respond; Code 3.", "dispatch_respond_code"); } }
        public static ScannerFile RespondCode3 { get { return new ScannerFile("01_dispatch_respond_code\\0x0E9C9C35.mp3", "Respond; Code 3.", "dispatch_respond_code"); } }
        public static ScannerFile AllunitsrespondCode99emergency { get { return new ScannerFile("01_dispatch_respond_code\\0x113C43C4.mp3", "All units respond; Code 99 emergency.", "dispatch_respond_code"); } }
        public static ScannerFile UnitrespondCode3 { get { return new ScannerFile("01_dispatch_respond_code\\0x1917312B.mp3", "Unit respond; Code 3.", "dispatch_respond_code"); } }
        public static ScannerFile EmergencyallunitsrespondCode99 { get { return new ScannerFile("01_dispatch_respond_code\\0x1B01574D.mp3", "Emergency; all units respond Code 99.", "dispatch_respond_code"); } }
        public static ScannerFile UnitrespondCode2 { get { return new ScannerFile("01_dispatch_respond_code\\0x1CB5A95C.mp3", "Unit respond; Code 2.", "dispatch_respond_code"); } }
    }
    //public class dispatch_to
    //{
    //    public static ScannerFile Dispatchtouhh { get { return new ScannerFile("01_dispatch_to\\0x04BCE5D5.mp3", "Dispatch to, uhh...", "dispatch_to"); } }
    //    public static ScannerFile Dispatchtoumm { get { return new ScannerFile("01_dispatch_to\\0x14FE4658.mp3", "Dispatch to, umm...", "dispatch_to"); } }
    //}
    //public class dispatch_units_from
    //{
    //    public static ScannerFile Dispatchunitsfromuh { get { return new ScannerFile("01_dispatch_units_from\\0x08A4112E.mp3", "Dispatch units from uh...", "dispatch_units_from"); } }
    //    public static ScannerFile Dispatchunitsfrom { get { return new ScannerFile("01_dispatch_units_from\\0x0B7756D4.mp3", "Dispatch units from...", "dispatch_units_from"); } }
    //    public static ScannerFile Dispatchunitsfromumm { get { return new ScannerFile("01_dispatch_units_from\\0x1668ECB8.mp3", "Dispatch units from...umm...", "dispatch_units_from"); } }
    //    public static ScannerFile Dispatchunitsfromumm1 { get { return new ScannerFile("01_dispatch_units_from\\0x175AEE96.mp3", "Dispatch units from...umm...", "dispatch_units_from"); } }
    //}
    public class dispatch_units_full
    {
        public static ScannerFile DispatchingSWATunitsfrompoliceheadquarters { get { return new ScannerFile("01_dispatch_units_full\\0x011432C4.mp3", "Dispatching SWAT units from police headquarters.", "dispatch_units_full"); } }
        public static ScannerFile DispatchunitsfromMirrorParkPoliceStation { get { return new ScannerFile("01_dispatch_units_full\\0x01E4F3CE.mp3", "Dispatch units fromMirror Park Police Station.", "dispatch_units_full"); } }
        public static ScannerFile ScramblingmilitaryaircraftfromKazanskyAirForceBase { get { return new ScannerFile("01_dispatch_units_full\\0x06AFD53C.mp3", "Scrambling military aircraft from Kazansky Air-Force Base.", "dispatch_units_full"); } }
        public static ScannerFile DispatchunitsfromMissionRowPoliceDepartment { get { return new ScannerFile("01_dispatch_units_full\\0x087C8D8D.mp3", "Dispatch units fromMission Row Police Department.", "dispatch_units_full"); } }
        public static ScannerFile DispatchingFIBinvestigators { get { return new ScannerFile("01_dispatch_units_full\\0x0AD31361.mp3", "Dispatching FIB investigators.", "dispatch_units_full"); } }
        public static ScannerFile Dispatchairunitfromcentralstation { get { return new ScannerFile("01_dispatch_units_full\\0x0B24363A.mp3", "Dispatch air unit from central station.", "dispatch_units_full"); } }
        public static ScannerFile Dispatchallavailableunitsfromdowntownarea { get { return new ScannerFile("01_dispatch_units_full\\0x0BA92B59.mp3", "Dispatch all available units from downtown area.", "dispatch_units_full"); } }
        public static ScannerFile DispatchingSWATunitsfrompoliceheadquarters1 { get { return new ScannerFile("01_dispatch_units_full\\0x10569149.mp3", "Dispatching SWAT units from police headquarters.", "dispatch_units_full"); } }
        public static ScannerFile DispatchunitsfromVespucciBeachPD { get { return new ScannerFile("01_dispatch_units_full\\0x14000A1A.mp3", "Dispatch units from Vespucci Beach PD.", "dispatch_units_full"); } }
        public static ScannerFile Dispatchingairunitfromcentralstation { get { return new ScannerFile("01_dispatch_units_full\\0x14B7C962.mp3", "Dispatching air unit from central station.", "dispatch_units_full"); } }
        public static ScannerFile Dispatchingairunitfromcentralstation1 { get { return new ScannerFile("01_dispatch_units_full\\0x16310C54.mp3", "Dispatching air unit from central station.", "dispatch_units_full"); } }
        public static ScannerFile Dispatchallavailableunitsfromthedowntownarea { get { return new ScannerFile("01_dispatch_units_full\\0x1887454D.mp3", "Dispatch all available units from the downtown area.", "dispatch_units_full"); } }
        public static ScannerFile Dispatchunitsfromdowntownprecinct { get { return new ScannerFile("01_dispatch_units_full\\0x196806D7.mp3", "Dispatch units from downtown precinct.", "dispatch_units_full"); } }
        public static ScannerFile DispatchingunitsfromKazanskyAirForceBase { get { return new ScannerFile("01_dispatch_units_full\\0x19C1FB60.mp3", "Dispatching units from Kazansky Air-Force Base.", "dispatch_units_full"); } }
        public static ScannerFile FIBteamdispatchingfromstation { get { return new ScannerFile("01_dispatch_units_full\\0x1D08B7CC.mp3", "FIB team dispatching from station.", "dispatch_units_full"); } }
    }
    public class doing_speed
    {
        public static ScannerFile Doing100mph { get { return new ScannerFile("01_doing_speed\\0x082AF3B3.mp3", "Doing 100 mph.", "doing_speed"); } }
        public static ScannerFile Doing70mph { get { return new ScannerFile("01_doing_speed\\0x0EB2AEE4.mp3", "Doing 70 mph.", "doing_speed"); } }
        public static ScannerFile Doingover100mph { get { return new ScannerFile("01_doing_speed\\0x10BF0162.mp3", "Doing over 100 mph.", "doing_speed"); } }
        public static ScannerFile Doing50mph { get { return new ScannerFile("01_doing_speed\\0x13559E06.mp3", "Doing 50 mph.", "doing_speed"); } }
        public static ScannerFile Doing60mph { get { return new ScannerFile("01_doing_speed\\0x18545449.mp3", "Doing 60 mph.", "doing_speed"); } }
        public static ScannerFile Doing80mph { get { return new ScannerFile("01_doing_speed\\0x1A1E8187.mp3", "Doing 80 mph.", "doing_speed"); } }
        public static ScannerFile Doing40mph { get { return new ScannerFile("01_doing_speed\\0x1CCDF2A2.mp3", "Doing 40 mph.", "doing_speed"); } }
        public static ScannerFile Doing90mph { get { return new ScannerFile("01_doing_speed\\0x1F166F61.mp3", "Doing 90 mph.", "doing_speed"); } }
    }
    public class emergency
    {
        public static ScannerFile Apossiblefire { get { return new ScannerFile("01_emergency\\0x006667C2.mp3", "A possible fire.", "emergency"); } }
        public static ScannerFile ApossibleAnthraxexposure { get { return new ScannerFile("01_emergency\\0x0173E77A.mp3", "A possible Anthrax exposure.", "emergency"); } }
        public static ScannerFile ApossibleEbolaexposure { get { return new ScannerFile("01_emergency\\0x02FFD687.mp3", "A possible Ebola exposure.", "emergency"); } }
        public static ScannerFile Anapartmentfire { get { return new ScannerFile("01_emergency\\0x03E3FED7.mp3", "An apartment fire.", "emergency"); } }
        public static ScannerFile Athreealarmfire { get { return new ScannerFile("01_emergency\\0x0518696C.mp3", "A three-alarm fire.", "emergency"); } }
        public static ScannerFile Apossibleapartmentfire { get { return new ScannerFile("01_emergency\\0x058BC227.mp3", "A possible apartment fire.", "emergency"); } }
        public static ScannerFile Amedicalemergency { get { return new ScannerFile("01_emergency\\0x082543D6.mp3", "A medical emergency.", "emergency"); } }
        public static ScannerFile Anapartmentfire1 { get { return new ScannerFile("01_emergency\\0x0A00CB0F.mp3", "An apartment fire.", "emergency"); } }
        public static ScannerFile Apossiblecondofire { get { return new ScannerFile("01_emergency\\0x0BACA760.mp3", "A possible condo fire.", "emergency"); } }
        public static ScannerFile ApossibleAnthraxrelease { get { return new ScannerFile("01_emergency\\0x0C65BD68.mp3", "A possible Anthrax release.", "emergency"); } }
        public static ScannerFile Afire { get { return new ScannerFile("01_emergency\\0x0DDC42AE.mp3", "A fire.", "emergency"); } }
        public static ScannerFile Apossibleburnvictim { get { return new ScannerFile("01_emergency\\0x0F1FA623.mp3", "A possible burn victim.", "emergency"); } }
        public static ScannerFile AcardiacarrestatBurgerShot { get { return new ScannerFile("01_emergency\\0x0F9F9E46.mp3", "A cardiac arrest at Burger Shot.", "emergency"); } }
        public static ScannerFile Aburnvictim { get { return new ScannerFile("01_emergency\\0x0FDF27A4.mp3", "A burn victim.", "emergency"); } }
        public static ScannerFile Apossiblecaseoftuberculosis { get { return new ScannerFile("01_emergency\\0x0FE599E5.mp3", "A possible case of tuberculosis.", "emergency"); } }
        public static ScannerFile Aburningbuilding { get { return new ScannerFile("01_emergency\\0x0FE6D76A.mp3", "A burning building.", "emergency"); } }
        public static ScannerFile ApossibleEbolarelease { get { return new ScannerFile("01_emergency\\0x10F43270.mp3", "A possible Ebola release.", "emergency"); } }
        public static ScannerFile Anapartmentcomplexfire { get { return new ScannerFile("01_emergency\\0x1131D970.mp3", "An apartment complex fire.", "emergency"); } }
        public static ScannerFile ApersonwithchestpainsatBurgerShot { get { return new ScannerFile("01_emergency\\0x115C61C0.mp3", "A person with chest pains at Burger Shot.", "emergency"); } }
        public static ScannerFile Abuildingonfire { get { return new ScannerFile("01_emergency\\0x121C1BD8.mp3", "A building on fire.", "emergency"); } }
        public static ScannerFile Apossiblehousefire { get { return new ScannerFile("01_emergency\\0x15619DA2.mp3", "A possible house fire.", "emergency"); } }
        public static ScannerFile PossiblecaseofEbola { get { return new ScannerFile("01_emergency\\0x157B7B7B.mp3", "Possible case of Ebola.", "emergency"); } }
        public static ScannerFile Ahousefire { get { return new ScannerFile("01_emergency\\0x169EA01C.mp3", "A house fire.", "emergency"); } }
        public static ScannerFile Apossiblemedicalemergency { get { return new ScannerFile("01_emergency\\0x188B24A1.mp3", "A possible medical emergency.", "emergency"); } }
        public static ScannerFile Acondofire { get { return new ScannerFile("01_emergency\\0x19EB03DD.mp3", "A condo fire.", "emergency"); } }
        public static ScannerFile AcontaminantreleasepossiblyEbola { get { return new ScannerFile("01_emergency\\0x1B05068F.mp3", "A contaminant release, possibly Ebola.", "emergency"); } }
        public static ScannerFile Afivealarmfire { get { return new ScannerFile("01_emergency\\0x1C3C46C1.mp3", "A five-alarm fire.", "emergency"); } }
        public static ScannerFile Apossiblebuildingonfire { get { return new ScannerFile("01_emergency\\0x1C4EF03C.mp3", "A possible building on fire.", "emergency"); } }
        public static ScannerFile Anapartmentonfire { get { return new ScannerFile("01_emergency\\0x1E8EF42A.mp3", "An apartment on fire.", "emergency"); } }
    }
    public class escort_boss
    {
        public static ScannerFile WehaveaCode99 { get { return new ScannerFile("01_escort_boss\\0x009F1452.mp3", "We have a Code 99.", "escort_boss"); } }
        public static ScannerFile Allunitsprimarysuspectisincustody { get { return new ScannerFile("01_escort_boss\\0x01CCC705.mp3", "All units, primary suspect is in custody.", "escort_boss"); } }
        public static ScannerFile Primarysuspecthasbeendetainedatprecinct { get { return new ScannerFile("01_escort_boss\\0x021FCAA6.mp3", "Primary suspect has been detained at precinct.", "escort_boss"); } }
        public static ScannerFile Primarysuspecthasarrivedattheprecinct { get { return new ScannerFile("01_escort_boss\\0x026DB302.mp3", "Primary suspect has arrived at the precinct.", "escort_boss"); } }
        public static ScannerFile Primarysuspecthasbeendetainedattheprecinct { get { return new ScannerFile("01_escort_boss\\0x04EEE6A8.mp3", "Primary suspect has been detained at the precinct.", "escort_boss"); } }
        public static ScannerFile Officersrequestingimmediateescorttoprecinct { get { return new ScannerFile("01_escort_boss\\0x050DFFB4.mp3", "Officers requesting immediate escort to precinct.", "escort_boss"); } }
        public static ScannerFile Primarysuspecthasarrivedattheprecinct1 { get { return new ScannerFile("01_escort_boss\\0x055E6B9E.mp3", "Primary suspect has arrived at the precinct.", "escort_boss"); } }
        public static ScannerFile Immediateassistancerequired { get { return new ScannerFile("01_escort_boss\\0x07652595.mp3", "Immediate assistance required.", "escort_boss"); } }
        public static ScannerFile Allunitsmainsuspectis1014 { get { return new ScannerFile("01_escort_boss\\0x07BD2B7B.mp3", "All units, main suspect is 10-14.", "escort_boss"); } }
        public static ScannerFile AllunitsCode99 { get { return new ScannerFile("01_escort_boss\\0x0987A9E6.mp3", "All units; Code 99.", "escort_boss"); } }
        public static ScannerFile SuspectisenroutetoCentralLosSantos { get { return new ScannerFile("01_escort_boss\\0x0C0DACFB.mp3", "Suspect is en route to Central Los Santos.", "escort_boss"); } }
        public static ScannerFile WehavereportsofahighlevelVagosgangmemberintransit { get { return new ScannerFile("01_escort_boss\\0x0D17473D.mp3", "We have reports of a high-level Vagos gang member in transit.", "escort_boss"); } }
        public static ScannerFile Allunitsprovidedimmediatebackup { get { return new ScannerFile("01_escort_boss\\0x0D276D5F.mp3", "All units provided immediate backup.", "escort_boss"); } }
        public static ScannerFile SuspectisenroutetoCentralLosSantos1 { get { return new ScannerFile("01_escort_boss\\0x0D9A700E.mp3", "Suspect is en route to Central Los Santos.", "escort_boss"); } }
        public static ScannerFile WehavereportsofahighlevelLostgangmemberintransit { get { return new ScannerFile("01_escort_boss\\0x0E9E5B46.mp3", "We have reports of a high-level Lost gang member in transit.", "escort_boss"); } }
        public static ScannerFile Suspecttransportunderattack { get { return new ScannerFile("01_escort_boss\\0x0F74B1FD.mp3", "Suspect transport under attack.", "escort_boss"); } }
        public static ScannerFile Allunitsmainsuspectisa1014 { get { return new ScannerFile("01_escort_boss\\0x12385A09.mp3", "All units, main suspect is a 10-14.", "escort_boss"); } }
        public static ScannerFile Allunitsstanddown { get { return new ScannerFile("01_escort_boss\\0x12A2020F.mp3", "All units stand down.", "escort_boss"); } }
        public static ScannerFile AllunitsCode4 { get { return new ScannerFile("01_escort_boss\\0x12CC867A.mp3", "All units; Code 4.", "escort_boss"); } }
        public static ScannerFile Suspectsareheavilyarmed { get { return new ScannerFile("01_escort_boss\\0x158FFB90.mp3", "Suspects are heavily armed.", "escort_boss"); } }
        public static ScannerFile Officersrequireescorttoprecinct { get { return new ScannerFile("01_escort_boss\\0x159E77AB.mp3", "Officers require escort to precinct.", "escort_boss"); } }
        public static ScannerFile SuspectisenroutetoCentralLosSantos2 { get { return new ScannerFile("01_escort_boss\\0x16440167.mp3", "Suspect is en route to Central Los Santos.", "escort_boss"); } }
        public static ScannerFile Officersrequestingimmediateescorttoprecinct1 { get { return new ScannerFile("01_escort_boss\\0x169F4940.mp3", "Officers requesting immediate escort to precinct.", "escort_boss"); } }
        public static ScannerFile Officerstransportingprimarysuspectsareunderattack { get { return new ScannerFile("01_escort_boss\\0x16C08458.mp3", "Officers transporting primary suspects are under attack.", "escort_boss"); } }
        public static ScannerFile AllunitsCode41 { get { return new ScannerFile("01_escort_boss\\0x17975D56.mp3", "All units; Code 4.", "escort_boss"); } }
        public static ScannerFile SuspectisenroutetoCentralLosSantos2_1 { get { return new ScannerFile("01_escort_boss\\0x19C0C860.mp3", "Suspect is en route to Central Los Santos.", "escort_boss"); } }
        public static ScannerFile WehavereportsofahighlevelLostgangmemberintransit1 { get { return new ScannerFile("01_escort_boss\\0x1A857318.mp3", "We have reports of a high-level Lost gang member in transit.", "escort_boss"); } }
        public static ScannerFile Officersrequestingimmediatetransitassistance { get { return new ScannerFile("01_escort_boss\\0x1A97F89B.mp3", "Officers requesting immediate transit assistance.", "escort_boss"); } }
        public static ScannerFile Allunitsstanddown1 { get { return new ScannerFile("01_escort_boss\\0x1BD9FE19.mp3", "All units stand down.", "escort_boss"); } }
        public static ScannerFile Allunitsprimarytargetisunderarrest { get { return new ScannerFile("01_escort_boss\\0x1EC349F5.mp3", "All units, primary target is under arrest.", "escort_boss"); } }
        public static ScannerFile WehavereportsofahighlevelVagosgangmemberintransit1 { get { return new ScannerFile("01_escort_boss\\0x1EC96AA1.mp3", "We have reports of a high-level Vagos gang member in transit.", "escort_boss"); } }
    }
    //public class extra_prefix
    //{
    //    public static ScannerFile Beatup { get { return new ScannerFile("01_extra_prefix\\0x02CB8B4C.mp3", "Beat up.", "extra_prefix"); } }
    //    public static ScannerFile Dented { get { return new ScannerFile("01_extra_prefix\\0x02E3C342.mp3", "Dented.", "extra_prefix"); } }
    //    public static ScannerFile Modified { get { return new ScannerFile("01_extra_prefix\\0x06127D7F.mp3", "Modified.", "extra_prefix"); } }
    //    public static ScannerFile Dirty { get { return new ScannerFile("01_extra_prefix\\0x067B9330.mp3", "Dirty.", "extra_prefix"); } }
    //    public static ScannerFile Mint { get { return new ScannerFile("01_extra_prefix\\0x08510305.mp3", "Mint.", "extra_prefix"); } }
    //    public static ScannerFile Custom { get { return new ScannerFile("01_extra_prefix\\0x0DE67420.mp3", "Custom.", "extra_prefix"); } }
    //    public static ScannerFile Customized { get { return new ScannerFile("01_extra_prefix\\0x1303EEAD.mp3", "Customized.", "extra_prefix"); } }
    //    public static ScannerFile Chopped { get { return new ScannerFile("01_extra_prefix\\0x1501AFC3.mp3", "Chopped.", "extra_prefix"); } }
    //    public static ScannerFile Damaged { get { return new ScannerFile("01_extra_prefix\\0x151A41F6.mp3", "Damaged.", "extra_prefix"); } }
    //    public static ScannerFile Rundown { get { return new ScannerFile("01_extra_prefix\\0x158689B3.mp3", "Run-down.", "extra_prefix"); } }
    //    public static ScannerFile Distressed { get { return new ScannerFile("01_extra_prefix\\0x15F33674.mp3", "Distressed.", "extra_prefix"); } }
    //    public static ScannerFile Rundown1 { get { return new ScannerFile("01_extra_prefix\\0x160B4ABB.mp3", "Run-down.", "extra_prefix"); } }
    //    public static ScannerFile Battered { get { return new ScannerFile("01_extra_prefix\\0x17987A64.mp3", "Battered.", "extra_prefix"); } }
    //    public static ScannerFile Rusty { get { return new ScannerFile("01_extra_prefix\\0x1CDCBBCC.mp3", "Rusty.", "extra_prefix"); } }
    //}
    //public class gang_name
    //{
    //    public static ScannerFile TheLost { get { return new ScannerFile("01_gang_name\\0x00A35403.mp3", "The Lost.", "gang_name"); } }
    //    public static ScannerFile TheVagos { get { return new ScannerFile("01_gang_name\\0x0476C52A.mp3", "The Vagos.", "gang_name"); } }
    //    public static ScannerFile Aprofessionalcrimeoutfit { get { return new ScannerFile("01_gang_name\\0x06123C0C.mp3", "A professional crime outfit.", "gang_name"); } }
    //    public static ScannerFile AMexicangang { get { return new ScannerFile("01_gang_name\\0x06A0C782.mp3", "A Mexican gang.", "gang_name"); } }
    //    public static ScannerFile Aprofessionalcriminalorganization { get { return new ScannerFile("01_gang_name\\0x0A713996.mp3", "A professional criminal organization", "gang_name"); } }
    //    public static ScannerFile Aprofessionalcrimesyndicate { get { return new ScannerFile("01_gang_name\\0x0BE7D9C7.mp3", "A professional crime syndicate.", "gang_name"); } }
    //    public static ScannerFile AnAfricanAmericangang { get { return new ScannerFile("01_gang_name\\0x0CB8D07E.mp3", "An African-American gang.", "gang_name"); } }
    //    public static ScannerFile Abikergang { get { return new ScannerFile("01_gang_name\\0x0FCCB6E6.mp3", "A biker gang.", "gang_name"); } }
    //    public static ScannerFile Aprofessionalcrimecrew { get { return new ScannerFile("01_gang_name\\0x1F1DE0EA.mp3", "A professional crime crew.", "gang_name"); } }
    //}
    //public class generic_direction { public static ScannerFile Central { get { return new ScannerFile("01_generic_direction\\0x0BF563E8.mp3", "Central.", "generic_direction"); } } }
    //public class hair
    //{
    //    public static ScannerFile Purplehair { get { return new ScannerFile("01_hair\\0x019331A8.mp3", "Purple hair.", "hair"); } }
    //    public static ScannerFile Bluehair { get { return new ScannerFile("01_hair\\0x06449285.mp3", "Blue hair.", "hair"); } }
    //    public static ScannerFile Orangehair { get { return new ScannerFile("01_hair\\0x0F349B52.mp3", "Orange hair.", "hair"); } }
    //    public static ScannerFile Coloredhair { get { return new ScannerFile("01_hair\\0x133F208B.mp3", "Colored hair.", "hair"); } }
    //    public static ScannerFile Aknittedcap { get { return new ScannerFile("01_hair\\0x1433A16F.mp3", "A knitted cap.", "hair"); } }
    //    public static ScannerFile Brownhair { get { return new ScannerFile("01_hair\\0x184B98DE.mp3", "Brown hair.", "hair"); } }
    //    public static ScannerFile Redhair { get { return new ScannerFile("01_hair\\0x18E34C46.mp3", "Red hair.", "hair"); } }
    //    public static ScannerFile Greenhair { get { return new ScannerFile("01_hair\\0x18FC48DA.mp3", "Green hair.", "hair"); } }
    //    public static ScannerFile Blackhair { get { return new ScannerFile("01_hair\\0x19960FF6.mp3", "Black hair.", "hair"); } }
    //    public static ScannerFile Abaseballcap { get { return new ScannerFile("01_hair\\0x1A122B24.mp3", "A baseball cap.", "hair"); } }
    //    public static ScannerFile Blondehair { get { return new ScannerFile("01_hair\\0x1D7A1600.mp3", "Blonde hair.", "hair"); } }
    //    public static ScannerFile Punkhair { get { return new ScannerFile("01_hair\\0x1E913A94.mp3", "Punk hair.", "hair"); } }
    //    public static ScannerFile Acowboyhat { get { return new ScannerFile("01_hair\\0x1F47D088.mp3", "A cowboy hat.", "hair"); } }
    //    public static ScannerFile Nohair { get { return new ScannerFile("01_hair\\0x1F975F7C.mp3", "No hair.", "hair"); } }
    //}
    //public class helicopter_refuelling
    //{
    //    public static ScannerFile Airunitlowonfuelreturningtobase { get { return new ScannerFile("01_helicopter_refuelling\\0x021BAEBA.mp3", "Air unit low on fuel, returning to base.", "helicopter_refuelling"); } }
    //    public static ScannerFile Eagleunithasbeenrecalledforarefueling { get { return new ScannerFile("01_helicopter_refuelling\\0x0783F887.mp3", "Eagle unit has been recalled for a refueling.", "helicopter_refuelling"); } }
    //    public static ScannerFile Eagleunithasbeenrecalledforrefueling { get { return new ScannerFile("01_helicopter_refuelling\\0x0CCA0311.mp3", "Eagle unit has been recalled for refueling.", "helicopter_refuelling"); } }
    //    public static ScannerFile Airsupportlowonfuelreturningtobase { get { return new ScannerFile("01_helicopter_refuelling\\0x1017CABD.mp3", "Air support low on fuel; returning to base.", "helicopter_refuelling"); } }
    //    public static ScannerFile Airsupportisreturningtobaseforarefueling { get { return new ScannerFile("01_helicopter_refuelling\\0x12924E9F.mp3", "Air support is returning to base for a refueling.", "helicopter_refuelling"); } }
    //    public static ScannerFile Airsupportunitneedstorefuel { get { return new ScannerFile("01_helicopter_refuelling\\0x1336D0F7.mp3", "Air support unit needs to refuel.", "helicopter_refuelling"); } }
    //    public static ScannerFile Airunitneedstorefuel { get { return new ScannerFile("01_helicopter_refuelling\\0x15761452.mp3", "Air unit needs to refuel.", "helicopter_refuelling"); } }
    //    public static ScannerFile Airunitislowonfuelreturningtobase { get { return new ScannerFile("01_helicopter_refuelling\\0x19F1DD49.mp3", "Air unit is low on fuel; returning to base.", "helicopter_refuelling"); } }
    //    public static ScannerFile Airsupportisheadinghometorefuel { get { return new ScannerFile("01_helicopter_refuelling\\0x1C4F2219.mp3", "Air support is heading home to refuel.", "helicopter_refuelling"); } }
    //    public static ScannerFile Airunitisreturningtobaseforarefueling { get { return new ScannerFile("01_helicopter_refuelling\\0x1FD3E922.mp3", "Air unit is returning to base for a refueling.", "helicopter_refuelling"); } }
    //}
    //public class in_the_water
    //{
    //    public static ScannerFile IntheLSriver { get { return new ScannerFile("01_in_the_water\\0x0243B2FD.mp3", "In the LS river.", "in_the_water"); } }
    //    public static ScannerFile OfftheWesterncoast { get { return new ScannerFile("01_in_the_water\\0x03680F1E.mp3", "Off the Western coast.", "in_the_water"); } }
    //    public static ScannerFile OfftheWestcoast { get { return new ScannerFile("01_in_the_water\\0x09AD1BA7.mp3", "Off the West coast.", "in_the_water"); } }
    //    public static ScannerFile OfftheNortherncoast { get { return new ScannerFile("01_in_the_water\\0x0BC82B92.mp3", "Off the Northern coast.", "in_the_water"); } }
    //    public static ScannerFile Inthewater { get { return new ScannerFile("01_in_the_water\\0x0BF2657F.mp3", "In the water.", "in_the_water"); } }
    //    public static ScannerFile IntheAlamoSea { get { return new ScannerFile("01_in_the_water\\0x0D0526A6.mp3", "In the Alamo Sea.", "in_the_water"); } }
    //    public static ScannerFile OfftheEastcoast { get { return new ScannerFile("01_in_the_water\\0x0F083043.mp3", "Off the East coast.", "in_the_water"); } }
    //    public static ScannerFile OfftheSoutherncoast { get { return new ScannerFile("01_in_the_water\\0x10CDD7BA.mp3", "Off the Southern coast.", "in_the_water"); } }
    //    public static ScannerFile OfftheSouthcoast { get { return new ScannerFile("01_in_the_water\\0x15E2E1E5.mp3", "Off the South coast.", "in_the_water"); } }
    //    public static ScannerFile OfftheNorthcoast { get { return new ScannerFile("01_in_the_water\\0x1916062E.mp3", "Off the North coast.", "in_the_water"); } }
    //    public static ScannerFile OfftheEasterncoast { get { return new ScannerFile("01_in_the_water\\0x1EC9CFC7.mp3", "Off the Eastern coast.", "in_the_water"); } }
    //}
    public class lethal_force
    {
        public static ScannerFile Useoflethalforceisnotauthorized { get { return new ScannerFile("01_lethal_force\\0x0270822F.mp3", "Use of lethal force is not authorized.", "lethal_force"); } }
        public static ScannerFile Useofdeadlyforcepermitted { get { return new ScannerFile("01_lethal_force\\0x064EE711.mp3", "Use of deadly force permitted.", "lethal_force"); } }
        public static ScannerFile Nocasualties { get { return new ScannerFile("01_lethal_force\\0x073ACBC4.mp3", "No casualties.", "lethal_force"); } }
        public static ScannerFile Useofdeadlyforceisauthorized { get { return new ScannerFile("01_lethal_force\\0x07E6AA1A.mp3", "Use of deadly force is authorized.", "lethal_force"); } }
        public static ScannerFile Nonlethalweaponstobeemployed { get { return new ScannerFile("01_lethal_force\\0x0B7B9446.mp3", "Non-lethal weapons to be employed.", "lethal_force"); } }
        public static ScannerFile Useoflethalforceisauthorized { get { return new ScannerFile("01_lethal_force\\0x145F4332.mp3", "Use of lethal force is authorized.", "lethal_force"); } }
        public static ScannerFile Useoflethalforceispermitted { get { return new ScannerFile("01_lethal_force\\0x16BA07E8.mp3", "Use of lethal force is permitted.", "lethal_force"); } }
        public static ScannerFile Useofdeadlyforceauthorized { get { return new ScannerFile("01_lethal_force\\0x17940975.mp3", "Use of deadly force authorized.", "lethal_force"); } }
        public static ScannerFile Nonlethalweaponsonly { get { return new ScannerFile("01_lethal_force\\0x18AAAEA3.mp3", "Non-lethal weapons only.", "lethal_force"); } }
        public static ScannerFile Useofdeadlyforcepermitted1 { get { return new ScannerFile("01_lethal_force\\0x1B901193.mp3", "Use of deadly force permitted.", "lethal_force"); } }
        public static ScannerFile Useofdeadlyforceisauthorized1 { get { return new ScannerFile("01_lethal_force\\0x1EEAD848.mp3", "Use of deadly force is authorized.", "lethal_force"); } }
        public static ScannerFile Nonlethaltacticsonly { get { return new ScannerFile("01_lethal_force\\0x1F81FC45.mp3", "Non-lethal tactics only.", "lethal_force"); } }
    }
    public class lp_letters_high
    {
        public static ScannerFile Nora { get { return new ScannerFile("01_lp_letters_high\\0x001E74CF.mp3", "Nora.", "lp_letters_high"); } }
        public static ScannerFile George { get { return new ScannerFile("01_lp_letters_high\\0x002E9DE5.mp3", "George.", "lp_letters_high"); } }
        public static ScannerFile Sam { get { return new ScannerFile("01_lp_letters_high\\0x0087733A.mp3", "Sam.", "lp_letters_high"); } }
        public static ScannerFile Mary { get { return new ScannerFile("01_lp_letters_high\\0x00E210C8.mp3", "Mary.", "lp_letters_high"); } }
        public static ScannerFile Frank { get { return new ScannerFile("01_lp_letters_high\\0x0158F4B2.mp3", "Frank.", "lp_letters_high"); } }
        public static ScannerFile David { get { return new ScannerFile("01_lp_letters_high\\0x02F91F2A.mp3", "David.", "lp_letters_high"); } }
        public static ScannerFile William { get { return new ScannerFile("01_lp_letters_high\\0x03A9D3DF.mp3", "William.", "lp_letters_high"); } }
        public static ScannerFile George1 { get { return new ScannerFile("01_lp_letters_high\\0x03AF64F1.mp3", "George.", "lp_letters_high"); } }
        public static ScannerFile John { get { return new ScannerFile("01_lp_letters_high\\0x03DAC98A.mp3", "John.", "lp_letters_high"); } }
        public static ScannerFile Boy { get { return new ScannerFile("01_lp_letters_high\\0x043556DB.mp3", "Boy.", "lp_letters_high"); } }
        public static ScannerFile King { get { return new ScannerFile("01_lp_letters_high\\0x0458C6FF.mp3", "King.", "lp_letters_high"); } }
        public static ScannerFile Tom { get { return new ScannerFile("01_lp_letters_high\\0x047066CE.mp3", "Tom.", "lp_letters_high"); } }
        public static ScannerFile Edward { get { return new ScannerFile("01_lp_letters_high\\0x04A5AE85.mp3", "Edward.", "lp_letters_high"); } }
        public static ScannerFile Charles { get { return new ScannerFile("01_lp_letters_high\\0x068372C5.mp3", "Charles.", "lp_letters_high"); } }
        public static ScannerFile King1 { get { return new ScannerFile("01_lp_letters_high\\0x080ECE69.mp3", "King.", "lp_letters_high"); } }
        public static ScannerFile Union { get { return new ScannerFile("01_lp_letters_high\\0x082957EE.mp3", "Union.", "lp_letters_high"); } }
        public static ScannerFile Paul { get { return new ScannerFile("01_lp_letters_high\\0x0A69B2A3.mp3", "Paul.", "lp_letters_high"); } }
        public static ScannerFile Victor { get { return new ScannerFile("01_lp_letters_high\\0x0ADD2EDE.mp3", "Victor.", "lp_letters_high"); } }
        public static ScannerFile Sam1 { get { return new ScannerFile("01_lp_letters_high\\0x0B5CC8E2.mp3", "Sam.", "lp_letters_high"); } }
        public static ScannerFile Adam { get { return new ScannerFile("01_lp_letters_high\\0x0C5E4FE3.mp3", "Adam.", "lp_letters_high"); } }
        public static ScannerFile Frank1 { get { return new ScannerFile("01_lp_letters_high\\0x0C804B02.mp3", "Frank.", "lp_letters_high"); } }
        public static ScannerFile Tom1 { get { return new ScannerFile("01_lp_letters_high\\0x0C8476F7.mp3", "Tom.", "lp_letters_high"); } }
        public static ScannerFile Adam1 { get { return new ScannerFile("01_lp_letters_high\\0x0D951251.mp3", "Adam.", "lp_letters_high"); } }
        public static ScannerFile Queen { get { return new ScannerFile("01_lp_letters_high\\0x0DFBFA78.mp3", "Queen.", "lp_letters_high"); } }
        public static ScannerFile Ocean { get { return new ScannerFile("01_lp_letters_high\\0x0F6D568F.mp3", "Ocean.", "lp_letters_high"); } }
        public static ScannerFile Robert { get { return new ScannerFile("01_lp_letters_high\\0x0FC33F6E.mp3", "Robert.", "lp_letters_high"); } }
        public static ScannerFile Mary1 { get { return new ScannerFile("01_lp_letters_high\\0x101A2F36.mp3", "Mary.", "lp_letters_high"); } }
        public static ScannerFile Ita { get { return new ScannerFile("01_lp_letters_high\\0x106ED745.mp3", "Ita.", "lp_letters_high"); } }
        public static ScannerFile Paul1 { get { return new ScannerFile("01_lp_letters_high\\0x109CFF03.mp3", "Paul.", "lp_letters_high"); } }
        public static ScannerFile Lincoln { get { return new ScannerFile("01_lp_letters_high\\0x11B9CE69.mp3", "Lincoln.", "lp_letters_high"); } }
        public static ScannerFile Boy1 { get { return new ScannerFile("01_lp_letters_high\\0x11E5B23C.mp3", "Boy.", "lp_letters_high"); } }
        public static ScannerFile Ita1 { get { return new ScannerFile("01_lp_letters_high\\0x1233DACD.mp3", "Ita.", "lp_letters_high"); } }
        public static ScannerFile Edward1 { get { return new ScannerFile("01_lp_letters_high\\0x12670A08.mp3", "Edward.", "lp_letters_high"); } }
        public static ScannerFile Henry { get { return new ScannerFile("01_lp_letters_high\\0x12E88C8C.mp3", "Henry.", "lp_letters_high"); } }
        public static ScannerFile Queen1 { get { return new ScannerFile("01_lp_letters_high\\0x13B305EE.mp3", "Queen.", "lp_letters_high"); } }
        public static ScannerFile Zebra { get { return new ScannerFile("01_lp_letters_high\\0x1562FF84.mp3", "Zebra.", "lp_letters_high"); } }
        public static ScannerFile Union1 { get { return new ScannerFile("01_lp_letters_high\\0x156BF273.mp3", "Union.", "lp_letters_high"); } }
        public static ScannerFile Zebra1 { get { return new ScannerFile("01_lp_letters_high\\0x15BA0034.mp3", "Zebra.", "lp_letters_high"); } }
        public static ScannerFile John1 { get { return new ScannerFile("01_lp_letters_high\\0x15D52D7F.mp3", "John.", "lp_letters_high"); } }
        public static ScannerFile Young { get { return new ScannerFile("01_lp_letters_high\\0x1624C995.mp3", "Young.", "lp_letters_high"); } }
        public static ScannerFile Henry1 { get { return new ScannerFile("01_lp_letters_high\\0x16451346.mp3", "Henry.", "lp_letters_high"); } }
        public static ScannerFile XRay { get { return new ScannerFile("01_lp_letters_high\\0x16F5D733.mp3", "X-Ray.", "lp_letters_high"); } }
        public static ScannerFile William1 { get { return new ScannerFile("01_lp_letters_high\\0x17073A99.mp3", "William.", "lp_letters_high"); } }
        public static ScannerFile Nora1 { get { return new ScannerFile("01_lp_letters_high\\0x173F6314.mp3", "Nora.", "lp_letters_high"); } }
        public static ScannerFile Charles1 { get { return new ScannerFile("01_lp_letters_high\\0x18239606.mp3", "Charles.", "lp_letters_high"); } }
        public static ScannerFile Victor1 { get { return new ScannerFile("01_lp_letters_high\\0x188F8A43.mp3", "Victor.", "lp_letters_high"); } }
        public static ScannerFile Ocean1 { get { return new ScannerFile("01_lp_letters_high\\0x19432A3B.mp3", "Ocean.", "lp_letters_high"); } }
        public static ScannerFile Robert1 { get { return new ScannerFile("01_lp_letters_high\\0x197BD2D8.mp3", "Robert.", "lp_letters_high"); } }
        public static ScannerFile XRay1 { get { return new ScannerFile("01_lp_letters_high\\0x1B1BDF79.mp3", "X-Ray.", "lp_letters_high"); } }
        public static ScannerFile Young1 { get { return new ScannerFile("01_lp_letters_high\\0x1B2FD3AF.mp3", "Young.", "lp_letters_high"); } }
        public static ScannerFile Lincoln1 { get { return new ScannerFile("01_lp_letters_high\\0x1E5D67B5.mp3", "Lincoln.", "lp_letters_high"); } }
    }
    //public class lp_letters_low
    //{
    //    public static ScannerFile William { get { return new ScannerFile("01_lp_letters_low\\0x0031F6C5.mp3", "William.", "lp_letters_low"); } }
    //    public static ScannerFile Robert { get { return new ScannerFile("01_lp_letters_low\\0x00D31CC4.mp3", "Robert.", "lp_letters_low"); } }
    //    public static ScannerFile HASH01E6E7C1 { get { return new ScannerFile("01_lp_letters_low\\0x01E6E7C1.mp3", "0x01E6E7C1", "lp_letters_low"); } }
    //    public static ScannerFile HASH03361ED9 { get { return new ScannerFile("01_lp_letters_low\\0x03361ED9.mp3", "0x03361ED9", "lp_letters_low"); } }
    //    public static ScannerFile HASH03B8C5D6 { get { return new ScannerFile("01_lp_letters_low\\0x03B8C5D6.mp3", "0x03B8C5D6", "lp_letters_low"); } }
    //    public static ScannerFile HASH048C0CEC { get { return new ScannerFile("01_lp_letters_low\\0x048C0CEC.mp3", "0x048C0CEC", "lp_letters_low"); } }
    //    public static ScannerFile HASH04936189 { get { return new ScannerFile("01_lp_letters_low\\0x04936189.mp3", "0x04936189", "lp_letters_low"); } }
    //    public static ScannerFile HASH0537B541 { get { return new ScannerFile("01_lp_letters_low\\0x0537B541.mp3", "0x0537B541", "lp_letters_low"); } }
    //    public static ScannerFile HASH055D0BCA { get { return new ScannerFile("01_lp_letters_low\\0x055D0BCA.mp3", "0x055D0BCA", "lp_letters_low"); } }
    //    public static ScannerFile HASH05EE78E6 { get { return new ScannerFile("01_lp_letters_low\\0x05EE78E6.mp3", "0x05EE78E6", "lp_letters_low"); } }
    //    public static ScannerFile HASH05F0170F { get { return new ScannerFile("01_lp_letters_low\\0x05F0170F.mp3", "0x05F0170F", "lp_letters_low"); } }
    //    public static ScannerFile HASH064182C9 { get { return new ScannerFile("01_lp_letters_low\\0x064182C9.mp3", "0x064182C9", "lp_letters_low"); } }
    //    public static ScannerFile HASH074858B4 { get { return new ScannerFile("01_lp_letters_low\\0x074858B4.mp3", "0x074858B4", "lp_letters_low"); } }
    //    public static ScannerFile HASH07511EA5 { get { return new ScannerFile("01_lp_letters_low\\0x07511EA5.mp3", "0x07511EA5", "lp_letters_low"); } }
    //    public static ScannerFile HASH0843F47A { get { return new ScannerFile("01_lp_letters_low\\0x0843F47A.mp3", "0x0843F47A", "lp_letters_low"); } }
    //    public static ScannerFile HASH0856C2D4 { get { return new ScannerFile("01_lp_letters_low\\0x0856C2D4.mp3", "0x0856C2D4", "lp_letters_low"); } }
    //    public static ScannerFile HASH0A913F22 { get { return new ScannerFile("01_lp_letters_low\\0x0A913F22.mp3", "0x0A913F22", "lp_letters_low"); } }
    //    public static ScannerFile HASH0ABED54D { get { return new ScannerFile("01_lp_letters_low\\0x0ABED54D.mp3", "0x0ABED54D", "lp_letters_low"); } }
    //    public static ScannerFile HASH0B4627A7 { get { return new ScannerFile("01_lp_letters_low\\0x0B4627A7.mp3", "0x0B4627A7", "lp_letters_low"); } }
    //    public static ScannerFile HASH0B905BFE { get { return new ScannerFile("01_lp_letters_low\\0x0B905BFE.mp3", "0x0B905BFE", "lp_letters_low"); } }
    //    public static ScannerFile HASH0D681934 { get { return new ScannerFile("01_lp_letters_low\\0x0D681934.mp3", "0x0D681934", "lp_letters_low"); } }
    //    public static ScannerFile HASH0DF35248 { get { return new ScannerFile("01_lp_letters_low\\0x0DF35248.mp3", "0x0DF35248", "lp_letters_low"); } }
    //    public static ScannerFile HASH0E67EDE6 { get { return new ScannerFile("01_lp_letters_low\\0x0E67EDE6.mp3", "0x0E67EDE6", "lp_letters_low"); } }
    //    public static ScannerFile HASH0F54B9C7 { get { return new ScannerFile("01_lp_letters_low\\0x0F54B9C7.mp3", "0x0F54B9C7", "lp_letters_low"); } }
    //    public static ScannerFile HASH1040DC27 { get { return new ScannerFile("01_lp_letters_low\\0x1040DC27.mp3", "0x1040DC27", "lp_letters_low"); } }
    //    public static ScannerFile HASH10A007F6 { get { return new ScannerFile("01_lp_letters_low\\0x10A007F6.mp3", "0x10A007F6", "lp_letters_low"); } }
    //    public static ScannerFile HASH11043372 { get { return new ScannerFile("01_lp_letters_low\\0x11043372.mp3", "0x11043372", "lp_letters_low"); } }
    //    public static ScannerFile HASH110EAB58 { get { return new ScannerFile("01_lp_letters_low\\0x110EAB58.mp3", "0x110EAB58", "lp_letters_low"); } }
    //    public static ScannerFile HASH1274A090 { get { return new ScannerFile("01_lp_letters_low\\0x1274A090.mp3", "0x1274A090", "lp_letters_low"); } }
    //    public static ScannerFile HASH13032F14 { get { return new ScannerFile("01_lp_letters_low\\0x13032F14.mp3", "0x13032F14", "lp_letters_low"); } }
    //    public static ScannerFile HASH1313AF33 { get { return new ScannerFile("01_lp_letters_low\\0x1313AF33.mp3", "0x1313AF33", "lp_letters_low"); } }
    //    public static ScannerFile HASH134D0FEB { get { return new ScannerFile("01_lp_letters_low\\0x134D0FEB.mp3", "0x134D0FEB", "lp_letters_low"); } }
    //    public static ScannerFile HASH138511DC { get { return new ScannerFile("01_lp_letters_low\\0x138511DC.mp3", "0x138511DC", "lp_letters_low"); } }
    //    public static ScannerFile HASH15A77B52 { get { return new ScannerFile("01_lp_letters_low\\0x15A77B52.mp3", "0x15A77B52", "lp_letters_low"); } }
    //    public static ScannerFile HASH15BBE1BC { get { return new ScannerFile("01_lp_letters_low\\0x15BBE1BC.mp3", "0x15BBE1BC", "lp_letters_low"); } }
    //    public static ScannerFile HASH16079E36 { get { return new ScannerFile("01_lp_letters_low\\0x16079E36.mp3", "0x16079E36", "lp_letters_low"); } }
    //    public static ScannerFile HASH175B37F2 { get { return new ScannerFile("01_lp_letters_low\\0x175B37F2.mp3", "0x175B37F2", "lp_letters_low"); } }
    //    public static ScannerFile HASH1774FFFB { get { return new ScannerFile("01_lp_letters_low\\0x1774FFFB.mp3", "0x1774FFFB", "lp_letters_low"); } }
    //    public static ScannerFile HASH177C9C03 { get { return new ScannerFile("01_lp_letters_low\\0x177C9C03.mp3", "0x177C9C03", "lp_letters_low"); } }
    //    public static ScannerFile HASH17BE3350 { get { return new ScannerFile("01_lp_letters_low\\0x17BE3350.mp3", "0x17BE3350", "lp_letters_low"); } }
    //    public static ScannerFile HASH18F531BA { get { return new ScannerFile("01_lp_letters_low\\0x18F531BA.mp3", "0x18F531BA", "lp_letters_low"); } }
    //    public static ScannerFile HASH18F83C11 { get { return new ScannerFile("01_lp_letters_low\\0x18F83C11.mp3", "0x18F83C11", "lp_letters_low"); } }
    //    public static ScannerFile HASH192F773C { get { return new ScannerFile("01_lp_letters_low\\0x192F773C.mp3", "0x192F773C", "lp_letters_low"); } }
    //    public static ScannerFile HASH1B56ADC8 { get { return new ScannerFile("01_lp_letters_low\\0x1B56ADC8.mp3", "0x1B56ADC8", "lp_letters_low"); } }
    //    public static ScannerFile HASH1C1CE18D { get { return new ScannerFile("01_lp_letters_low\\0x1C1CE18D.mp3", "0x1C1CE18D", "lp_letters_low"); } }
    //    public static ScannerFile HASH1C49E292 { get { return new ScannerFile("01_lp_letters_low\\0x1C49E292.mp3", "0x1C49E292", "lp_letters_low"); } }
    //    public static ScannerFile HASH1CEB0504 { get { return new ScannerFile("01_lp_letters_low\\0x1CEB0504.mp3", "0x1CEB0504", "lp_letters_low"); } }
    //    public static ScannerFile HASH1CEFAECF { get { return new ScannerFile("01_lp_letters_low\\0x1CEFAECF.mp3", "0x1CEFAECF", "lp_letters_low"); } }
    //    public static ScannerFile HASH1CFE711A { get { return new ScannerFile("01_lp_letters_low\\0x1CFE711A.mp3", "0x1CFE711A", "lp_letters_low"); } }
    //    public static ScannerFile HASH1E2EF14D { get { return new ScannerFile("01_lp_letters_low\\0x1E2EF14D.mp3", "0x1E2EF14D", "lp_letters_low"); } }
    //    public static ScannerFile HASH1E6B3DD7 { get { return new ScannerFile("01_lp_letters_low\\0x1E6B3DD7.mp3", "0x1E6B3DD7", "lp_letters_low"); } }
    //    public static ScannerFile HASH1ED86465 { get { return new ScannerFile("01_lp_letters_low\\0x1ED86465.mp3", "0x1ED86465", "lp_letters_low"); } }
    //    public static ScannerFile HASH1F7AA846 { get { return new ScannerFile("01_lp_letters_low\\0x1F7AA846.mp3", "0x1F7AA846", "lp_letters_low"); } }
    //}
    public class lp_numbers
    {
        public static ScannerFile Zero { get { return new ScannerFile("01_lp_numbers\\0x04F3CC0F.mp3", "0", "lp_numbers"); } }
        public static ScannerFile Zero1 { get { return new ScannerFile("01_lp_numbers\\0x02A288B0.mp3", "0", "lp_numbers"); } }
        public static ScannerFile Zero2 { get { return new ScannerFile("01_lp_numbers\\0x03B8B23A.mp3", "0", "lp_numbers"); } }
        public static ScannerFile Zero3 { get { return new ScannerFile("01_lp_numbers\\0x001F8998.mp3", "0", "lp_numbers"); } }
        public static ScannerFile Zero4 { get { return new ScannerFile("01_lp_numbers\\0x0BA6ADB6.mp3", "0", "lp_numbers"); } }

        public static ScannerFile One { get { return new ScannerFile("01_lp_numbers\\0x0100252F.mp3", "1", "lp_numbers"); } }
        public static ScannerFile One1 { get { return new ScannerFile("01_lp_numbers\\0x0945F55C.mp3", "1", "lp_numbers"); } }
        public static ScannerFile One2 { get { return new ScannerFile("01_lp_numbers\\0x0A44E2A4.mp3", "1", "lp_numbers"); } }
        public static ScannerFile One3 { get { return new ScannerFile("01_lp_numbers\\0x0AB5A365.mp3", "1", "lp_numbers"); } }
        public static ScannerFile One4 { get { return new ScannerFile("01_lp_numbers\\0x0B053108.mp3", "1", "lp_numbers"); } }
        public static ScannerFile One5 { get { return new ScannerFile("01_lp_numbers\\0x0B0CEFA0.mp3", "1", "lp_numbers"); } }

        public static ScannerFile Two { get { return new ScannerFile("01_lp_numbers\\0x02E5EEC0.mp3", "2", "lp_numbers"); } }
        public static ScannerFile Two1 { get { return new ScannerFile("01_lp_numbers\\0x03BEB046.mp3", "2", "lp_numbers"); } }
        public static ScannerFile Two2 { get { return new ScannerFile("01_lp_numbers\\0x03C6BD7E.mp3", "2", "lp_numbers"); } }
        public static ScannerFile Two3 { get { return new ScannerFile("01_lp_numbers\\0x09B8F8B2.mp3", "2", "lp_numbers"); } }
        public static ScannerFile Two4 { get { return new ScannerFile("01_lp_numbers\\0x09E3959A.mp3", "2", "lp_numbers"); } }
        public static ScannerFile Two5 { get { return new ScannerFile("01_lp_numbers\\0x0A21BD3A.mp3", "2", "lp_numbers"); } }

        public static ScannerFile Three { get { return new ScannerFile("01_lp_numbers\\0x060BDED7.mp3", "3", "lp_numbers"); } }
        public static ScannerFile Three1 { get { return new ScannerFile("01_lp_numbers\\0x0866698B.mp3", "3", "lp_numbers"); } }
        public static ScannerFile Three2 { get { return new ScannerFile("01_lp_numbers\\0x0B624017.mp3", "3", "lp_numbers"); } }

        public static ScannerFile Four { get { return new ScannerFile("01_lp_numbers\\0x02886760.mp3", "4", "lp_numbers"); } }
        public static ScannerFile Four1 { get { return new ScannerFile("01_lp_numbers\\0x03C3D7A1.mp3", "4", "lp_numbers"); } }
        public static ScannerFile Four2 { get { return new ScannerFile("01_lp_numbers\\0x041D81A4.mp3", "4", "lp_numbers"); } }
        public static ScannerFile Four3 { get { return new ScannerFile("01_lp_numbers\\0x04E9AB5B.mp3", "4", "lp_numbers"); } }
        public static ScannerFile Four4 { get { return new ScannerFile("01_lp_numbers\\0x08A07389.mp3", "4", "lp_numbers"); } }
        public static ScannerFile Four5 { get { return new ScannerFile("01_lp_numbers\\0x0AC34F2D.mp3", "4", "lp_numbers"); } }
        public static ScannerFile Four6 { get { return new ScannerFile("01_lp_numbers\\0x0B193882.mp3", "4", "lp_numbers"); } }

        public static ScannerFile Five { get { return new ScannerFile("01_lp_numbers\\0x034F92AA.mp3", "5", "lp_numbers"); } }
        public static ScannerFile Five1 { get { return new ScannerFile("01_lp_numbers\\0x057A4C20.mp3", "5", "lp_numbers"); } }
        public static ScannerFile Five2 { get { return new ScannerFile("01_lp_numbers\\0x07DC8B99.mp3", "5", "lp_numbers"); } }
        public static ScannerFile Five3 { get { return new ScannerFile("01_lp_numbers\\0x084F6895.mp3", "5", "lp_numbers"); } }

        public static ScannerFile Six { get { return new ScannerFile("01_lp_numbers\\0x00717979.mp3", "6", "lp_numbers"); } }
        public static ScannerFile Six1 { get { return new ScannerFile("01_lp_numbers\\0x01C22022.mp3", "6", "lp_numbers"); } }
        public static ScannerFile Six2 { get { return new ScannerFile("01_lp_numbers\\0x056635CE.mp3", "6", "lp_numbers"); } }
        public static ScannerFile Six3 { get { return new ScannerFile("01_lp_numbers\\0x072B44F1.mp3", "6", "lp_numbers"); } }
        public static ScannerFile Six4 { get { return new ScannerFile("01_lp_numbers\\0x0BC33189.mp3", "6", "lp_numbers"); } }

        public static ScannerFile Seven { get { return new ScannerFile("01_lp_numbers\\0x009E8E85.mp3", "7", "lp_numbers"); } }
        public static ScannerFile Seven1 { get { return new ScannerFile("01_lp_numbers\\0x0250392E.mp3", "7", "lp_numbers"); } }
        public static ScannerFile Seven2 { get { return new ScannerFile("01_lp_numbers\\0x08193D1F.mp3", "7", "lp_numbers"); } }
        public static ScannerFile Seven3 { get { return new ScannerFile("01_lp_numbers\\0x08DA0642.mp3", "7", "lp_numbers"); } }
        public static ScannerFile Seven4 { get { return new ScannerFile("01_lp_numbers\\0x0A520191.mp3", "7", "lp_numbers"); } }

        public static ScannerFile Eight { get { return new ScannerFile("01_lp_numbers\\0x00896952.mp3", "8", "lp_numbers"); } }
        public static ScannerFile Eight1 { get { return new ScannerFile("01_lp_numbers\\0x020E8A21.mp3", "8", "lp_numbers"); } }
        public static ScannerFile Eight2 { get { return new ScannerFile("01_lp_numbers\\0x02267CBE.mp3", "8", "lp_numbers"); } }
        public static ScannerFile Eight3 { get { return new ScannerFile("01_lp_numbers\\0x0702944B.mp3", "8", "lp_numbers"); } }
        public static ScannerFile Eight4 { get { return new ScannerFile("01_lp_numbers\\0x0738B2AC.mp3", "8", "lp_numbers"); } }
        public static ScannerFile Eight5 { get { return new ScannerFile("01_lp_numbers\\0x0B06D7D8.mp3", "8", "lp_numbers"); } }

        public static ScannerFile Nine { get { return new ScannerFile("01_lp_numbers\\0x0083267E.mp3", "9", "lp_numbers"); } }
        public static ScannerFile Niner { get { return new ScannerFile("01_lp_numbers\\0x04391135.mp3", "Niner", "lp_numbers"); } }
        public static ScannerFile Niner1 { get { return new ScannerFile("01_lp_numbers\\0x04E10A53.mp3", "Niner", "lp_numbers"); } }
        public static ScannerFile Niner2 { get { return new ScannerFile("01_lp_numbers\\0x0AC5F426.mp3", "Niner", "lp_numbers"); } }
        public static ScannerFile Niner3 { get { return new ScannerFile("01_lp_numbers\\0x0B111513.mp3", "Niner", "lp_numbers"); } }

        public static ScannerFile HASH0BD3DC4A { get { return new ScannerFile("01_lp_numbers\\0x0BD3DC4A.mp3", "0x0BD3DC4A", "lp_numbers"); } }
        public static ScannerFile HASH0BDF3B4E { get { return new ScannerFile("01_lp_numbers\\0x0BDF3B4E.mp3", "0x0BDF3B4E", "lp_numbers"); } }
        public static ScannerFile HASH0C475100 { get { return new ScannerFile("01_lp_numbers\\0x0C475100.mp3", "0x0C475100", "lp_numbers"); } }
        public static ScannerFile HASH0D0A9A07 { get { return new ScannerFile("01_lp_numbers\\0x0D0A9A07.mp3", "0x0D0A9A07", "lp_numbers"); } }
        public static ScannerFile HASH0E059625 { get { return new ScannerFile("01_lp_numbers\\0x0E059625.mp3", "0x0E059625", "lp_numbers"); } }
        public static ScannerFile HASH0E326A5E { get { return new ScannerFile("01_lp_numbers\\0x0E326A5E.mp3", "0x0E326A5E", "lp_numbers"); } }
        public static ScannerFile HASH0E5738DB { get { return new ScannerFile("01_lp_numbers\\0x0E5738DB.mp3", "0x0E5738DB", "lp_numbers"); } }
        public static ScannerFile HASH0E5D7871 { get { return new ScannerFile("01_lp_numbers\\0x0E5D7871.mp3", "0x0E5D7871", "lp_numbers"); } }
        public static ScannerFile HASH0F57708C { get { return new ScannerFile("01_lp_numbers\\0x0F57708C.mp3", "0x0F57708C", "lp_numbers"); } }
        public static ScannerFile HASH0F5C49C5 { get { return new ScannerFile("01_lp_numbers\\0x0F5C49C5.mp3", "0x0F5C49C5", "lp_numbers"); } }
        public static ScannerFile HASH0F684FCA { get { return new ScannerFile("01_lp_numbers\\0x0F684FCA.mp3", "0x0F684FCA", "lp_numbers"); } }
        public static ScannerFile HASH0F6A7978 { get { return new ScannerFile("01_lp_numbers\\0x0F6A7978.mp3", "0x0F6A7978", "lp_numbers"); } }
        public static ScannerFile HASH0FA44161 { get { return new ScannerFile("01_lp_numbers\\0x0FA44161.mp3", "0x0FA44161", "lp_numbers"); } }
        public static ScannerFile HASH0FF332A5 { get { return new ScannerFile("01_lp_numbers\\0x0FF332A5.mp3", "0x0FF332A5", "lp_numbers"); } }
        public static ScannerFile HASH1005A74F { get { return new ScannerFile("01_lp_numbers\\0x1005A74F.mp3", "0x1005A74F", "lp_numbers"); } }
        public static ScannerFile HASH100925CC { get { return new ScannerFile("01_lp_numbers\\0x100925CC.mp3", "0x100925CC", "lp_numbers"); } }
        public static ScannerFile HASH1047F6FB { get { return new ScannerFile("01_lp_numbers\\0x1047F6FB.mp3", "0x1047F6FB", "lp_numbers"); } }
        public static ScannerFile HASH105D245D { get { return new ScannerFile("01_lp_numbers\\0x105D245D.mp3", "0x105D245D", "lp_numbers"); } }
        public static ScannerFile HASH109F8A35 { get { return new ScannerFile("01_lp_numbers\\0x109F8A35.mp3", "0x109F8A35", "lp_numbers"); } }
        public static ScannerFile HASH118D3334 { get { return new ScannerFile("01_lp_numbers\\0x118D3334.mp3", "0x118D3334", "lp_numbers"); } }
        public static ScannerFile HASH11A62DC2 { get { return new ScannerFile("01_lp_numbers\\0x11A62DC2.mp3", "0x11A62DC2", "lp_numbers"); } }
        public static ScannerFile HASH11D9ED0F { get { return new ScannerFile("01_lp_numbers\\0x11D9ED0F.mp3", "0x11D9ED0F", "lp_numbers"); } }
        public static ScannerFile HASH12154D1F { get { return new ScannerFile("01_lp_numbers\\0x12154D1F.mp3", "0x12154D1F", "lp_numbers"); } }
        public static ScannerFile HASH12657A9F { get { return new ScannerFile("01_lp_numbers\\0x12657A9F.mp3", "0x12657A9F", "lp_numbers"); } }
        public static ScannerFile HASH1326514D { get { return new ScannerFile("01_lp_numbers\\0x1326514D.mp3", "0x1326514D", "lp_numbers"); } }
        public static ScannerFile HASH134D0ED7 { get { return new ScannerFile("01_lp_numbers\\0x134D0ED7.mp3", "0x134D0ED7", "lp_numbers"); } }
        public static ScannerFile HASH140BA943 { get { return new ScannerFile("01_lp_numbers\\0x140BA943.mp3", "0x140BA943", "lp_numbers"); } }
        public static ScannerFile HASH14215F58 { get { return new ScannerFile("01_lp_numbers\\0x14215F58.mp3", "0x14215F58", "lp_numbers"); } }
        public static ScannerFile HASH146411BD { get { return new ScannerFile("01_lp_numbers\\0x146411BD.mp3", "0x146411BD", "lp_numbers"); } }
        public static ScannerFile HASH14692C3D { get { return new ScannerFile("01_lp_numbers\\0x14692C3D.mp3", "0x14692C3D", "lp_numbers"); } }
        public static ScannerFile HASH146FE1F7 { get { return new ScannerFile("01_lp_numbers\\0x146FE1F7.mp3", "0x146FE1F7", "lp_numbers"); } }
        public static ScannerFile HASH14789B9E { get { return new ScannerFile("01_lp_numbers\\0x14789B9E.mp3", "0x14789B9E", "lp_numbers"); } }
        public static ScannerFile HASH148662B3 { get { return new ScannerFile("01_lp_numbers\\0x148662B3.mp3", "0x148662B3", "lp_numbers"); } }
        public static ScannerFile HASH14C60314 { get { return new ScannerFile("01_lp_numbers\\0x14C60314.mp3", "0x14C60314", "lp_numbers"); } }
        public static ScannerFile HASH1504CC53 { get { return new ScannerFile("01_lp_numbers\\0x1504CC53.mp3", "0x1504CC53", "lp_numbers"); } }
        public static ScannerFile HASH151F0732 { get { return new ScannerFile("01_lp_numbers\\0x151F0732.mp3", "0x151F0732", "lp_numbers"); } }
        public static ScannerFile HASH158DD629 { get { return new ScannerFile("01_lp_numbers\\0x158DD629.mp3", "0x158DD629", "lp_numbers"); } }
        public static ScannerFile HASH15BA4CFC { get { return new ScannerFile("01_lp_numbers\\0x15BA4CFC.mp3", "0x15BA4CFC", "lp_numbers"); } }
        public static ScannerFile HASH15BB0EA5 { get { return new ScannerFile("01_lp_numbers\\0x15BB0EA5.mp3", "0x15BB0EA5", "lp_numbers"); } }
        public static ScannerFile HASH15FED6C9 { get { return new ScannerFile("01_lp_numbers\\0x15FED6C9.mp3", "0x15FED6C9", "lp_numbers"); } }
        public static ScannerFile HASH161DACCC { get { return new ScannerFile("01_lp_numbers\\0x161DACCC.mp3", "0x161DACCC", "lp_numbers"); } }
        public static ScannerFile HASH1657B158 { get { return new ScannerFile("01_lp_numbers\\0x1657B158.mp3", "0x1657B158", "lp_numbers"); } }
        public static ScannerFile HASH1669BA1A { get { return new ScannerFile("01_lp_numbers\\0x1669BA1A.mp3", "0x1669BA1A", "lp_numbers"); } }
        public static ScannerFile HASH16A14539 { get { return new ScannerFile("01_lp_numbers\\0x16A14539.mp3", "0x16A14539", "lp_numbers"); } }
        public static ScannerFile HASH16BEAFA4 { get { return new ScannerFile("01_lp_numbers\\0x16BEAFA4.mp3", "0x16BEAFA4", "lp_numbers"); } }
        public static ScannerFile HASH16ECC442 { get { return new ScannerFile("01_lp_numbers\\0x16ECC442.mp3", "0x16ECC442", "lp_numbers"); } }
        public static ScannerFile HASH18093005 { get { return new ScannerFile("01_lp_numbers\\0x18093005.mp3", "0x18093005", "lp_numbers"); } }
        public static ScannerFile HASH182B594D { get { return new ScannerFile("01_lp_numbers\\0x182B594D.mp3", "0x182B594D", "lp_numbers"); } }
        public static ScannerFile HASH188A2706 { get { return new ScannerFile("01_lp_numbers\\0x188A2706.mp3", "0x188A2706", "lp_numbers"); } }
        public static ScannerFile HASH188F221E { get { return new ScannerFile("01_lp_numbers\\0x188F221E.mp3", "0x188F221E", "lp_numbers"); } }
        public static ScannerFile HASH18A43F66 { get { return new ScannerFile("01_lp_numbers\\0x18A43F66.mp3", "0x18A43F66", "lp_numbers"); } }
        public static ScannerFile HASH1900D63B { get { return new ScannerFile("01_lp_numbers\\0x1900D63B.mp3", "0x1900D63B", "lp_numbers"); } }
        public static ScannerFile HASH192C90F3 { get { return new ScannerFile("01_lp_numbers\\0x192C90F3.mp3", "0x192C90F3", "lp_numbers"); } }
        public static ScannerFile HASH1952F85E { get { return new ScannerFile("01_lp_numbers\\0x1952F85E.mp3", "0x1952F85E", "lp_numbers"); } }
        public static ScannerFile HASH195A091D { get { return new ScannerFile("01_lp_numbers\\0x195A091D.mp3", "0x195A091D", "lp_numbers"); } }
        public static ScannerFile HASH196A34A7 { get { return new ScannerFile("01_lp_numbers\\0x196A34A7.mp3", "0x196A34A7", "lp_numbers"); } }
        public static ScannerFile HASH1970FBA7 { get { return new ScannerFile("01_lp_numbers\\0x1970FBA7.mp3", "0x1970FBA7", "lp_numbers"); } }
        public static ScannerFile HASH197574B5 { get { return new ScannerFile("01_lp_numbers\\0x197574B5.mp3", "0x197574B5", "lp_numbers"); } }
        public static ScannerFile HASH19984137 { get { return new ScannerFile("01_lp_numbers\\0x19984137.mp3", "0x19984137", "lp_numbers"); } }
        public static ScannerFile HASH19E87FDC { get { return new ScannerFile("01_lp_numbers\\0x19E87FDC.mp3", "0x19E87FDC", "lp_numbers"); } }
        public static ScannerFile HASH1A41A730 { get { return new ScannerFile("01_lp_numbers\\0x1A41A730.mp3", "0x1A41A730", "lp_numbers"); } }
        public static ScannerFile HASH1A580D70 { get { return new ScannerFile("01_lp_numbers\\0x1A580D70.mp3", "0x1A580D70", "lp_numbers"); } }
        public static ScannerFile HASH1A9A4FD7 { get { return new ScannerFile("01_lp_numbers\\0x1A9A4FD7.mp3", "0x1A9A4FD7", "lp_numbers"); } }
        public static ScannerFile HASH1AF8440B { get { return new ScannerFile("01_lp_numbers\\0x1AF8440B.mp3", "0x1AF8440B", "lp_numbers"); } }
        public static ScannerFile HASH1B3B522D { get { return new ScannerFile("01_lp_numbers\\0x1B3B522D.mp3", "0x1B3B522D", "lp_numbers"); } }
        public static ScannerFile HASH1B5AC892 { get { return new ScannerFile("01_lp_numbers\\0x1B5AC892.mp3", "0x1B5AC892", "lp_numbers"); } }
        public static ScannerFile HASH1B5E13AF { get { return new ScannerFile("01_lp_numbers\\0x1B5E13AF.mp3", "0x1B5E13AF", "lp_numbers"); } }
        public static ScannerFile HASH1C30743F { get { return new ScannerFile("01_lp_numbers\\0x1C30743F.mp3", "0x1C30743F", "lp_numbers"); } }
        public static ScannerFile HASH1CCC3889 { get { return new ScannerFile("01_lp_numbers\\0x1CCC3889.mp3", "0x1CCC3889", "lp_numbers"); } }
        public static ScannerFile HASH1D20A337 { get { return new ScannerFile("01_lp_numbers\\0x1D20A337.mp3", "0x1D20A337", "lp_numbers"); } }
        public static ScannerFile HASH1D3F9FF7 { get { return new ScannerFile("01_lp_numbers\\0x1D3F9FF7.mp3", "0x1D3F9FF7", "lp_numbers"); } }
        public static ScannerFile HASH1D49BE35 { get { return new ScannerFile("01_lp_numbers\\0x1D49BE35.mp3", "0x1D49BE35", "lp_numbers"); } }
        public static ScannerFile HASH1DA41775 { get { return new ScannerFile("01_lp_numbers\\0x1DA41775.mp3", "0x1DA41775", "lp_numbers"); } }
        public static ScannerFile HASH1DC8568D { get { return new ScannerFile("01_lp_numbers\\0x1DC8568D.mp3", "0x1DC8568D", "lp_numbers"); } }
        public static ScannerFile HASH1DEE5E25 { get { return new ScannerFile("01_lp_numbers\\0x1DEE5E25.mp3", "0x1DEE5E25", "lp_numbers"); } }
        public static ScannerFile HASH1DF45254 { get { return new ScannerFile("01_lp_numbers\\0x1DF45254.mp3", "0x1DF45254", "lp_numbers"); } }
        public static ScannerFile HASH1E1EA590 { get { return new ScannerFile("01_lp_numbers\\0x1E1EA590.mp3", "0x1E1EA590", "lp_numbers"); } }
        public static ScannerFile HASH1E3F03C2 { get { return new ScannerFile("01_lp_numbers\\0x1E3F03C2.mp3", "0x1E3F03C2", "lp_numbers"); } }
        public static ScannerFile HASH1E7FA2425 { get { return new ScannerFile("01_lp_numbers\\0x1E7FA242.mp3", "0x1E7FA242", "lp_numbers"); } }
        public static ScannerFile HASH1EF897F4 { get { return new ScannerFile("01_lp_numbers\\0x1EF897F4.mp3", "0x1EF897F4", "lp_numbers"); } }
        public static ScannerFile Seven5 { get { return new ScannerFile("01_lp_numbers\\0x1F858981.mp3", "0x1F858981", "lp_numbers"); } }
        public static ScannerFile Six5 { get { return new ScannerFile("01_lp_numbers\\0x1F869BAC.mp3", "0x1F869BAC", "lp_numbers"); } }
    }
    public class manufacturer
    {
        public static ScannerFile Thrifter { get { return new ScannerFile("01_manufacturer\\0x0A69F4AC.mp3", "Thrifter(?)", "manufacturer"); } }
        public static ScannerFile ALBANY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_ALBANY_01.mp3", "MANUFACTURER_ALBANY_01", "manufacturer"); } }
        public static ScannerFile ANNIS01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_ANNIS_01.mp3", "MANUFACTURER_ANNIS_01", "manufacturer"); } }
        public static ScannerFile ARMY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_ARMY_01.mp3", "MANUFACTURER_ARMY_01", "manufacturer"); } }
        public static ScannerFile BENEFACTOR01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_BENEFACTOR_01.mp3", "MANUFACTURER_BENEFACTOR_01", "manufacturer"); } }
        public static ScannerFile BF01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_BF_01.mp3", "MANUFACTURER_BF_01", "manufacturer"); } }
        public static ScannerFile BOLLOKAN01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_BOLLOKAN_01.mp3", "MANUFACTURER_BOLLOKAN_01", "manufacturer"); } }
        public static ScannerFile BRAVADO01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_BRAVADO_01.mp3", "MANUFACTURER_BRAVADO_01", "manufacturer"); } }
        public static ScannerFile BRUTE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_BRUTE_01.mp3", "MANUFACTURER_BRUTE_01", "manufacturer"); } }
        public static ScannerFile CANIS01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_CANIS_01.mp3", "MANUFACTURER_CANIS_01", "manufacturer"); } }
        public static ScannerFile CHARIOT01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_CHARIOT_01.mp3", "MANUFACTURER_CHARIOT_01", "manufacturer"); } }
        public static ScannerFile CHEVAL01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_CHEVAL_01.mp3", "MANUFACTURER_CHEVAL_01", "manufacturer"); } }
        public static ScannerFile CLASSIQUE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_CLASSIQUE_01.mp3", "MANUFACTURER_CLASSIQUE_01", "manufacturer"); } }
        public static ScannerFile COIL01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_COIL_01.mp3", "MANUFACTURER_COIL_01", "manufacturer"); } }
        public static ScannerFile CUSTOM01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_CUSTOM_01.mp3", "MANUFACTURER_CUSTOM_01", "manufacturer"); } }
        public static ScannerFile DECLASSE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_DECLASSE_01.mp3", "MANUFACTURER_DECLASSE_01", "manufacturer"); } }
        public static ScannerFile DEWBAUCHEE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_DEWBAUCHEE_01.mp3", "MANUFACTURER_DEWBAUCHEE_01", "manufacturer"); } }
        public static ScannerFile DINKA01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_DINKA_01.mp3", "MANUFACTURER_DINKA_01", "manufacturer"); } }
        public static ScannerFile DUNDREARY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_DUNDREARY_01.mp3", "MANUFACTURER_DUNDREARY_01", "manufacturer"); } }
        public static ScannerFile EMERGENCY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_EMERGENCY_01.mp3", "MANUFACTURER_EMERGENCY_01", "manufacturer"); } }
        public static ScannerFile EMPEROR01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_EMPEROR_01.mp3", "MANUFACTURER_EMPEROR_01", "manufacturer"); } }
        public static ScannerFile EMPORER01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_EMPORER_01.mp3", "MANUFACTURER_EMPORER_01", "manufacturer"); } }
        public static ScannerFile ENUS01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_ENUS_01.mp3", "MANUFACTURER_ENUS_01", "manufacturer"); } }
        public static ScannerFile FATHOM01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_FATHOM_01.mp3", "MANUFACTURER_FATHOM_01", "manufacturer"); } }
        public static ScannerFile FIB01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_FIB_01.mp3", "MANUFACTURER_FIB_01", "manufacturer"); } }
        public static ScannerFile GALLIVANTER01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_GALLIVANTER_01.mp3", "MANUFACTURER_GALLIVANTER_01", "manufacturer"); } }
        public static ScannerFile GOPOSTAL01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_GO_POSTAL_01.mp3", "MANUFACTURER_GO_POSTAL_01", "manufacturer"); } }
        public static ScannerFile GROTTI01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_GROTTI_01.mp3", "MANUFACTURER_GROTTI_01", "manufacturer"); } }
        public static ScannerFile HIJAK01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_HIJAK_01.mp3", "MANUFACTURER_HIJAK_01", "manufacturer"); } }
        public static ScannerFile HVY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_HVY_01.mp3", "MANUFACTURER_HVY_01", "manufacturer"); } }
        public static ScannerFile IMPONTE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_IMPONTE_01.mp3", "MANUFACTURER_IMPONTE_01", "manufacturer"); } }
        public static ScannerFile INVETERO01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_INVETERO_01.mp3", "MANUFACTURER_INVETERO_01", "manufacturer"); } }
        public static ScannerFile JACKSHEEPE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_JACK_SHEEPE_01.mp3", "MANUFACTURER_JACK_SHEEPE_01", "manufacturer"); } }
        public static ScannerFile JOEBUILT01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_JOEBUILT_01.mp3", "MANUFACTURER_JOEBUILT_01", "manufacturer"); } }
        public static ScannerFile KARIN01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_KARIN_01.mp3", "MANUFACTURER_KARIN_01", "manufacturer"); } }
        public static ScannerFile LAMPADATI01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_LAMPADATI_01.mp3", "MANUFACTURER_LAMPADATI_01", "manufacturer"); } }
        public static ScannerFile MAIBATSU01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_MAIBATSU_01.mp3", "MANUFACTURER_MAIBATSU_01", "manufacturer"); } }
        public static ScannerFile MAMMOTH01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_MAMMOTH_01.mp3", "MANUFACTURER_MAMMOTH_01", "manufacturer"); } }
        public static ScannerFile MILITARY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_MILITARY_01.mp3", "MANUFACTURER_MILITARY_01", "manufacturer"); } }
        public static ScannerFile MOTORCYCLEWCOMPANY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_MOTORCYCLE_W_COMPANY_01.mp3", "MANUFACTURER_MOTORCYCLE_W_COMPANY_01", "manufacturer"); } }
        public static ScannerFile MTL01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_MTL_01.mp3", "MANUFACTURER_MTL_01", "manufacturer"); } }
        public static ScannerFile NAGASAKI01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_NAGASAKI_01.mp3", "MANUFACTURER_NAGASAKI_01", "manufacturer"); } }
        public static ScannerFile OBEY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_OBEY_01.mp3", "MANUFACTURER_OBEY_01", "manufacturer"); } }
        public static ScannerFile OCELOT01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_OCELOT_01.mp3", "MANUFACTURER_OCELOT_01", "manufacturer"); } }
        public static ScannerFile OVERFLOD01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_OVERFLOD_01.mp3", "MANUFACTURER_OVERFLOD_01", "manufacturer"); } }
        public static ScannerFile PEGASI01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_PEGASI_01.mp3", "MANUFACTURER_PEGASI_01", "manufacturer"); } }
        public static ScannerFile POLICE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_POLICE_01.mp3", "MANUFACTURER_POLICE_01", "manufacturer"); } }
        public static ScannerFile PRINCIPE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_PRINCIPE_01.mp3", "MANUFACTURER_PRINCIPE_01", "manufacturer"); } }
        public static ScannerFile PROGEN01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_PROGEN_01.mp3", "MANUFACTURER_PROGEN_01", "manufacturer"); } }
        public static ScannerFile SCHYSTER01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_SCHYSTER_01.mp3", "MANUFACTURER_SCHYSTER_01", "manufacturer"); } }
        public static ScannerFile SHITZU01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_SHITZU_01.mp3", "MANUFACTURER_SHITZU_01", "manufacturer"); } }
        public static ScannerFile SKIVER01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_SKIVER_01.mp3", "MANUFACTURER_SKIVER_01", "manufacturer"); } }
        public static ScannerFile SPEEDOPHILE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_SPEEDOPHILE_01.mp3", "MANUFACTURER_SPEEDOPHILE_01", "manufacturer"); } }
        public static ScannerFile STANLEY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_STANLEY_01.mp3", "MANUFACTURER_STANLEY_01", "manufacturer"); } }
        public static ScannerFile STEELHORSE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_STEEL_HORSE_01.mp3", "MANUFACTURER_STEEL_HORSE_01", "manufacturer"); } }
        public static ScannerFile TRUFFADE01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_TRUFFADE_01.mp3", "MANUFACTURER_TRUFFADE_01", "manufacturer"); } }
        public static ScannerFile UBERMACHT01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_UBERMACHT_01.mp3", "MANUFACTURER_UBERMACHT_01", "manufacturer"); } }
        public static ScannerFile VAPID01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_VAPID_01.mp3", "MANUFACTURER_VAPID_01", "manufacturer"); } }
        public static ScannerFile VULCAR01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_VULCAR_01.mp3", "MANUFACTURER_VULCAR_01", "manufacturer"); } }
        public static ScannerFile WEENY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_WEENY_01.mp3", "MANUFACTURER_WEENY_01", "manufacturer"); } }
        public static ScannerFile WESTERNCOMPANY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_WESTERN_COMPANY_01.mp3", "MANUFACTURER_WESTERN_COMPANY_01", "manufacturer"); } }
        public static ScannerFile WESTERNMOTORCYCLECOMPANY01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_WESTERN_MOTORCYCLE_COMPANY_01.mp3", "MANUFACTURER_WESTERN_MOTORCYCLE_COMPANY_01", "manufacturer"); } }
        public static ScannerFile WILLARD01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_WILLARD_01.mp3", "MANUFACTURER_WILLARD_01", "manufacturer"); } }
        public static ScannerFile WMC01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_WMC_01.mp3", "MANUFACTURER_WMC_01", "manufacturer"); } }
        public static ScannerFile ZIRCONIUM01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_ZIRCONIUM_01.mp3", "MANUFACTURER_ZIRCONIUM_01", "manufacturer"); } }
        public static ScannerFile ZIREONIUM01 { get { return new ScannerFile("01_manufacturer\\MANUFACTURER_ZIREONIUM_01.mp3", "MANUFACTURER_ZIREONIUM_01", "manufacturer"); } }
    }
    public class model
    {
        public static ScannerFile HASH071B9975 { get { return new ScannerFile("01_model\\0x071B9975.mp3", "0x071B9975", "model"); } }
        public static ScannerFile ADDER01 { get { return new ScannerFile("01_model\\MODEL_ADDER_01.mp3", "MODEL_ADDER_01", "model"); } }
        public static ScannerFile AIRSHIP01 { get { return new ScannerFile("01_model\\MODEL_AIRSHIP_01.mp3", "MODEL_AIRSHIP_01", "model"); } }
        public static ScannerFile AIRTUG01 { get { return new ScannerFile("01_model\\MODEL_AIRTUG_01.mp3", "MODEL_AIRTUG_01", "model"); } }
        public static ScannerFile AKUMA01 { get { return new ScannerFile("01_model\\MODEL_AKUMA_01.mp3", "MODEL_AKUMA_01", "model"); } }
        public static ScannerFile AMBULANCE01 { get { return new ScannerFile("01_model\\MODEL_AMBULANCE_01.mp3", "MODEL_AMBULANCE_01", "model"); } }
        public static ScannerFile ANNIHILATOR01 { get { return new ScannerFile("01_model\\MODEL_ANNIHILATOR_01.mp3", "MODEL_ANNIHILATOR_01", "model"); } }
        public static ScannerFile ASEA01 { get { return new ScannerFile("01_model\\MODEL_ASEA_01.mp3", "MODEL_ASEA_01", "model"); } }
        public static ScannerFile ASTEROPE01 { get { return new ScannerFile("01_model\\MODEL_ASTEROPE_01.mp3", "MODEL_ASTEROPE_01", "model"); } }
        public static ScannerFile BAGGER01 { get { return new ScannerFile("01_model\\MODEL_BAGGER_01.mp3", "MODEL_BAGGER_01", "model"); } }
        public static ScannerFile BALLER01 { get { return new ScannerFile("01_model\\MODEL_BALLER_01.mp3", "MODEL_BALLER_01", "model"); } }
        public static ScannerFile BANSHEE01 { get { return new ScannerFile("01_model\\MODEL_BANSHEE_01.mp3", "MODEL_BANSHEE_01", "model"); } }
        public static ScannerFile BARRACKS01 { get { return new ScannerFile("01_model\\MODEL_BARRACKS_01.mp3", "MODEL_BARRACKS_01", "model"); } }
        public static ScannerFile BATI01 { get { return new ScannerFile("01_model\\MODEL_BATI_01.mp3", "MODEL_BATI_01", "model"); } }
        public static ScannerFile BENSON01 { get { return new ScannerFile("01_model\\MODEL_BENSON_01.mp3", "MODEL_BENSON_01", "model"); } }
        public static ScannerFile BFINJECTION01 { get { return new ScannerFile("01_model\\MODEL_BF_INJECTION_01.mp3", "MODEL_BF_INJECTION_01", "model"); } }
        public static ScannerFile BIFF01 { get { return new ScannerFile("01_model\\MODEL_BIFF_01.mp3", "MODEL_BIFF_01", "model"); } }
        public static ScannerFile BISON01 { get { return new ScannerFile("01_model\\MODEL_BISON_01.mp3", "MODEL_BISON_01", "model"); } }
        public static ScannerFile BJXL01 { get { return new ScannerFile("01_model\\MODEL_BJXL_01.mp3", "MODEL_BJXL_01", "model"); } }
        public static ScannerFile BLAZER01 { get { return new ScannerFile("01_model\\MODEL_BLAZER_01.mp3", "MODEL_BLAZER_01", "model"); } }
        public static ScannerFile BLIMP01 { get { return new ScannerFile("01_model\\MODEL_BLIMP_01.mp3", "MODEL_BLIMP_01", "model"); } }
        public static ScannerFile BLISTA01 { get { return new ScannerFile("01_model\\MODEL_BLISTA_01.mp3", "MODEL_BLISTA_01", "model"); } }
        public static ScannerFile BMX01 { get { return new ScannerFile("01_model\\MODEL_BMX_01.mp3", "MODEL_BMX_01", "model"); } }
        public static ScannerFile BOBCAT01 { get { return new ScannerFile("01_model\\MODEL_BOBCAT_01.mp3", "MODEL_BOBCAT_01", "model"); } }
        public static ScannerFile BOBCATXL01 { get { return new ScannerFile("01_model\\MODEL_BOBCAT_XL_01.mp3", "MODEL_BOBCAT_XL_01", "model"); } }
        public static ScannerFile BODHI01 { get { return new ScannerFile("01_model\\MODEL_BODHI_01.mp3", "MODEL_BODHI_01", "model"); } }
        public static ScannerFile BOXVILLE01 { get { return new ScannerFile("01_model\\MODEL_BOXVILLE_01.mp3", "MODEL_BOXVILLE_01", "model"); } }
        public static ScannerFile BUCCANEER01 { get { return new ScannerFile("01_model\\MODEL_BUCCANEER_01.mp3", "MODEL_BUCCANEER_01", "model"); } }
        public static ScannerFile BUFFALO01 { get { return new ScannerFile("01_model\\MODEL_BUFFALO_01.mp3", "MODEL_BUFFALO_01", "model"); } }
        public static ScannerFile BULLDOZER01 { get { return new ScannerFile("01_model\\MODEL_BULLDOZER_01.mp3", "MODEL_BULLDOZER_01", "model"); } }
        public static ScannerFile BULLET01 { get { return new ScannerFile("01_model\\MODEL_BULLET_01.mp3", "MODEL_BULLET_01", "model"); } }
        public static ScannerFile BULLETGT01 { get { return new ScannerFile("01_model\\MODEL_BULLET_GT_01.mp3", "MODEL_BULLET_GT_01", "model"); } }
        public static ScannerFile BURRITO01 { get { return new ScannerFile("01_model\\MODEL_BURRITO_01.mp3", "MODEL_BURRITO_01", "model"); } }
        public static ScannerFile BUS01 { get { return new ScannerFile("01_model\\MODEL_BUS_01.mp3", "MODEL_BUS_01", "model"); } }
        public static ScannerFile BUZZARD01 { get { return new ScannerFile("01_model\\MODEL_BUZZARD_01.mp3", "MODEL_BUZZARD_01", "model"); } }
        public static ScannerFile CADDY01 { get { return new ScannerFile("01_model\\MODEL_CADDY_01.mp3", "MODEL_CADDY_01", "model"); } }
        public static ScannerFile CAMPER01 { get { return new ScannerFile("01_model\\MODEL_CAMPER_01.mp3", "MODEL_CAMPER_01", "model"); } }
        public static ScannerFile CARBONIZZARE01 { get { return new ScannerFile("01_model\\MODEL_CARBONIZZARE_01.mp3", "MODEL_CARBONIZZARE_01", "model"); } }
        public static ScannerFile CARBONRS01 { get { return new ScannerFile("01_model\\MODEL_CARBON_RS_01.mp3", "MODEL_CARBON_RS_01", "model"); } }
        public static ScannerFile CARGOBOB01 { get { return new ScannerFile("01_model\\MODEL_CARGOBOB_01.mp3", "MODEL_CARGOBOB_01", "model"); } }
        public static ScannerFile CARGOPLANE01 { get { return new ScannerFile("01_model\\MODEL_CARGO_PLANE_01.mp3", "MODEL_CARGO_PLANE_01", "model"); } }
        public static ScannerFile CARGOPLANE02 { get { return new ScannerFile("01_model\\MODEL_CARGO_PLANE_02.mp3", "MODEL_CARGO_PLANE_02", "model"); } }
        public static ScannerFile CAVALCADE01 { get { return new ScannerFile("01_model\\MODEL_CAVALCADE_01.mp3", "MODEL_CAVALCADE_01", "model"); } }
        public static ScannerFile CEMENTMIXER01 { get { return new ScannerFile("01_model\\MODEL_CEMENT_MIXER_01.mp3", "MODEL_CEMENT_MIXER_01", "model"); } }
        public static ScannerFile CHEETAH01 { get { return new ScannerFile("01_model\\MODEL_CHEETAH_01.mp3", "MODEL_CHEETAH_01", "model"); } }
        public static ScannerFile COACH01 { get { return new ScannerFile("01_model\\MODEL_COACH_01.mp3", "MODEL_COACH_01", "model"); } }
        public static ScannerFile COGNOSCENTI01 { get { return new ScannerFile("01_model\\MODEL_COGNOSCENTI_01.mp3", "MODEL_COGNOSCENTI_01", "model"); } }
        public static ScannerFile COG5501 { get { return new ScannerFile("01_model\\MODEL_COG_55_01.mp3", "MODEL_COG_55_01", "model"); } }
        public static ScannerFile COGCABRIO01 { get { return new ScannerFile("01_model\\MODEL_COG_CABRIO_01.mp3", "MODEL_COG_CABRIO_01", "model"); } }
        public static ScannerFile COMET01 { get { return new ScannerFile("01_model\\MODEL_COMET_01.mp3", "MODEL_COMET_01", "model"); } }
        public static ScannerFile COQUETTE01 { get { return new ScannerFile("01_model\\MODEL_COQUETTE_01.mp3", "MODEL_COQUETTE_01", "model"); } }
        public static ScannerFile CRUISER01 { get { return new ScannerFile("01_model\\MODEL_CRUISER_01.mp3", "MODEL_CRUISER_01", "model"); } }
        public static ScannerFile CRUSADER01 { get { return new ScannerFile("01_model\\MODEL_CRUSADER_01.mp3", "MODEL_CRUSADER_01", "model"); } }
        public static ScannerFile CUBAN80001 { get { return new ScannerFile("01_model\\MODEL_CUBAN_800_01.mp3", "MODEL_CUBAN_800_01", "model"); } }
        public static ScannerFile CUTTER01 { get { return new ScannerFile("01_model\\MODEL_CUTTER_01.mp3", "MODEL_CUTTER_01", "model"); } }
        public static ScannerFile DAEMON01 { get { return new ScannerFile("01_model\\MODEL_DAEMON_01.mp3", "MODEL_DAEMON_01", "model"); } }
        public static ScannerFile DIGGER01 { get { return new ScannerFile("01_model\\MODEL_DIGGER_01.mp3", "MODEL_DIGGER_01", "model"); } }
        public static ScannerFile DILETTANTE01 { get { return new ScannerFile("01_model\\MODEL_DILETTANTE_01.mp3", "MODEL_DILETTANTE_01", "model"); } }
        public static ScannerFile DINGHY01 { get { return new ScannerFile("01_model\\MODEL_DINGHY_01.mp3", "MODEL_DINGHY_01", "model"); } }
        public static ScannerFile DOCKTUG01 { get { return new ScannerFile("01_model\\MODEL_DOCK_TUG_01.mp3", "MODEL_DOCK_TUG_01", "model"); } }
        public static ScannerFile DOMINATOR01 { get { return new ScannerFile("01_model\\MODEL_DOMINATOR_01.mp3", "MODEL_DOMINATOR_01", "model"); } }
        public static ScannerFile DOUBLE01 { get { return new ScannerFile("01_model\\MODEL_DOUBLE_01.mp3", "MODEL_DOUBLE_01", "model"); } }
        public static ScannerFile DOUBLET01 { get { return new ScannerFile("01_model\\MODEL_DOUBLE_T_01.mp3", "MODEL_DOUBLE_T_01", "model"); } }
        public static ScannerFile DUBSTA01 { get { return new ScannerFile("01_model\\MODEL_DUBSTA_01.mp3", "MODEL_DUBSTA_01", "model"); } }
        public static ScannerFile DUKES01 { get { return new ScannerFile("01_model\\MODEL_DUKES_01.mp3", "MODEL_DUKES_01", "model"); } }
        public static ScannerFile DUMPER01 { get { return new ScannerFile("01_model\\MODEL_DUMPER_01.mp3", "MODEL_DUMPER_01", "model"); } }
        public static ScannerFile DUMP01 { get { return new ScannerFile("01_model\\MODEL_DUMP_01.mp3", "MODEL_DUMP_01", "model"); } }
        public static ScannerFile DUNELOADER01 { get { return new ScannerFile("01_model\\MODEL_DUNELOADER_01.mp3", "MODEL_DUNELOADER_01", "model"); } }
        public static ScannerFile DUNE01 { get { return new ScannerFile("01_model\\MODEL_DUNE_01.mp3", "MODEL_DUNE_01", "model"); } }
        public static ScannerFile DUNEBUGGY01 { get { return new ScannerFile("01_model\\MODEL_DUNE_BUGGY_01.mp3", "MODEL_DUNE_BUGGY_01", "model"); } }
        public static ScannerFile DUSTER01 { get { return new ScannerFile("01_model\\MODEL_DUSTER_01.mp3", "MODEL_DUSTER_01", "model"); } }
        public static ScannerFile ELEGY01 { get { return new ScannerFile("01_model\\MODEL_ELEGY_01.mp3", "MODEL_ELEGY_01", "model"); } }
        public static ScannerFile EMPEROR01 { get { return new ScannerFile("01_model\\MODEL_EMPEROR_01.mp3", "MODEL_EMPEROR_01", "model"); } }
        public static ScannerFile ENTITYXF01 { get { return new ScannerFile("01_model\\MODEL_ENTITY_XF_01.mp3", "MODEL_ENTITY_XF_01", "model"); } }
        public static ScannerFile EOD01 { get { return new ScannerFile("01_model\\MODEL_EOD_01.mp3", "MODEL_EOD_01", "model"); } }
        public static ScannerFile EXEMPLAR01 { get { return new ScannerFile("01_model\\MODEL_EXEMPLAR_01.mp3", "MODEL_EXEMPLAR_01", "model"); } }
        public static ScannerFile F62001 { get { return new ScannerFile("01_model\\MODEL_F620_01.mp3", "MODEL_F620_01", "model"); } }
        public static ScannerFile FACTION01 { get { return new ScannerFile("01_model\\MODEL_FACTION_01.mp3", "MODEL_FACTION_01", "model"); } }
        public static ScannerFile FAGGIO01 { get { return new ScannerFile("01_model\\MODEL_FAGGIO_01.mp3", "MODEL_FAGGIO_01", "model"); } }
        public static ScannerFile FELON01 { get { return new ScannerFile("01_model\\MODEL_FELON_01.mp3", "MODEL_FELON_01", "model"); } }
        public static ScannerFile FELTZER01 { get { return new ScannerFile("01_model\\MODEL_FELTZER_01.mp3", "MODEL_FELTZER_01", "model"); } }
        public static ScannerFile FEROCI01 { get { return new ScannerFile("01_model\\MODEL_FEROCI_01.mp3", "MODEL_FEROCI_01", "model"); } }
        public static ScannerFile FIELDMASTER01 { get { return new ScannerFile("01_model\\MODEL_FIELDMASTER_01.mp3", "MODEL_FIELDMASTER_01", "model"); } }
        public static ScannerFile FIRETRUCK01 { get { return new ScannerFile("01_model\\MODEL_FIRETRUCK_01.mp3", "MODEL_FIRETRUCK_01", "model"); } }
        public static ScannerFile FLATBED01 { get { return new ScannerFile("01_model\\MODEL_FLATBED_01.mp3", "MODEL_FLATBED_01", "model"); } }
        public static ScannerFile FORKLIFT01 { get { return new ScannerFile("01_model\\MODEL_FORKLIFT_01.mp3", "MODEL_FORKLIFT_01", "model"); } }
        public static ScannerFile FQ201 { get { return new ScannerFile("01_model\\MODEL_FQ2_01.mp3", "MODEL_FQ2_01", "model"); } }
        public static ScannerFile FREIGHT01 { get { return new ScannerFile("01_model\\MODEL_FREIGHT_01.mp3", "MODEL_FREIGHT_01", "model"); } }
        public static ScannerFile FROGGER01 { get { return new ScannerFile("01_model\\MODEL_FROGGER_01.mp3", "MODEL_FROGGER_01", "model"); } }
        public static ScannerFile FUGITIVE01 { get { return new ScannerFile("01_model\\MODEL_FUGITIVE_01.mp3", "MODEL_FUGITIVE_01", "model"); } }
        public static ScannerFile FUSILADE01 { get { return new ScannerFile("01_model\\MODEL_FUSILADE_01.mp3", "MODEL_FUSILADE_01", "model"); } }
        public static ScannerFile FUTO01 { get { return new ScannerFile("01_model\\MODEL_FUTO_01.mp3", "MODEL_FUTO_01", "model"); } }
        public static ScannerFile GAUNTLET01 { get { return new ScannerFile("01_model\\MODEL_GAUNTLET_01.mp3", "MODEL_GAUNTLET_01", "model"); } }
        public static ScannerFile GRANGER01 { get { return new ScannerFile("01_model\\MODEL_GRANGER_01.mp3", "MODEL_GRANGER_01", "model"); } }
        public static ScannerFile GRESLEY01 { get { return new ScannerFile("01_model\\MODEL_GRESLEY_01.mp3", "MODEL_GRESLEY_01", "model"); } }
        public static ScannerFile HABANERO01 { get { return new ScannerFile("01_model\\MODEL_HABANERO_01.mp3", "MODEL_HABANERO_01", "model"); } }
        public static ScannerFile HAKUMAI01 { get { return new ScannerFile("01_model\\MODEL_HAKUMAI_01.mp3", "MODEL_HAKUMAI_01", "model"); } }
        public static ScannerFile HANDLER01 { get { return new ScannerFile("01_model\\MODEL_HANDLER_01.mp3", "MODEL_HANDLER_01", "model"); } }
        public static ScannerFile HAULER01 { get { return new ScannerFile("01_model\\MODEL_HAULER_01.mp3", "MODEL_HAULER_01", "model"); } }
        public static ScannerFile HEARSE01 { get { return new ScannerFile("01_model\\MODEL_HEARSE_01.mp3", "MODEL_HEARSE_01", "model"); } }
        public static ScannerFile HELLFURY01 { get { return new ScannerFile("01_model\\MODEL_HELLFURY_01.mp3", "MODEL_HELLFURY_01", "model"); } }
        public static ScannerFile HEXER01 { get { return new ScannerFile("01_model\\MODEL_HEXER_01.mp3", "MODEL_HEXER_01", "model"); } }
        public static ScannerFile HOTKNIFE01 { get { return new ScannerFile("01_model\\MODEL_HOT_KNIFE_01.mp3", "MODEL_HOT_KNIFE_01", "model"); } }
        public static ScannerFile HUNTER01 { get { return new ScannerFile("01_model\\MODEL_HUNTER_01.mp3", "MODEL_HUNTER_01", "model"); } }
        public static ScannerFile INFERNUS01 { get { return new ScannerFile("01_model\\MODEL_INFERNUS_01.mp3", "MODEL_INFERNUS_01", "model"); } }
        public static ScannerFile INGOT01 { get { return new ScannerFile("01_model\\MODEL_INGOT_01.mp3", "MODEL_INGOT_01", "model"); } }
        public static ScannerFile INTRUDER01 { get { return new ScannerFile("01_model\\MODEL_INTRUDER_01.mp3", "MODEL_INTRUDER_01", "model"); } }
        public static ScannerFile ISSI01 { get { return new ScannerFile("01_model\\MODEL_ISSI_01.mp3", "MODEL_ISSI_01", "model"); } }
        public static ScannerFile JACKAL01 { get { return new ScannerFile("01_model\\MODEL_JACKAL_01.mp3", "MODEL_JACKAL_01", "model"); } }
        public static ScannerFile JB70001 { get { return new ScannerFile("01_model\\MODEL_JB700_01.mp3", "MODEL_JB700_01", "model"); } }
        public static ScannerFile JETMAX01 { get { return new ScannerFile("01_model\\MODEL_JETMAX_01.mp3", "MODEL_JETMAX_01", "model"); } }
        public static ScannerFile JET01 { get { return new ScannerFile("01_model\\MODEL_JET_01.mp3", "MODEL_JET_01", "model"); } }
        public static ScannerFile JOURNEY01 { get { return new ScannerFile("01_model\\MODEL_JOURNEY_01.mp3", "MODEL_JOURNEY_01", "model"); } }
        public static ScannerFile KHAMELION01 { get { return new ScannerFile("01_model\\MODEL_KHAMELION_01.mp3", "MODEL_KHAMELION_01", "model"); } }
        public static ScannerFile LANDSTALKER01 { get { return new ScannerFile("01_model\\MODEL_LANDSTALKER_01.mp3", "MODEL_LANDSTALKER_01", "model"); } }
        public static ScannerFile LAZER01 { get { return new ScannerFile("01_model\\MODEL_LAZER_01.mp3", "MODEL_LAZER_01", "model"); } }
        public static ScannerFile LIFEGUARDGRANGER01 { get { return new ScannerFile("01_model\\MODEL_LIFEGUARD_GRANGER_01.mp3", "MODEL_LIFEGUARD_GRANGER_01", "model"); } }
        public static ScannerFile MANANA01 { get { return new ScannerFile("01_model\\MODEL_MANANA_01.mp3", "MODEL_MANANA_01", "model"); } }
        public static ScannerFile MAVERICK01 { get { return new ScannerFile("01_model\\MODEL_MAVERICK_01.mp3", "MODEL_MAVERICK_01", "model"); } }
        public static ScannerFile MESA01 { get { return new ScannerFile("01_model\\MODEL_MESA_01.mp3", "MODEL_MESA_01", "model"); } }
        public static ScannerFile METROTRAIN01 { get { return new ScannerFile("01_model\\MODEL_METROTRAIN_01.mp3", "MODEL_METROTRAIN_01", "model"); } }
        public static ScannerFile MINIVAN01 { get { return new ScannerFile("01_model\\MODEL_MINIVAN_01.mp3", "MODEL_MINIVAN_01", "model"); } }
        public static ScannerFile MIXER01 { get { return new ScannerFile("01_model\\MODEL_MIXER_01.mp3", "MODEL_MIXER_01", "model"); } }
        public static ScannerFile MONROE01 { get { return new ScannerFile("01_model\\MODEL_MONROE_01.mp3", "MODEL_MONROE_01", "model"); } }
        public static ScannerFile MOWER01 { get { return new ScannerFile("01_model\\MODEL_MOWER_01.mp3", "MODEL_MOWER_01", "model"); } }
        public static ScannerFile MULE01 { get { return new ScannerFile("01_model\\MODEL_MULE_01.mp3", "MODEL_MULE_01", "model"); } }
        public static ScannerFile NEMESIS01 { get { return new ScannerFile("01_model\\MODEL_NEMESIS_01.mp3", "MODEL_NEMESIS_01", "model"); } }
        public static ScannerFile NINEF01 { get { return new ScannerFile("01_model\\MODEL_NINE_F_01.mp3", "MODEL_NINE_F_01", "model"); } }
        public static ScannerFile ORACLE01 { get { return new ScannerFile("01_model\\MODEL_ORACLE_01.mp3", "MODEL_ORACLE_01", "model"); } }
        public static ScannerFile PACKER01 { get { return new ScannerFile("01_model\\MODEL_PACKER_01.mp3", "MODEL_PACKER_01", "model"); } }
        public static ScannerFile PATRIOT01 { get { return new ScannerFile("01_model\\MODEL_PATRIOT_01.mp3", "MODEL_PATRIOT_01", "model"); } }
        public static ScannerFile PCJ60001 { get { return new ScannerFile("01_model\\MODEL_PCJ_600_01.mp3", "MODEL_PCJ_600_01", "model"); } }
        public static ScannerFile PENUMBRA01 { get { return new ScannerFile("01_model\\MODEL_PENUMBRA_01.mp3", "MODEL_PENUMBRA_01", "model"); } }
        public static ScannerFile PEYOTE01 { get { return new ScannerFile("01_model\\MODEL_PEYOTE_01.mp3", "MODEL_PEYOTE_01", "model"); } }
        public static ScannerFile PHANTOM01 { get { return new ScannerFile("01_model\\MODEL_PHANTOM_01.mp3", "MODEL_PHANTOM_01", "model"); } }
        public static ScannerFile PHOENIX01 { get { return new ScannerFile("01_model\\MODEL_PHOENIX_01.mp3", "MODEL_PHOENIX_01", "model"); } }
        public static ScannerFile PICADOR01 { get { return new ScannerFile("01_model\\MODEL_PICADOR_01.mp3", "MODEL_PICADOR_01", "model"); } }
        public static ScannerFile POLICECAR01 { get { return new ScannerFile("01_model\\MODEL_POLICE_CAR_01.mp3", "MODEL_POLICE_CAR_01", "model"); } }
        public static ScannerFile POLICEFUGITIVE01 { get { return new ScannerFile("01_model\\MODEL_POLICE_FUGITIVE_01.mp3", "MODEL_POLICE_FUGITIVE_01", "model"); } }
        public static ScannerFile POLICEMAVERICK01 { get { return new ScannerFile("01_model\\MODEL_POLICE_MAVERICK_01.mp3", "MODEL_POLICE_MAVERICK_01", "model"); } }
        public static ScannerFile POLICETRANSPORT01 { get { return new ScannerFile("01_model\\MODEL_POLICE_TRANSPORT_01.mp3", "MODEL_POLICE_TRANSPORT_01", "model"); } }
        public static ScannerFile PONY01 { get { return new ScannerFile("01_model\\MODEL_PONY_01.mp3", "MODEL_PONY_01", "model"); } }
        public static ScannerFile POUNDER01 { get { return new ScannerFile("01_model\\MODEL_POUNDER_01.mp3", "MODEL_POUNDER_01", "model"); } }
        public static ScannerFile PRAIRIE01 { get { return new ScannerFile("01_model\\MODEL_PRAIRIE_01.mp3", "MODEL_PRAIRIE_01", "model"); } }
        public static ScannerFile PREDATOR01 { get { return new ScannerFile("01_model\\MODEL_PREDATOR_01.mp3", "MODEL_PREDATOR_01", "model"); } }
        public static ScannerFile PREMIER01 { get { return new ScannerFile("01_model\\MODEL_PREMIER_01.mp3", "MODEL_PREMIER_01", "model"); } }
        public static ScannerFile PRIMO01 { get { return new ScannerFile("01_model\\MODEL_PRIMO_01.mp3", "MODEL_PRIMO_01", "model"); } }
        public static ScannerFile RADIUS01 { get { return new ScannerFile("01_model\\MODEL_RADIUS_01.mp3", "MODEL_RADIUS_01", "model"); } }
        public static ScannerFile RADI01 { get { return new ScannerFile("01_model\\MODEL_RADI_01.mp3", "MODEL_RADI_01", "model"); } }
        public static ScannerFile RANCHERXL01 { get { return new ScannerFile("01_model\\MODEL_RANCHER_XL_01.mp3", "MODEL_RANCHER_XL_01", "model"); } }
        public static ScannerFile RAPIDGT01 { get { return new ScannerFile("01_model\\MODEL_RAPID_GT_01.mp3", "MODEL_RAPID_GT_01", "model"); } }
        public static ScannerFile RATLOADER01 { get { return new ScannerFile("01_model\\MODEL_RATLOADER_01.mp3", "MODEL_RATLOADER_01", "model"); } }
        public static ScannerFile RCBANDITO01 { get { return new ScannerFile("01_model\\MODEL_RC_BANDITO_01.mp3", "MODEL_RC_BANDITO_01", "model"); } }
        public static ScannerFile REBEL01 { get { return new ScannerFile("01_model\\MODEL_REBEL_01.mp3", "MODEL_REBEL_01", "model"); } }
        public static ScannerFile REGINA01 { get { return new ScannerFile("01_model\\MODEL_REGINA_01.mp3", "MODEL_REGINA_01", "model"); } }
        public static ScannerFile RHINO01 { get { return new ScannerFile("01_model\\MODEL_RHINO_01.mp3", "MODEL_RHINO_01", "model"); } }
        public static ScannerFile RIDEONMOWER01 { get { return new ScannerFile("01_model\\MODEL_RIDE_ON_MOWER_01.mp3", "MODEL_RIDE_ON_MOWER_01", "model"); } }
        public static ScannerFile RIOT01 { get { return new ScannerFile("01_model\\MODEL_RIOT_01.mp3", "MODEL_RIOT_01", "model"); } }
        public static ScannerFile RIPLEY01 { get { return new ScannerFile("01_model\\MODEL_RIPLEY_01.mp3", "MODEL_RIPLEY_01", "model"); } }
        public static ScannerFile ROCOTO01 { get { return new ScannerFile("01_model\\MODEL_ROCOTO_01.mp3", "MODEL_ROCOTO_01", "model"); } }
        public static ScannerFile RUBBLE01 { get { return new ScannerFile("01_model\\MODEL_RUBBLE_01.mp3", "MODEL_RUBBLE_01", "model"); } }
        public static ScannerFile RUFFIAN01 { get { return new ScannerFile("01_model\\MODEL_RUFFIAN_01.mp3", "MODEL_RUFFIAN_01", "model"); } }
        public static ScannerFile RUINER01 { get { return new ScannerFile("01_model\\MODEL_RUINER_01.mp3", "MODEL_RUINER_01", "model"); } }
        public static ScannerFile RUMPO01 { get { return new ScannerFile("01_model\\MODEL_RUMPO_01.mp3", "MODEL_RUMPO_01", "model"); } }
        public static ScannerFile SABERGT01 { get { return new ScannerFile("01_model\\MODEL_SABER_GT_01.mp3", "MODEL_SABER_GT_01", "model"); } }
        public static ScannerFile SABREGT01 { get { return new ScannerFile("01_model\\MODEL_SABREGT_01.mp3", "MODEL_SABREGT_01", "model"); } }
        public static ScannerFile SADLER01 { get { return new ScannerFile("01_model\\MODEL_SADLER_01.mp3", "MODEL_SADLER_01", "model"); } }
        public static ScannerFile SANCHEZ01 { get { return new ScannerFile("01_model\\MODEL_SANCHEZ_01.mp3", "MODEL_SANCHEZ_01", "model"); } }
        public static ScannerFile SANDKING01 { get { return new ScannerFile("01_model\\MODEL_SANDKING_01.mp3", "MODEL_SANDKING_01", "model"); } }
        public static ScannerFile SCHAFTER01 { get { return new ScannerFile("01_model\\MODEL_SCHAFTER_01.mp3", "MODEL_SCHAFTER_01", "model"); } }
        public static ScannerFile SCHWARZER01 { get { return new ScannerFile("01_model\\MODEL_SCHWARZER_01.mp3", "MODEL_SCHWARZER_01", "model"); } }
        public static ScannerFile SCORCHER01 { get { return new ScannerFile("01_model\\MODEL_SCORCHER_01.mp3", "MODEL_SCORCHER_01", "model"); } }
        public static ScannerFile SCRAP01 { get { return new ScannerFile("01_model\\MODEL_SCRAP_01.mp3", "MODEL_SCRAP_01", "model"); } }
        public static ScannerFile SEAPLANE01 { get { return new ScannerFile("01_model\\MODEL_SEAPLANE_01.mp3", "MODEL_SEAPLANE_01", "model"); } }
        public static ScannerFile SEASHARK01 { get { return new ScannerFile("01_model\\MODEL_SEASHARK_01.mp3", "MODEL_SEASHARK_01", "model"); } }
        public static ScannerFile SEMINOLE01 { get { return new ScannerFile("01_model\\MODEL_SEMINOLE_01.mp3", "MODEL_SEMINOLE_01", "model"); } }
        public static ScannerFile SENTINEL01 { get { return new ScannerFile("01_model\\MODEL_SENTINEL_01.mp3", "MODEL_SENTINEL_01", "model"); } }
        public static ScannerFile SERRANO01 { get { return new ScannerFile("01_model\\MODEL_SERRANO_01.mp3", "MODEL_SERRANO_01", "model"); } }
        public static ScannerFile SKIVVY01 { get { return new ScannerFile("01_model\\MODEL_SKIVVY_01.mp3", "MODEL_SKIVVY_01", "model"); } }
        public static ScannerFile SKYLIFT01 { get { return new ScannerFile("01_model\\MODEL_SKYLIFT_01.mp3", "MODEL_SKYLIFT_01", "model"); } }
        public static ScannerFile SLAMVAN01 { get { return new ScannerFile("01_model\\MODEL_SLAMVAN_01.mp3", "MODEL_SLAMVAN_01", "model"); } }
        public static ScannerFile SPEEDER01 { get { return new ScannerFile("01_model\\MODEL_SPEEDER_01.mp3", "MODEL_SPEEDER_01", "model"); } }
        public static ScannerFile SPEEDO01 { get { return new ScannerFile("01_model\\MODEL_SPEEDO_01.mp3", "MODEL_SPEEDO_01", "model"); } }
        public static ScannerFile SQUADDIE01 { get { return new ScannerFile("01_model\\MODEL_SQUADDIE_01.mp3", "MODEL_SQUADDIE_01", "model"); } }
        public static ScannerFile SQUALO01 { get { return new ScannerFile("01_model\\MODEL_SQUALO_01.mp3", "MODEL_SQUALO_01", "model"); } }
        public static ScannerFile STANIER01 { get { return new ScannerFile("01_model\\MODEL_STANIER_01.mp3", "MODEL_STANIER_01", "model"); } }
        public static ScannerFile STINGER01 { get { return new ScannerFile("01_model\\MODEL_STINGER_01.mp3", "MODEL_STINGER_01", "model"); } }
        public static ScannerFile STINGERGT01 { get { return new ScannerFile("01_model\\MODEL_STINGER_GT_01.mp3", "MODEL_STINGER_GT_01", "model"); } }
        public static ScannerFile STOCKADE01 { get { return new ScannerFile("01_model\\MODEL_STOCKADE_01.mp3", "MODEL_STOCKADE_01", "model"); } }
        public static ScannerFile STRATUM01 { get { return new ScannerFile("01_model\\MODEL_STRATUM_01.mp3", "MODEL_STRATUM_01", "model"); } }
        public static ScannerFile STRETCH01 { get { return new ScannerFile("01_model\\MODEL_STRETCH_01.mp3", "MODEL_STRETCH_01", "model"); } }
        public static ScannerFile STUNT01 { get { return new ScannerFile("01_model\\MODEL_STUNT_01.mp3", "MODEL_STUNT_01", "model"); } }
        public static ScannerFile SUBMARINE01 { get { return new ScannerFile("01_model\\MODEL_SUBMARINE_01.mp3", "MODEL_SUBMARINE_01", "model"); } }
        public static ScannerFile SUBMERSIBLE01 { get { return new ScannerFile("01_model\\MODEL_SUBMERSIBLE_01.mp3", "MODEL_SUBMERSIBLE_01", "model"); } }
        public static ScannerFile SULTAN01 { get { return new ScannerFile("01_model\\MODEL_SULTAN_01.mp3", "MODEL_SULTAN_01", "model"); } }
        public static ScannerFile SUNTRAP01 { get { return new ScannerFile("01_model\\MODEL_SUNTRAP_01.mp3", "MODEL_SUNTRAP_01", "model"); } }
        public static ScannerFile SUPERDIAMOND01 { get { return new ScannerFile("01_model\\MODEL_SUPER_DIAMOND_01.mp3", "MODEL_SUPER_DIAMOND_01", "model"); } }
        public static ScannerFile SURANO01 { get { return new ScannerFile("01_model\\MODEL_SURANO_01.mp3", "MODEL_SURANO_01", "model"); } }
        public static ScannerFile SURFER01 { get { return new ScannerFile("01_model\\MODEL_SURFER_01.mp3", "MODEL_SURFER_01", "model"); } }
        public static ScannerFile SURGE01 { get { return new ScannerFile("01_model\\MODEL_SURGE_01.mp3", "MODEL_SURGE_01", "model"); } }
        public static ScannerFile SXR01 { get { return new ScannerFile("01_model\\MODEL_SXR_01.mp3", "MODEL_SXR_01", "model"); } }
        public static ScannerFile TACO01 { get { return new ScannerFile("01_model\\MODEL_TACO_01.mp3", "MODEL_TACO_01", "model"); } }
        public static ScannerFile TACOVAN01 { get { return new ScannerFile("01_model\\MODEL_TACO_VAN_01.mp3", "MODEL_TACO_VAN_01", "model"); } }
        public static ScannerFile TAILGATER01 { get { return new ScannerFile("01_model\\MODEL_TAILGATER_01.mp3", "MODEL_TAILGATER_01", "model"); } }
        public static ScannerFile TAMPA01 { get { return new ScannerFile("01_model\\MODEL_TAMPA_01.mp3", "MODEL_TAMPA_01", "model"); } }
        public static ScannerFile TAXI01 { get { return new ScannerFile("01_model\\MODEL_TAXI_01.mp3", "MODEL_TAXI_01", "model"); } }
        public static ScannerFile TIPPER01 { get { return new ScannerFile("01_model\\MODEL_TIPPER_01.mp3", "MODEL_TIPPER_01", "model"); } }
        public static ScannerFile TIPTRUCK01 { get { return new ScannerFile("01_model\\MODEL_TIPTRUCK_01.mp3", "MODEL_TIPTRUCK_01", "model"); } }
        public static ScannerFile TITAN01 { get { return new ScannerFile("01_model\\MODEL_TITAN_01.mp3", "MODEL_TITAN_01", "model"); } }
        public static ScannerFile TORNADO01 { get { return new ScannerFile("01_model\\MODEL_TORNADO_01.mp3", "MODEL_TORNADO_01", "model"); } }
        public static ScannerFile TOURBUS01 { get { return new ScannerFile("01_model\\MODEL_TOUR_BUS_01.mp3", "MODEL_TOUR_BUS_01", "model"); } }
        public static ScannerFile TOWTRUCK01 { get { return new ScannerFile("01_model\\MODEL_TOWTRUCK_01.mp3", "MODEL_TOWTRUCK_01", "model"); } }
        public static ScannerFile TR301 { get { return new ScannerFile("01_model\\MODEL_TR3_01.mp3", "MODEL_TR3_01", "model"); } }
        public static ScannerFile TRACTOR01 { get { return new ScannerFile("01_model\\MODEL_TRACTOR_01.mp3", "MODEL_TRACTOR_01", "model"); } }
        public static ScannerFile TRASH01 { get { return new ScannerFile("01_model\\MODEL_TRASH_01.mp3", "MODEL_TRASH_01", "model"); } }
        public static ScannerFile TRIALS01 { get { return new ScannerFile("01_model\\MODEL_TRIALS_01.mp3", "MODEL_TRIALS_01", "model"); } }
        public static ScannerFile TRIBIKE01 { get { return new ScannerFile("01_model\\MODEL_TRIBIKE_01.mp3", "MODEL_TRIBIKE_01", "model"); } }
        public static ScannerFile TROPIC01 { get { return new ScannerFile("01_model\\MODEL_TROPIC_01.mp3", "MODEL_TROPIC_01", "model"); } }
        public static ScannerFile TUGBOAT01 { get { return new ScannerFile("01_model\\MODEL_TUG_BOAT_01.mp3", "MODEL_TUG_BOAT_01", "model"); } }
        public static ScannerFile UTILITYTRUCK01 { get { return new ScannerFile("01_model\\MODEL_UTILITY_TRUCK_01.mp3", "MODEL_UTILITY_TRUCK_01", "model"); } }
        public static ScannerFile VACCA01 { get { return new ScannerFile("01_model\\MODEL_VACCA_01.mp3", "MODEL_VACCA_01", "model"); } }
        public static ScannerFile VADER01 { get { return new ScannerFile("01_model\\MODEL_VADER_01.mp3", "MODEL_VADER_01", "model"); } }
        public static ScannerFile VIGERO01 { get { return new ScannerFile("01_model\\MODEL_VIGERO_01.mp3", "MODEL_VIGERO_01", "model"); } }
        public static ScannerFile VOLTIC01 { get { return new ScannerFile("01_model\\MODEL_VOLTIC_01.mp3", "MODEL_VOLTIC_01", "model"); } }
        public static ScannerFile VOODOO01 { get { return new ScannerFile("01_model\\MODEL_VOODOO_01.mp3", "MODEL_VOODOO_01", "model"); } }
        public static ScannerFile VULKAN01 { get { return new ScannerFile("01_model\\MODEL_VULKAN_01.mp3", "MODEL_VULKAN_01", "model"); } }
        public static ScannerFile WASHINGTON01 { get { return new ScannerFile("01_model\\MODEL_WASHINGTON_01.mp3", "MODEL_WASHINGTON_01", "model"); } }
        public static ScannerFile WAYFARER01 { get { return new ScannerFile("01_model\\MODEL_WAYFARER_01.mp3", "MODEL_WAYFARER_01", "model"); } }
        public static ScannerFile WILLARD01 { get { return new ScannerFile("01_model\\MODEL_WILLARD_01.mp3", "MODEL_WILLARD_01", "model"); } }
        public static ScannerFile XL01 { get { return new ScannerFile("01_model\\MODEL_XL_01.mp3", "MODEL_XL_01", "model"); } }
        public static ScannerFile YOUGA01 { get { return new ScannerFile("01_model\\MODEL_YOUGA_01.mp3", "MODEL_YOUGA_01", "model"); } }
        public static ScannerFile ZION01 { get { return new ScannerFile("01_model\\MODEL_ZION_01.mp3", "MODEL_ZION_01", "model"); } }
        public static ScannerFile ZTYPE01 { get { return new ScannerFile("01_model\\MODEL_ZTYPE_01.mp3", "MODEL_ZTYPE_01", "model"); } }
    }
    //public class near_dir
    //{
    //    public static ScannerFile Westofumm { get { return new ScannerFile("01_near_dir\\0x07FAA085.mp3", "West of, umm...", "near_dir"); } }
    //    public static ScannerFile Eastofuh { get { return new ScannerFile("01_near_dir\\0x0B24BCE7.mp3", "East of, uh...", "near_dir"); } }
    //    public static ScannerFile Southofumm { get { return new ScannerFile("01_near_dir\\0x0DEF2D26.mp3", "South of, umm...", "near_dir"); } }
    //    public static ScannerFile Eastofumm { get { return new ScannerFile("01_near_dir\\0x156E917B.mp3", "East of, umm...", "near_dir"); } }
    //    public static ScannerFile Northofuhh { get { return new ScannerFile("01_near_dir\\0x15BD7E38.mp3", "North of, uhh...", "near_dir"); } }
    //    public static ScannerFile Northofuh { get { return new ScannerFile("01_near_dir\\0x16C2C038.mp3", "North of, (uh)", "near_dir"); } }
    //    public static ScannerFile Westof { get { return new ScannerFile("01_near_dir\\0x19D04430.mp3", "West of...", "near_dir"); } }
    //    public static ScannerFile Southofuhh { get { return new ScannerFile("01_near_dir\\0x1D0DCB63.mp3", "South of, uhh...", "near_dir"); } }
    //}
    public class no_further_units
    {
        public static ScannerFile WereCode4Adam { get { return new ScannerFile("01_no_further_units\\0x0605420C.mp3", "We're Code 4-Adam.", "no_further_units"); } }
        public static ScannerFile Code4Adamnoadditionalsupportneeded { get { return new ScannerFile("01_no_further_units\\0x0A5BCAB6.mp3", "Code 4-Adam; no additional support needed.", "no_further_units"); } }
        public static ScannerFile Noadditionalofficersneeded { get { return new ScannerFile("01_no_further_units\\0x0B1C8C3B.mp3", "No additional officers needed.", "no_further_units"); } }
        public static ScannerFile Code4Adam { get { return new ScannerFile("01_no_further_units\\0x185CA6BB.mp3", "Code 4-Adam.", "no_further_units"); } }
        public static ScannerFile Noadditionalofficersneeded1 { get { return new ScannerFile("01_no_further_units\\0x189CE738.mp3", "No additional officers needed.", "no_further_units"); } }
        public static ScannerFile Nofurtherunitsrequired { get { return new ScannerFile("01_no_further_units\\0x1CE7EFD0.mp3", "No further units required.", "no_further_units"); } }
    }
    //public class number_criminals
    //{
    //    public static ScannerFile suspects8 { get { return new ScannerFile("01_number_criminals\\0x03F2B4F9.mp3", "8 suspects.", "number_criminals"); } }
    //    public static ScannerFile suspects3 { get { return new ScannerFile("01_number_criminals\\0x06344DE2.mp3", "3 suspects.", "number_criminals"); } }
    //    public static ScannerFile suspects9 { get { return new ScannerFile("01_number_criminals\\0x08A64BDC.mp3", "9 suspects.", "number_criminals"); } }
    //    public static ScannerFile suspects6 { get { return new ScannerFile("01_number_criminals\\0x0E5BE06F.mp3", "6 suspects.", "number_criminals"); } }
    //    public static ScannerFile suspects5 { get { return new ScannerFile("01_number_criminals\\0x113E5F08.mp3", "5 suspects.", "number_criminals"); } }
    //    public static ScannerFile suspects7 { get { return new ScannerFile("01_number_criminals\\0x13572036.mp3", "7 suspects.", "number_criminals"); } }
    //    public static ScannerFile suspect1 { get { return new ScannerFile("01_number_criminals\\0x136DA273.mp3", "1 suspect.", "number_criminals"); } }
    //    public static ScannerFile suspects10 { get { return new ScannerFile("01_number_criminals\\0x16B651EB.mp3", "10 suspects.", "number_criminals"); } }
    //    public static ScannerFile suspects2 { get { return new ScannerFile("01_number_criminals\\0x19FB0E23.mp3", "2 suspects.", "number_criminals"); } }
    //    public static ScannerFile suspects4 { get { return new ScannerFile("01_number_criminals\\0x1DF7C60A.mp3", "4 suspects.", "number_criminals"); } }
    //}
    public class officer
    {
        public static ScannerFile Unituhh { get { return new ScannerFile("01_officer\\0x03087D87.mp3", "Unit, uhh...", "officer"); } }
        public static ScannerFile Officeruhh { get { return new ScannerFile("01_officer\\0x060A837E.mp3", "Officer, uhh...", "officer"); } }
        public static ScannerFile Unitumm { get { return new ScannerFile("01_officer\\0x0C5C9031.mp3", "Unit, umm..", "officer"); } }
        public static ScannerFile Officerumm { get { return new ScannerFile("01_officer\\0x17D62715.mp3", "Officer, umm...", "officer"); } }
        public static ScannerFile Officer { get { return new ScannerFile("01_officer\\0x19CC6B10.mp3", "Officer...", "officer"); } }
        public static ScannerFile Officerrrrumm { get { return new ScannerFile("01_officer\\0x1BE7EF39.mp3", "Officerrrr...umm...", "officer"); } }
        public static ScannerFile Officeruhh1 { get { return new ScannerFile("01_officer\\0x1E9A34AC.mp3", "Officer...uhh...", "officer"); } }
    }
    public class officers_on_scene
    {
        public static ScannerFile Officersareatthescene { get { return new ScannerFile("01_officers_on_scene\\0x0307A167.mp3", "Officers are at the scene.", "officers_on_scene"); } }
        public static ScannerFile Officershavearrived { get { return new ScannerFile("01_officers_on_scene\\0x06606818.mp3", "Officers have arrived.", "officers_on_scene"); } }
        public static ScannerFile Officersonscene { get { return new ScannerFile("01_officers_on_scene\\0x0FFB7B47.mp3", "Officers on scene.", "officers_on_scene"); } }
        public static ScannerFile Officersarrivedonscene { get { return new ScannerFile("01_officers_on_scene\\0x154DC5F2.mp3", "Officers arrived on scene.", "officers_on_scene"); } }
        public static ScannerFile Officersonsite { get { return new ScannerFile("01_officers_on_scene\\0x15BC46C9.mp3", "Officers on site.", "officers_on_scene"); } }
    }
    public class officer_begin_patrol
    {
        public static ScannerFile Proceedwithpatrol { get { return new ScannerFile("01_officer_begin_patrol\\0x00F6FF69.mp3", "Proceed with patrol.", "officer_begin_patrol"); } }
        public static ScannerFile Proceedtopatrolarea { get { return new ScannerFile("01_officer_begin_patrol\\0x01D5812A.mp3", "Proceed to patrol area.", "officer_begin_patrol"); } }
        public static ScannerFile Beginpatrol { get { return new ScannerFile("01_officer_begin_patrol\\0x062F49DC.mp3", "Begin patrol.", "officer_begin_patrol"); } }
        public static ScannerFile Assigntopatrol { get { return new ScannerFile("01_officer_begin_patrol\\0x0D6A5853.mp3", "Assign to patrol.", "officer_begin_patrol"); } }
        public static ScannerFile Beginbeat { get { return new ScannerFile("01_officer_begin_patrol\\0x152767CD.mp3", "Begin beat.", "officer_begin_patrol"); } }
        public static ScannerFile Proceedtopatrolarea1 { get { return new ScannerFile("01_officer_begin_patrol\\0x17ABACD6.mp3", "Proceed to patrol area.", "officer_begin_patrol"); } }
    }
    //public class officer_down
    //{
    //    public static ScannerFile Hasbeeninjured { get { return new ScannerFile("01_officer_down\\0x02CD8D91.mp3", "Has been injured.", "officer_down"); } }
    //    public static ScannerFile Hasbeenwounded { get { return new ScannerFile("01_officer_down\\0x0721163B.mp3", "Has been wounded.", "officer_down"); } }
    //    public static ScannerFile Iswounded { get { return new ScannerFile("01_officer_down\\0x0A2E5C55.mp3", "Is wounded.", "officer_down"); } }
    //    public static ScannerFile Isnotrespondingpossiblywounded { get { return new ScannerFile("01_officer_down\\0x0A701DB8.mp3", "Is not responding; possibly wounded.", "officer_down"); } }
    //    public static ScannerFile Killedinaction { get { return new ScannerFile("01_officer_down\\0x103D2951.mp3", "Killed in action.", "officer_down"); } }
    //    public static ScannerFile Isseverelywounded { get { return new ScannerFile("01_officer_down\\0x1418F029.mp3", "Is severely wounded.", "officer_down"); } }
    //    public static ScannerFile Hasbeenseverelyinjured { get { return new ScannerFile("01_officer_down\\0x1423B03D.mp3", "Has been severely injured.", "officer_down"); } }
    //    public static ScannerFile Hasbeenkilled { get { return new ScannerFile("01_officer_down\\0x1E62C4BA.mp3", "Has been killed.", "officer_down"); } }
    //    public static ScannerFile OFFICERDOWN01 { get { return new ScannerFile("01_officer_down\\OFFICER_DOWN_01.mp3", "OFFICER_DOWN_01", "officer_down"); } }
    //    public static ScannerFile OFFICERDOWN02 { get { return new ScannerFile("01_officer_down\\OFFICER_DOWN_02.mp3", "OFFICER_DOWN_02", "officer_down"); } }
    //    public static ScannerFile OFFICERDOWN03 { get { return new ScannerFile("01_officer_down\\OFFICER_DOWN_03.mp3", "OFFICER_DOWN_03", "officer_down"); } }
    //}
    //public class officer_down_shot
    //{
    //    public static ScannerFile Hasbeenfatallyshot { get { return new ScannerFile("01_officer_down_shot\\0x00A2944D.mp3", "Has been fatally shot.", "officer_down_shot"); } }
    //    public static ScannerFile Hasbeenshot { get { return new ScannerFile("01_officer_down_shot\\0x0A66680B.mp3", "Has been shot.", "officer_down_shot"); } }
    //    public static ScannerFile Isreportedlyshotandwounded { get { return new ScannerFile("01_officer_down_shot\\0x0DBDEE80.mp3", "Is reportedly shot and wounded.", "officer_down_shot"); } }
    //    public static ScannerFile Hasbeenshotandcriticallywounded { get { return new ScannerFile("01_officer_down_shot\\0x0EDD30C2.mp3", "Has been shot and critically wounded.", "officer_down_shot"); } }
    //    public static ScannerFile Isreportedlyshot { get { return new ScannerFile("01_officer_down_shot\\0x1C6B0BDB.mp3", "Is reportedly shot.", "officer_down_shot"); } }
    //}
    public class officer_requests_air_support
    {
        public static ScannerFile Officersrequireaerialsupport { get { return new ScannerFile("01_officer_requests_air_support\\0x03867D3A.mp3", "Officers require aerial support.", "officer_requests_air_support"); } }
        public static ScannerFile Unitsrequestinghelicoptersupport { get { return new ScannerFile("01_officer_requests_air_support\\0x064A82C3.mp3", "Units requesting helicopter support.", "officer_requests_air_support"); } }
        public static ScannerFile Unitsrequestaerialsupport { get { return new ScannerFile("01_officer_requests_air_support\\0x0CADCF88.mp3", "Units request aerial support.", "officer_requests_air_support"); } }
        public static ScannerFile Unitsrequestingairsupport { get { return new ScannerFile("01_officer_requests_air_support\\0x1010164D.mp3", "Units requesting air support.", "officer_requests_air_support"); } }
        public static ScannerFile Code99unitsrequestimmediateairsupport { get { return new ScannerFile("01_officer_requests_air_support\\0x1482DF27.mp3", "Code 99; units request immediate air support.", "officer_requests_air_support"); } }
        public static ScannerFile Officersrequestinghelicoptersupport { get { return new ScannerFile("01_officer_requests_air_support\\0x1528207E.mp3", "Officers requesting helicopter support.", "officer_requests_air_support"); } }
        public static ScannerFile Officersrequireaerialsupport1 { get { return new ScannerFile("01_officer_requests_air_support\\0x19946955.mp3", "Officers require aerial support.", "officer_requests_air_support"); } }
        public static ScannerFile Officersrequireairsupport { get { return new ScannerFile("01_officer_requests_air_support\\0x1CE9B000.mp3", "Officers require air support.", "officer_requests_air_support"); } }
    }
    //public class officer_requests_backup
    //{
    //    public static ScannerFile Code99officersrequireassistance { get { return new ScannerFile("01_officer_requests_backup\\0x001BB1F7.mp3", "Code 99; officers require assistance.", "officer_requests_backup"); } }
    //    public static ScannerFile Code99unitneedsimmediatebackup { get { return new ScannerFile("01_officer_requests_backup\\0x033FF83C.mp3", "Code 99; unit needs immediate backup.", "officer_requests_backup"); } }
    //    public static ScannerFile Officersrequestingbackup { get { return new ScannerFile("01_officer_requests_backup\\0x0ACEC75C.mp3", "Officers requesting backup.", "officer_requests_backup"); } }
    //    public static ScannerFile Unitsrequirebackup { get { return new ScannerFile("01_officer_requests_backup\\0x0DE40D87.mp3", "Units require backup.", "officer_requests_backup"); } }
    //    public static ScannerFile Unitsrequireimmediateassistance { get { return new ScannerFile("01_officer_requests_backup\\0x11D15562.mp3", "Units require immediate assistance.", "officer_requests_backup"); } }
    //    public static ScannerFile Code99unitrequiresbackup { get { return new ScannerFile("01_officer_requests_backup\\0x14FC9BB9.mp3", "Code 99; unit requires backup.", "officer_requests_backup"); } }
    //    public static ScannerFile Unitsrequestingbackup { get { return new ScannerFile("01_officer_requests_backup\\0x190D23D9.mp3", "Units requesting backup.", "officer_requests_backup"); } }
    //    public static ScannerFile Officerneedsimmediateassistance { get { return new ScannerFile("01_officer_requests_backup\\0x1C296A12.mp3", "Officer needs immediate assistance.", "officer_requests_backup"); } }
    //    public static ScannerFile Officerrequestingbackup { get { return new ScannerFile("01_officer_requests_backup\\0x1C79AAAE.mp3", "Officer requesting backup.", "officer_requests_backup"); } }
    //}
    public class on_foot
    {
        public static ScannerFile Onfoot { get { return new ScannerFile("01_on_foot\\0x00EF6F8D.mp3", "On foot.", "on_foot"); } }
        public static ScannerFile Onfoot1 { get { return new ScannerFile("01_on_foot\\0x0EA9CB02.mp3", "On foot.", "on_foot"); } }
    }
    //public class ornate_bank_heist
    //{
    //    public static ScannerFile Atthe211inEastLosSantos { get { return new ScannerFile("01_ornate_bank_heist\\0x0006F181.mp3", "At the 2-11 in East Los Santos.", "ornate_bank_heist"); } }
    //    public static ScannerFile Allunits { get { return new ScannerFile("01_ornate_bank_heist\\0x011A4380.mp3", "All units.", "ornate_bank_heist"); } }
    //    public static ScannerFile AtthebankrobberyattheEastVinewoodBankofLosSantos { get { return new ScannerFile("01_ornate_bank_heist\\0x04EDBB4E.mp3", "At the bank robbery at the East Vinewood Bank of Los Santos.", "ornate_bank_heist"); } }
    //    public static ScannerFile AttheEastVinewoodBankofLosSantos { get { return new ScannerFile("01_ornate_bank_heist\\0x0614A3D8.mp3", "At the East Vinewood Bank of Los Santos.", "ornate_bank_heist"); } }
    //    public static ScannerFile Officershavearrivedatthe211 { get { return new ScannerFile("01_ornate_bank_heist\\0x08C55498.mp3", "Officers have arrived at the 2-11.", "ornate_bank_heist"); } }
    //    public static ScannerFile Unitsatthe211inEastLosSantosbeadvised { get { return new ScannerFile("01_ornate_bank_heist\\0x0A022F01.mp3", "Units at the 2-11 in East Los Santos, be advised.", "ornate_bank_heist"); } }
    //    public static ScannerFile Attentionallunitsatthe211inEastLosSantos { get { return new ScannerFile("01_ornate_bank_heist\\0x0B9E89B4.mp3", "Attention all units at the 2-11 in East Los Santos.", "ornate_bank_heist"); } }
    //    public static ScannerFile Attentionallunitsatthe211inEastLosSantos1 { get { return new ScannerFile("01_ornate_bank_heist\\0x0D40F8A4.mp3", "Attention all units at the 2-11 in East Los Santos.", "ornate_bank_heist"); } }
    //    public static ScannerFile Suspectsarefleeingthecrime { get { return new ScannerFile("01_ornate_bank_heist\\0x0D6D38FC.mp3", "Suspects are fleeing the crime.", "ornate_bank_heist"); } }
    //    public static ScannerFile Wehavereportsofapossible211inEastLosSantos { get { return new ScannerFile("01_ornate_bank_heist\\0x10BBC345.mp3", "We have reports of a possible 2-11 in East Los Santos.", "ornate_bank_heist"); } }
    //    public static ScannerFile Atthe211inEastLosSantos1 { get { return new ScannerFile("01_ornate_bank_heist\\0x1264563C.mp3", "At the 2-11 in East Los Santos.", "ornate_bank_heist"); } }
    //    public static ScannerFile Suspectshavebreachedthebanksvault { get { return new ScannerFile("01_ornate_bank_heist\\0x137722CE.mp3", "Suspects have breached the bank's vault.", "ornate_bank_heist"); } }
    //    public static ScannerFile EastVinewoodBankofLosSantos { get { return new ScannerFile("01_ornate_bank_heist\\0x14D4EAF7.mp3", "East Vinewood Bank of Los Santos.", "ornate_bank_heist"); } }
    //    public static ScannerFile Officershavearrivedatthe2111 { get { return new ScannerFile("01_ornate_bank_heist\\0x1606C3BC.mp3", "Officers have arrived at the 2-11.", "ornate_bank_heist"); } }
    //    public static ScannerFile Atthe211attheEastVinewoodBankofLosSantos { get { return new ScannerFile("01_ornate_bank_heist\\0x17301FD3.mp3", "At the 2-11 at the East Vinewood Bank of Los Santos.", "ornate_bank_heist"); } }
    //    public static ScannerFile Suspectshaveenteredthebanksvault { get { return new ScannerFile("01_ornate_bank_heist\\0x18C08C7E.mp3", "Suspects have entered the bank's vault.", "ornate_bank_heist"); } }
    //    public static ScannerFile AttheEastVinewoodBankofLS { get { return new ScannerFile("01_ornate_bank_heist\\0x1A34F777.mp3", "At the East Vinewood Bank of LS.", "ornate_bank_heist"); } }
    //    public static ScannerFile Wehaveconfirmationofabankrobberyatthe { get { return new ScannerFile("01_ornate_bank_heist\\0x1A853657.mp3", "We have confirmation of a bank robbery at the...", "ornate_bank_heist"); } }
    //    public static ScannerFile Suspectsarefleeingthecrime1 { get { return new ScannerFile("01_ornate_bank_heist\\0x1CDC2C2F.mp3", "Suspects are fleeing the crime.", "ornate_bank_heist"); } }
    //    public static ScannerFile Unitsatthe211inEastLosSantosbeadvised1 { get { return new ScannerFile("01_ornate_bank_heist\\0x1D6A36A5.mp3", "Units at the 2-11 in East Los Santos, be advised.", "ornate_bank_heist"); } }
    //    public static ScannerFile Banksecurityreports4suspectsarmedanddangerous { get { return new ScannerFile("01_ornate_bank_heist\\0x1DFFFD4C.mp3", "Bank security reports 4 suspects, armed and dangerous.", "ornate_bank_heist"); } }
    //    public static ScannerFile Atthe211attheEastVinewoodBankofLS { get { return new ScannerFile("01_ornate_bank_heist\\0x1F2DEFE7.mp3", "At the 2-11 at the East Vinewood Bank of LS.", "ornate_bank_heist"); } }
    //    public static ScannerFile AllavailableunitsrespondCode3 { get { return new ScannerFile("01_ornate_bank_heist\\0x1FB8613E.mp3", "All available units respond; Code 3.", "ornate_bank_heist"); } }
    //}
    //public class over_area
    //{
    //    public static ScannerFile OVERAREAALAMOSEA01 { get { return new ScannerFile("01_over_area\\OVER_AREA_ALAMO_SEA_01.mp3", "OVER_AREA_ALAMO_SEA_01", "over_area"); } }
    //    public static ScannerFile OVERAREABRADDOCKPASS01 { get { return new ScannerFile("01_over_area\\OVER_AREA_BRADDOCK_PASS_01.mp3", "OVER_AREA_BRADDOCK_PASS_01", "over_area"); } }
    //    public static ScannerFile OVERAREACENTRALLOSSANTOS01 { get { return new ScannerFile("01_over_area\\OVER_AREA_CENTRAL_LOS_SANTOS_01.mp3", "OVER_AREA_CENTRAL_LOS_SANTOS_01", "over_area"); } }
    //    public static ScannerFile OVERAREACHUMASH01 { get { return new ScannerFile("01_over_area\\OVER_AREA_CHUMASH_01.mp3", "OVER_AREA_CHUMASH_01", "over_area"); } }
    //    public static ScannerFile OVERAREADOWNTOWN01 { get { return new ScannerFile("01_over_area\\OVER_AREA_DOWNTOWN_01.mp3", "OVER_AREA_DOWNTOWN_01", "over_area"); } }
    //    public static ScannerFile OVERAREAEASTLOSSANTOS01 { get { return new ScannerFile("01_over_area\\OVER_AREA_EAST_LOS_SANTOS_01.mp3", "OVER_AREA_EAST_LOS_SANTOS_01", "over_area"); } }
    //    public static ScannerFile OVERAREAGRANDESENORADESERT01 { get { return new ScannerFile("01_over_area\\OVER_AREA_GRANDE_SENORA_DESERT_01.mp3", "OVER_AREA_GRANDE_SENORA_DESERT_01", "over_area"); } }
    //    public static ScannerFile OVERAREALAGOZANCUDO01 { get { return new ScannerFile("01_over_area\\OVER_AREA_LAGO_ZANCUDO_01.mp3", "OVER_AREA_LAGO_ZANCUDO_01", "over_area"); } }
    //    public static ScannerFile OVERAREALOSSANTOSINTERNATIONAL01 { get { return new ScannerFile("01_over_area\\OVER_AREA_LOS_SANTOS_INTERNATIONAL_01.mp3", "OVER_AREA_LOS_SANTOS_INTERNATIONAL_01", "over_area"); } }
    //    public static ScannerFile OVERAREAMOUNTJOSIAH01 { get { return new ScannerFile("01_over_area\\OVER_AREA_MOUNT_JOSIAH_01.mp3", "OVER_AREA_MOUNT_JOSIAH_01", "over_area"); } }
    //    public static ScannerFile OVERAREANORTHLOSSANTOS01 { get { return new ScannerFile("01_over_area\\OVER_AREA_NORTH_LOS_SANTOS_01.mp3", "OVER_AREA_NORTH_LOS_SANTOS_01", "over_area"); } }
    //    public static ScannerFile OVERAREAPALETOBAY01 { get { return new ScannerFile("01_over_area\\OVER_AREA_PALETO_BAY_01.mp3", "OVER_AREA_PALETO_BAY_01", "over_area"); } }
    //    public static ScannerFile OVERAREAPORTOFLOSSANTOS01 { get { return new ScannerFile("01_over_area\\OVER_AREA_PORT_OF_LOS_SANTOS_01.mp3", "OVER_AREA_PORT_OF_LOS_SANTOS_01", "over_area"); } }
    //    public static ScannerFile OVERAREARATONCANYON01 { get { return new ScannerFile("01_over_area\\OVER_AREA_RATON_CANYON_01.mp3", "OVER_AREA_RATON_CANYON_01", "over_area"); } }
    //    public static ScannerFile OVERAREASANDYSHORES01 { get { return new ScannerFile("01_over_area\\OVER_AREA_SANDY_SHORES_01.mp3", "OVER_AREA_SANDY_SHORES_01", "over_area"); } }
    //    public static ScannerFile OVERAREASOUTHLOSSANTOS01 { get { return new ScannerFile("01_over_area\\OVER_AREA_SOUTH_LOS_SANTOS_01.mp3", "OVER_AREA_SOUTH_LOS_SANTOS_01", "over_area"); } }
    //    public static ScannerFile OVERAREAVINEWOODHILLS01 { get { return new ScannerFile("01_over_area\\OVER_AREA_VINEWOOD_HILLS_01.mp3", "OVER_AREA_VINEWOOD_HILLS_01", "over_area"); } }
    //    public static ScannerFile OVERAREAWESTLOSSANTOS01 { get { return new ScannerFile("01_over_area\\OVER_AREA_WEST_LOS_SANTOS_01.mp3", "OVER_AREA_WEST_LOS_SANTOS_01", "over_area"); } }
    //    public static ScannerFile OVERAREAWESTLOSSANTOS02 { get { return new ScannerFile("01_over_area\\OVER_AREA_WEST_LOS_SANTOS_02.mp3", "OVER_AREA_WEST_LOS_SANTOS_02", "over_area"); } }
    //}
    //public class player_description
    //{
    //    public static ScannerFile Blackmaleearly20sblackhair { get { return new ScannerFile("01_player_description\\0x002BC54F.mp3", "Black male, early 20s, black hair.", "player_description"); } }
    //    public static ScannerFile Whitemalelate40sdarkhair { get { return new ScannerFile("01_player_description\\0x0372C4A6.mp3", "White male, late 40s, dark hair.", "player_description"); } }
    //    public static ScannerFile Athleticwhitemalelate40sdarkhair { get { return new ScannerFile("01_player_description\\0x049E79F3.mp3", "Athletic white male, late 40s, dark hair.", "player_description"); } }
    //    public static ScannerFile Athleticblackmaleearly20sblackhair { get { return new ScannerFile("01_player_description\\0x0B2492A0.mp3", "Athletic black male, early 20s, black hair.", "player_description"); } }
    //    public static ScannerFile Heavysetblackmaleearly20sblackhair { get { return new ScannerFile("01_player_description\\0x1285A907.mp3", "Heavyset black male, early 20s, black hair.", "player_description"); } }
    //    public static ScannerFile Heavysetwhitemalelate40sdarkhair { get { return new ScannerFile("01_player_description\\0x18396F91.mp3", "Heavyset white male, late 40s, dark hair.", "player_description"); } }
    //    public static ScannerFile Whitemalemid30sbrownhair { get { return new ScannerFile("01_player_description\\0x19D42672.mp3", "White male, mid-30s, brown hair.", "player_description"); } }
    //    public static ScannerFile Heavysetwhitemalemid30sbrownhair { get { return new ScannerFile("01_player_description\\0x1B2189EA.mp3", "Heavyset white male, mid-30s, brown hair.", "player_description"); } }
    //    public static ScannerFile Athleticwhitemalemid30sbrownhair { get { return new ScannerFile("01_player_description\\0x1EF15F7E.mp3", "Athletic white male, mid-30s, brown hair.", "player_description"); } }
    //}
    //public class police_station_bust_out
    //{
    //    public static ScannerFile Emergencyallunitsrespond { get { return new ScannerFile("01_police_station_bust_out\\0x0121C945.mp3", "Emergency; all units respond.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitswehavea1024 { get { return new ScannerFile("01_police_station_bust_out\\0x0362211C.mp3", "All units, we have a 10-24.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitsrespondimmediatelycodepurple { get { return new ScannerFile("01_police_station_bust_out\\0x047D8AA7.mp3", "All units respond immediately, code purple.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitsrespondimmediatelyemergency { get { return new ScannerFile("01_police_station_bust_out\\0x05959293.mp3", "All units respond immediately; emergency.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitsrespondimmediatelycode99 { get { return new ScannerFile("01_police_station_bust_out\\0x080C5809.mp3", "All units respond immediately; code 99.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitsrespondimmediatelyemergency1 { get { return new ScannerFile("01_police_station_bust_out\\0x08968ED7.mp3", "All units respond immediately; emergency.", "police_station_bust_out"); } }
    //    public static ScannerFile Attentionallunitswehaveareportofanexplosionattheprecinct { get { return new ScannerFile("01_police_station_bust_out\\0x0A4618EC.mp3", "Attention all units, we have a report of an explosion at the precinct.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitsrespond1024 { get { return new ScannerFile("01_police_station_bust_out\\0x0A786E55.mp3", "All units respond; 10-24.", "police_station_bust_out"); } }
    //    public static ScannerFile Emergencyallunitsrespond1 { get { return new ScannerFile("01_police_station_bust_out\\0x0EC921B4.mp3", "Emergency; all units respond.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitsrespondimmediatelycode991 { get { return new ScannerFile("01_police_station_bust_out\\0x0FB1DEC0.mp3", "All units respond immediately; code 99.", "police_station_bust_out"); } }
    //    public static ScannerFile Attentionwehavea982atthecentralprecinct { get { return new ScannerFile("01_police_station_bust_out\\0x0FEDA742.mp3", "Attention, we have a 9-82 at the central precinct.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitsanexplosionhasoccurredattheprecinct { get { return new ScannerFile("01_police_station_bust_out\\0x10A0609E.mp3", "All units, an explosion has occurred at the precinct.", "police_station_bust_out"); } }
    //    public static ScannerFile Attentionwehavea983atthecentralprecinct { get { return new ScannerFile("01_police_station_bust_out\\0x12C9A33D.mp3", "Attention, we have a 9-83 at the central precinct.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitsrespondimmediatelycodepurple1 { get { return new ScannerFile("01_police_station_bust_out\\0x13594109.mp3", "All units respond immediately; code purple.", "police_station_bust_out"); } }
    //    public static ScannerFile Wehaveareportofanexplosionattheprecinct { get { return new ScannerFile("01_police_station_bust_out\\0x13672DD0.mp3", "We have a report of an explosion at the precinct.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitsanexplosionhasoccurredattheprecinct1 { get { return new ScannerFile("01_police_station_bust_out\\0x15CD338B.mp3", "All units, an explosion has occurred at the precinct.", "police_station_bust_out"); } }
    //    public static ScannerFile Allunitswehavea10241 { get { return new ScannerFile("01_police_station_bust_out\\0x16362E18.mp3", "All units, we have a 10-24.", "police_station_bust_out"); } }
    //    public static ScannerFile Attentionallunitswevegota996attheprecinct { get { return new ScannerFile("01_police_station_bust_out\\0x19B8CCD6.mp3", "Attention all units, we've got a 9-96 at the precinct.", "police_station_bust_out"); } }
    //}
    //public class proceed_with_caution
    //{
    //    public static ScannerFile Proceedwithcaution { get { return new ScannerFile("01_proceed_with_caution\\0x0C544469.mp3", "Proceed with caution.", "proceed_with_caution"); } }
    //    public static ScannerFile Approachwithcaution { get { return new ScannerFile("01_proceed_with_caution\\0x1A101FE4.mp3", "Approach with caution.", "proceed_with_caution"); } }
    //    public static ScannerFile Officersproceedwithcaution { get { return new ScannerFile("01_proceed_with_caution\\0x1AEC219A.mp3", "Officers, proceed with caution.", "proceed_with_caution"); } }
    //}
    //public class race_sex
    //{
    //    public static ScannerFile Caucasianmale { get { return new ScannerFile("01_race_sex\\0x000394EA.mp3", "Caucasian male.", "race_sex"); } }
    //    public static ScannerFile Asianmale { get { return new ScannerFile("01_race_sex\\0x035E8EE4.mp3", "Asian male.", "race_sex"); } }
    //    public static ScannerFile AfricanAmericanfemale { get { return new ScannerFile("01_race_sex\\0x040777A8.mp3", "African-American female.", "race_sex"); } }
    //    public static ScannerFile Caucasianfemale { get { return new ScannerFile("01_race_sex\\0x0858623E.mp3", "Caucasian female.", "race_sex"); } }
    //    public static ScannerFile AMA { get { return new ScannerFile("01_race_sex\\0x0920E051.mp3", "AMA.", "race_sex"); } }
    //    public static ScannerFile WFA { get { return new ScannerFile("01_race_sex\\0x0B427DCF.mp3", "WFA.", "race_sex"); } }
    //    public static ScannerFile Blackmale { get { return new ScannerFile("01_race_sex\\0x0B8CBDE4.mp3", "Black male.", "race_sex"); } }
    //    public static ScannerFile AfricanAmericanmale { get { return new ScannerFile("01_race_sex\\0x0CE2C090.mp3", "African-American male.", "race_sex"); } }
    //    public static ScannerFile Hispanicmale { get { return new ScannerFile("01_race_sex\\0x0E6CBBB1.mp3", "Hispanic male.", "race_sex"); } }
    //    public static ScannerFile Whitefemale { get { return new ScannerFile("01_race_sex\\0x0EDCEF46.mp3", "White female.", "race_sex"); } }
    //    public static ScannerFile Whitemale { get { return new ScannerFile("01_race_sex\\0x122AF938.mp3", "White male.", "race_sex"); } }
    //    public static ScannerFile BFA { get { return new ScannerFile("01_race_sex\\0x13490822.mp3", "BFA.", "race_sex"); } }
    //    public static ScannerFile Asianfemale { get { return new ScannerFile("01_race_sex\\0x17579460.mp3", "Asian female.", "race_sex"); } }
    //    public static ScannerFile BMA { get { return new ScannerFile("01_race_sex\\0x17608E77.mp3", "BMA.", "race_sex"); } }
    //    public static ScannerFile Hispanicfemale { get { return new ScannerFile("01_race_sex\\0x177B46CA.mp3", "Hispanic female.", "race_sex"); } }
    //    public static ScannerFile AFA { get { return new ScannerFile("01_race_sex\\0x18792A5B.mp3", "AFA.", "race_sex"); } }
    //    public static ScannerFile WFA1 { get { return new ScannerFile("01_race_sex\\0x188BD862.mp3", "WFA.", "race_sex"); } }
    //    public static ScannerFile HFA { get { return new ScannerFile("01_race_sex\\0x19BB2712.mp3", "HFA.", "race_sex"); } }
    //    public static ScannerFile WMA { get { return new ScannerFile("01_race_sex\\0x1BF59998.mp3", "WMA.", "race_sex"); } }
    //    public static ScannerFile Blackfemale { get { return new ScannerFile("01_race_sex\\0x1D26A9B5.mp3", "Black female.", "race_sex"); } }
    //    public static ScannerFile HMA { get { return new ScannerFile("01_race_sex\\0x1EB40183.mp3", "HMA.", "race_sex"); } }
    //}
    //public class requesting_backup
    //{
    //    public static ScannerFile Requiresassistance { get { return new ScannerFile("01_requesting_backup\\0x00659C9E.mp3", "Requires assistance.", "requesting_backup"); } }
    //    public static ScannerFile Needsassistance { get { return new ScannerFile("01_requesting_backup\\0x16328837.mp3", "Needs assistance.", "requesting_backup"); } }
    //    public static ScannerFile REQUESTBACKUP01 { get { return new ScannerFile("01_requesting_backup\\REQUEST_BACKUP_01.mp3", "REQUEST_BACKUP_01", "requesting_backup"); } }
    //    public static ScannerFile REQUESTBACKUP02 { get { return new ScannerFile("01_requesting_backup\\REQUEST_BACKUP_02.mp3", "REQUEST_BACKUP_02", "requesting_backup"); } }
    //    public static ScannerFile REQUESTBACKUP03 { get { return new ScannerFile("01_requesting_backup\\REQUEST_BACKUP_03.mp3", "REQUEST_BACKUP_03", "requesting_backup"); } }
    //    public static ScannerFile REQUESTBACKUP04 { get { return new ScannerFile("01_requesting_backup\\REQUEST_BACKUP_04.mp3", "REQUEST_BACKUP_04", "requesting_backup"); } }
    //}
    //public class requesting_escort
    //{
    //    public static ScannerFile Requestsanescort { get { return new ScannerFile("01_requesting_escort\\0x0C7682B4.mp3", "Requests an escort.", "requesting_escort"); } }
    //    public static ScannerFile Requesting1014 { get { return new ScannerFile("01_requesting_escort\\0x0DFA05B6.mp3", "Requesting 10-14.", "requesting_escort"); } }
    //    public static ScannerFile Requestsprisonertransportassistance { get { return new ScannerFile("01_requesting_escort\\0x17C81958.mp3", "Requests prisoner transport assistance.", "requesting_escort"); } }
    //    public static ScannerFile Requesta1014 { get { return new ScannerFile("01_requesting_escort\\0x1A27DE16.mp3", "Request a 10-14.", "requesting_escort"); } }
    //    public static ScannerFile Requestingescort { get { return new ScannerFile("01_requesting_escort\\0x1F80E8C2.mp3", "Requesting escort.", "requesting_escort"); } }
    //}
    //public class scars
    //{
    //    public static ScannerFile Alargefacialscar { get { return new ScannerFile("01_scars\\0x03FA659B.mp3", "A large facial scar.", "scars"); } }
    //    public static ScannerFile Smallupperbodyscar { get { return new ScannerFile("01_scars\\0x054E3D88.mp3", "Small upper-body scar.", "scars"); } }
    //    public static ScannerFile Largeupperbodyscar { get { return new ScannerFile("01_scars\\0x05D1764C.mp3", "Large upper-body scar.", "scars"); } }
    //    public static ScannerFile Asmallscarontheirface { get { return new ScannerFile("01_scars\\0x0655846D.mp3", "A small scar on their face.", "scars"); } }
    //    public static ScannerFile Asmallscarontheirupperbody { get { return new ScannerFile("01_scars\\0x079FC228.mp3", "A small scar on their upper-body.", "scars"); } }
    //    public static ScannerFile Alargescarorscarsontheface { get { return new ScannerFile("01_scars\\0x09DD315F.mp3", "A large scar or scars on the face.", "scars"); } }
    //    public static ScannerFile Lightupperbodyscarring { get { return new ScannerFile("01_scars\\0x0A246759.mp3", "Light upper-body scarring.", "scars"); } }
    //    public static ScannerFile Asmallscarorscarsontheface { get { return new ScannerFile("01_scars\\0x0A5CCC7D.mp3", "A small scar or scars on the face.", "scars"); } }
    //    public static ScannerFile Heavyfacialscarring { get { return new ScannerFile("01_scars\\0x0B7E0ED1.mp3", "Heavy facial scarring.", "scars"); } }
    //    public static ScannerFile Alargescarontheirface { get { return new ScannerFile("01_scars\\0x11B7C116.mp3", "A large scar on their face.", "scars"); } }
    //    public static ScannerFile Lightfacialscarring { get { return new ScannerFile("01_scars\\0x136455B7.mp3", "Light facial scarring.", "scars"); } }
    //    public static ScannerFile Smallscarsontheirfaceandbody { get { return new ScannerFile("01_scars\\0x13D6CBC0.mp3", "Small scars on their face and body.", "scars"); } }
    //    public static ScannerFile Largeupperbodyscarorscars { get { return new ScannerFile("01_scars\\0x141F92E9.mp3", "Large upper-body scar or scars.", "scars"); } }
    //    public static ScannerFile Lifescarringtofaceandbody { get { return new ScannerFile("01_scars\\0x14A8577D.mp3", "Life scarring to face and body.", "scars"); } }
    //    public static ScannerFile Heavyupperbodyscarring { get { return new ScannerFile("01_scars\\0x17E59DFE.mp3", "Heavy upper-body scarring.", "scars"); } }
    //    public static ScannerFile Alargescarontheirupperbody { get { return new ScannerFile("01_scars\\0x188CDBC2.mp3", "A large scar on their upper-body.", "scars"); } }
    //    public static ScannerFile Asmallfacialscar { get { return new ScannerFile("01_scars\\0x1910A9E3.mp3", "A small facial scar.", "scars"); } }
    //    public static ScannerFile Largescarsontheirfaceandbody { get { return new ScannerFile("01_scars\\0x19604F3C.mp3", "Large scars on their face and body.", "scars"); } }
    //    public static ScannerFile Smallupperbodyscarorscars { get { return new ScannerFile("01_scars\\0x19E7E6BA.mp3", "Small upper-body scar or scars.", "scars"); } }
    //    public static ScannerFile Heavyscarringtofaceandbody { get { return new ScannerFile("01_scars\\0x1FD6FB59.mp3", "Heavy scarring to face and body.", "scars"); } }
    //}
    //public class scripted_lines
    //{
    //    public static ScannerFile Attentionallunits { get { return new ScannerFile("01_scripted_lines\\0x00075F1C.mp3", "Attention all units.", "scripted_lines"); } }
    //    public static ScannerFile TheLSRiver { get { return new ScannerFile("01_scripted_lines\\0x002DE1C8.mp3", "The LS River.", "scripted_lines"); } }
    //    public static ScannerFile Wehavea211silentonanarmoredtruck { get { return new ScannerFile("01_scripted_lines\\0x0046621B.mp3", "We have a 2-11 silent on an armored truck.", "scripted_lines"); } }
    //    public static ScannerFile Wehavea211attheUnionDepository { get { return new ScannerFile("01_scripted_lines\\0x005F5082.mp3", "We have a 2-11 at the Union Depository.", "scripted_lines"); } }
    //    public static ScannerFile Whitemaleadultseenfleeingthearea { get { return new ScannerFile("01_scripted_lines\\0x01034057.mp3", "White male, adult, seen fleeing the area.", "scripted_lines"); } }
    //    public static ScannerFile Useofdeadlyforceisauthorized { get { return new ScannerFile("01_scripted_lines\\0x010F1FF6.mp3", "Use of deadly force is authorized.", "scripted_lines"); } }
    //    public static ScannerFile Possiblesuspectseenheadingwestinabulldozer { get { return new ScannerFile("01_scripted_lines\\0x0116D5B7.mp3", "Possible suspect seen heading west in a bulldozer.", "scripted_lines"); } }
    //    public static ScannerFile TheparkinggarageattheArcadiusBusinessCenter { get { return new ScannerFile("01_scripted_lines\\0x015CB5CE.mp3", "The parking garage at the Arcadius Business Center.", "scripted_lines"); } }
    //    public static ScannerFile AttentionLaPuertaunits { get { return new ScannerFile("01_scripted_lines\\0x016048EA.mp3", "Attention La Puerta units.", "scripted_lines"); } }
    //    public static ScannerFile Code4allunitsreturntopatrol { get { return new ScannerFile("01_scripted_lines\\0x0193CCC9.mp3", "Code 4; all units return to patrol.", "scripted_lines"); } }
    //    public static ScannerFile RespondCode3 { get { return new ScannerFile("01_scripted_lines\\0x01F3ACCB.mp3", "Respond; Code 3.", "scripted_lines"); } }
    //    public static ScannerFile Piggybankisbrokenrepeatbroken { get { return new ScannerFile("01_scripted_lines\\0x02001264.mp3", "Piggy bank is broken; repeat, broken.", "scripted_lines"); } }
    //    public static ScannerFile Attentionallunits1 { get { return new ScannerFile("01_scripted_lines\\0x023C372E.mp3", "Attention all units.", "scripted_lines"); } }
    //    public static ScannerFile Vehiclesarereportedstolen { get { return new ScannerFile("01_scripted_lines\\0x027592ED.mp3", "Vehicles are reported stolen.", "scripted_lines"); } }
    //    public static ScannerFile Wevegotareportofanarmedcarhijacked { get { return new ScannerFile("01_scripted_lines\\0x02B6EF7F.mp3", "We've got a report of an armed car hijacked.", "scripted_lines"); } }
    //    public static ScannerFile AttentionGruppe6securityalarmtriggeredon { get { return new ScannerFile("01_scripted_lines\\0x02E399B8.mp3", "Attention, Gruppe 6 security alarm triggered on...", "scripted_lines"); } }
    //    public static ScannerFile Wehaveareported187 { get { return new ScannerFile("01_scripted_lines\\0x02EDC597.mp3", "We have a reported 1-87.", "scripted_lines"); } }
    //    public static ScannerFile Beadvisedsuspectisarmed { get { return new ScannerFile("01_scripted_lines\\0x033A2DB4.mp3", "Be advised, suspect is armed.", "scripted_lines"); } }
    //    public static ScannerFile HASH040A5429 { get { return new ScannerFile("01_scripted_lines\\0x040A5429.mp3", "0x040A5429", "scripted_lines"); } }
    //    public static ScannerFile HASH04152C67 { get { return new ScannerFile("01_scripted_lines\\0x04152C67.mp3", "0x04152C67", "scripted_lines"); } }
    //    public static ScannerFile HASH04907C35 { get { return new ScannerFile("01_scripted_lines\\0x04907C35.mp3", "0x04907C35", "scripted_lines"); } }
    //    public static ScannerFile HASH04977E6C { get { return new ScannerFile("01_scripted_lines\\0x04977E6C.mp3", "0x04977E6C", "scripted_lines"); } }
    //    public static ScannerFile HASH04A776F2 { get { return new ScannerFile("01_scripted_lines\\0x04A776F2.mp3", "0x04A776F2", "scripted_lines"); } }
    //    public static ScannerFile HASH04C12DC7 { get { return new ScannerFile("01_scripted_lines\\0x04C12DC7.mp3", "0x04C12DC7", "scripted_lines"); } }
    //    public static ScannerFile HASH04C47163 { get { return new ScannerFile("01_scripted_lines\\0x04C47163.mp3", "0x04C47163", "scripted_lines"); } }
    //    public static ScannerFile HASH04D1464C { get { return new ScannerFile("01_scripted_lines\\0x04D1464C.mp3", "0x04D1464C", "scripted_lines"); } }
    //    public static ScannerFile HASH04F54D95 { get { return new ScannerFile("01_scripted_lines\\0x04F54D95.mp3", "0x04F54D95", "scripted_lines"); } }
    //    public static ScannerFile HASH0524C7F7 { get { return new ScannerFile("01_scripted_lines\\0x0524C7F7.mp3", "0x0524C7F7", "scripted_lines"); } }
    //    public static ScannerFile HASH0550EC10 { get { return new ScannerFile("01_scripted_lines\\0x0550EC10.mp3", "0x0550EC10", "scripted_lines"); } }
    //    public static ScannerFile HASH056D892C { get { return new ScannerFile("01_scripted_lines\\0x056D892C.mp3", "0x056D892C", "scripted_lines"); } }
    //    public static ScannerFile HASH05D97E65 { get { return new ScannerFile("01_scripted_lines\\0x05D97E65.mp3", "0x05D97E65", "scripted_lines"); } }
    //    public static ScannerFile HASH065281C6 { get { return new ScannerFile("01_scripted_lines\\0x065281C6.mp3", "0x065281C6", "scripted_lines"); } }
    //    public static ScannerFile HASH067F9B20 { get { return new ScannerFile("01_scripted_lines\\0x067F9B20.mp3", "0x067F9B20", "scripted_lines"); } }
    //    public static ScannerFile HASH06FEFB5C { get { return new ScannerFile("01_scripted_lines\\0x06FEFB5C.mp3", "0x06FEFB5C", "scripted_lines"); } }
    //    public static ScannerFile HASH07337749 { get { return new ScannerFile("01_scripted_lines\\0x07337749.mp3", "0x07337749", "scripted_lines"); } }
    //    public static ScannerFile HASH07D987FF { get { return new ScannerFile("01_scripted_lines\\0x07D987FF.mp3", "0x07D987FF", "scripted_lines"); } }
    //    public static ScannerFile HASH07DCD88F { get { return new ScannerFile("01_scripted_lines\\0x07DCD88F.mp3", "0x07DCD88F", "scripted_lines"); } }
    //    public static ScannerFile HASH08137472 { get { return new ScannerFile("01_scripted_lines\\0x08137472.mp3", "0x08137472", "scripted_lines"); } }
    //    public static ScannerFile HASH08138AE8 { get { return new ScannerFile("01_scripted_lines\\0x08138AE8.mp3", "0x08138AE8", "scripted_lines"); } }
    //    public static ScannerFile HASH083EB2E3 { get { return new ScannerFile("01_scripted_lines\\0x083EB2E3.mp3", "0x083EB2E3", "scripted_lines"); } }
    //    public static ScannerFile HASH084969C1 { get { return new ScannerFile("01_scripted_lines\\0x084969C1.mp3", "0x084969C1", "scripted_lines"); } }
    //    public static ScannerFile HASH08B98F20 { get { return new ScannerFile("01_scripted_lines\\0x08B98F20.mp3", "0x08B98F20", "scripted_lines"); } }
    //    public static ScannerFile HASH08D6E5A5 { get { return new ScannerFile("01_scripted_lines\\0x08D6E5A5.mp3", "0x08D6E5A5", "scripted_lines"); } }
    //    public static ScannerFile HASH08E29570 { get { return new ScannerFile("01_scripted_lines\\0x08E29570.mp3", "0x08E29570", "scripted_lines"); } }
    //    public static ScannerFile HASH091C12E0 { get { return new ScannerFile("01_scripted_lines\\0x091C12E0.mp3", "0x091C12E0", "scripted_lines"); } }
    //    public static ScannerFile HASH0927CCA7 { get { return new ScannerFile("01_scripted_lines\\0x0927CCA7.mp3", "0x0927CCA7", "scripted_lines"); } }
    //    public static ScannerFile HASH093D0F23 { get { return new ScannerFile("01_scripted_lines\\0x093D0F23.mp3", "0x093D0F23", "scripted_lines"); } }
    //    public static ScannerFile HASH097B0A47 { get { return new ScannerFile("01_scripted_lines\\0x097B0A47.mp3", "0x097B0A47", "scripted_lines"); } }
    //    public static ScannerFile HASH09814DE2 { get { return new ScannerFile("01_scripted_lines\\0x09814DE2.mp3", "0x09814DE2", "scripted_lines"); } }
    //    public static ScannerFile HASH09ADEC88 { get { return new ScannerFile("01_scripted_lines\\0x09ADEC88.mp3", "0x09ADEC88", "scripted_lines"); } }
    //    public static ScannerFile HASH0A053B49 { get { return new ScannerFile("01_scripted_lines\\0x0A053B49.mp3", "0x0A053B49", "scripted_lines"); } }
    //    public static ScannerFile HASH0A1B3E4C { get { return new ScannerFile("01_scripted_lines\\0x0A1B3E4C.mp3", "0x0A1B3E4C", "scripted_lines"); } }
    //    public static ScannerFile HASH0A29EB23 { get { return new ScannerFile("01_scripted_lines\\0x0A29EB23.mp3", "0x0A29EB23", "scripted_lines"); } }
    //    public static ScannerFile HASH0AA97460 { get { return new ScannerFile("01_scripted_lines\\0x0AA97460.mp3", "0x0AA97460", "scripted_lines"); } }
    //    public static ScannerFile HASH0AD51F6A { get { return new ScannerFile("01_scripted_lines\\0x0AD51F6A.mp3", "0x0AD51F6A", "scripted_lines"); } }
    //    public static ScannerFile HASH0AF13A84 { get { return new ScannerFile("01_scripted_lines\\0x0AF13A84.mp3", "0x0AF13A84", "scripted_lines"); } }
    //    public static ScannerFile HASH0AFD1BC2 { get { return new ScannerFile("01_scripted_lines\\0x0AFD1BC2.mp3", "0x0AFD1BC2", "scripted_lines"); } }
    //    public static ScannerFile HASH0B01A425 { get { return new ScannerFile("01_scripted_lines\\0x0B01A425.mp3", "0x0B01A425", "scripted_lines"); } }
    //    public static ScannerFile HASH0B09BEF6 { get { return new ScannerFile("01_scripted_lines\\0x0B09BEF6.mp3", "0x0B09BEF6", "scripted_lines"); } }
    //    public static ScannerFile HASH0B7DC711 { get { return new ScannerFile("01_scripted_lines\\0x0B7DC711.mp3", "0x0B7DC711", "scripted_lines"); } }
    //    public static ScannerFile HASH0B885CD8 { get { return new ScannerFile("01_scripted_lines\\0x0B885CD8.mp3", "0x0B885CD8", "scripted_lines"); } }
    //    public static ScannerFile HASH0B902335 { get { return new ScannerFile("01_scripted_lines\\0x0B902335.mp3", "0x0B902335", "scripted_lines"); } }
    //    public static ScannerFile HASH0B9C2AC1 { get { return new ScannerFile("01_scripted_lines\\0x0B9C2AC1.mp3", "0x0B9C2AC1", "scripted_lines"); } }
    //    public static ScannerFile HASH0BDD30E8 { get { return new ScannerFile("01_scripted_lines\\0x0BDD30E8.mp3", "0x0BDD30E8", "scripted_lines"); } }
    //    public static ScannerFile HASH0BF0ABD5 { get { return new ScannerFile("01_scripted_lines\\0x0BF0ABD5.mp3", "0x0BF0ABD5", "scripted_lines"); } }
    //    public static ScannerFile HASH0C1B7C74 { get { return new ScannerFile("01_scripted_lines\\0x0C1B7C74.mp3", "0x0C1B7C74", "scripted_lines"); } }
    //    public static ScannerFile HASH0C3C8054 { get { return new ScannerFile("01_scripted_lines\\0x0C3C8054.mp3", "0x0C3C8054", "scripted_lines"); } }
    //    public static ScannerFile HASH0C5713E5 { get { return new ScannerFile("01_scripted_lines\\0x0C5713E5.mp3", "0x0C5713E5", "scripted_lines"); } }
    //    public static ScannerFile HASH0C5BC7B0 { get { return new ScannerFile("01_scripted_lines\\0x0C5BC7B0.mp3", "0x0C5BC7B0", "scripted_lines"); } }
    //    public static ScannerFile HASH0C5F7B24 { get { return new ScannerFile("01_scripted_lines\\0x0C5F7B24.mp3", "0x0C5F7B24", "scripted_lines"); } }
    //    public static ScannerFile HASH0CB286C4 { get { return new ScannerFile("01_scripted_lines\\0x0CB286C4.mp3", "0x0CB286C4", "scripted_lines"); } }
    //    public static ScannerFile HASH0D321A78 { get { return new ScannerFile("01_scripted_lines\\0x0D321A78.mp3", "0x0D321A78", "scripted_lines"); } }
    //    public static ScannerFile HASH0D7F5BA7 { get { return new ScannerFile("01_scripted_lines\\0x0D7F5BA7.mp3", "0x0D7F5BA7", "scripted_lines"); } }
    //    public static ScannerFile HASH0DC66418 { get { return new ScannerFile("01_scripted_lines\\0x0DC66418.mp3", "0x0DC66418", "scripted_lines"); } }
    //    public static ScannerFile HASH0DDE56F3 { get { return new ScannerFile("01_scripted_lines\\0x0DDE56F3.mp3", "0x0DDE56F3", "scripted_lines"); } }
    //    public static ScannerFile HASH0DEBA202 { get { return new ScannerFile("01_scripted_lines\\0x0DEBA202.mp3", "0x0DEBA202", "scripted_lines"); } }
    //    public static ScannerFile HASH0DFFE738 { get { return new ScannerFile("01_scripted_lines\\0x0DFFE738.mp3", "0x0DFFE738", "scripted_lines"); } }
    //    public static ScannerFile HASH0E2B252B { get { return new ScannerFile("01_scripted_lines\\0x0E2B252B.mp3", "0x0E2B252B", "scripted_lines"); } }
    //    public static ScannerFile HASH0E5DDB1B { get { return new ScannerFile("01_scripted_lines\\0x0E5DDB1B.mp3", "0x0E5DDB1B", "scripted_lines"); } }
    //    public static ScannerFile HASH0E8C2586 { get { return new ScannerFile("01_scripted_lines\\0x0E8C2586.mp3", "0x0E8C2586", "scripted_lines"); } }
    //    public static ScannerFile HASH0ED3BB7F { get { return new ScannerFile("01_scripted_lines\\0x0ED3BB7F.mp3", "0x0ED3BB7F", "scripted_lines"); } }
    //    public static ScannerFile HASH0EF44F2C { get { return new ScannerFile("01_scripted_lines\\0x0EF44F2C.mp3", "0x0EF44F2C", "scripted_lines"); } }
    //    public static ScannerFile HASH0F1D6717 { get { return new ScannerFile("01_scripted_lines\\0x0F1D6717.mp3", "0x0F1D6717", "scripted_lines"); } }
    //    public static ScannerFile HASH0F2A4E66 { get { return new ScannerFile("01_scripted_lines\\0x0F2A4E66.mp3", "0x0F2A4E66", "scripted_lines"); } }
    //    public static ScannerFile HASH0F57ACB1 { get { return new ScannerFile("01_scripted_lines\\0x0F57ACB1.mp3", "0x0F57ACB1", "scripted_lines"); } }
    //    public static ScannerFile HASH0F704604 { get { return new ScannerFile("01_scripted_lines\\0x0F704604.mp3", "0x0F704604", "scripted_lines"); } }
    //    public static ScannerFile HASH0F8255E1 { get { return new ScannerFile("01_scripted_lines\\0x0F8255E1.mp3", "0x0F8255E1", "scripted_lines"); } }
    //    public static ScannerFile HASH0FD0D6F5 { get { return new ScannerFile("01_scripted_lines\\0x0FD0D6F5.mp3", "0x0FD0D6F5", "scripted_lines"); } }
    //    public static ScannerFile HASH10458A9D { get { return new ScannerFile("01_scripted_lines\\0x10458A9D.mp3", "0x10458A9D", "scripted_lines"); } }
    //    public static ScannerFile HASH1075F4DC { get { return new ScannerFile("01_scripted_lines\\0x1075F4DC.mp3", "0x1075F4DC", "scripted_lines"); } }
    //    public static ScannerFile HASH1078E105 { get { return new ScannerFile("01_scripted_lines\\0x1078E105.mp3", "0x1078E105", "scripted_lines"); } }
    //    public static ScannerFile HASH108405AA { get { return new ScannerFile("01_scripted_lines\\0x108405AA.mp3", "0x108405AA", "scripted_lines"); } }
    //    public static ScannerFile HASH10B7612A { get { return new ScannerFile("01_scripted_lines\\0x10B7612A.mp3", "0x10B7612A", "scripted_lines"); } }
    //    public static ScannerFile HASH10E29C6E { get { return new ScannerFile("01_scripted_lines\\0x10E29C6E.mp3", "0x10E29C6E", "scripted_lines"); } }
    //    public static ScannerFile HASH10EB80E5 { get { return new ScannerFile("01_scripted_lines\\0x10EB80E5.mp3", "0x10EB80E5", "scripted_lines"); } }
    //    public static ScannerFile HASH10EDE805 { get { return new ScannerFile("01_scripted_lines\\0x10EDE805.mp3", "0x10EDE805", "scripted_lines"); } }
    //    public static ScannerFile HASH11174006 { get { return new ScannerFile("01_scripted_lines\\0x11174006.mp3", "0x11174006", "scripted_lines"); } }
    //    public static ScannerFile HASH117239AB { get { return new ScannerFile("01_scripted_lines\\0x117239AB.mp3", "0x117239AB", "scripted_lines"); } }
    //    public static ScannerFile HASH11946C00 { get { return new ScannerFile("01_scripted_lines\\0x11946C00.mp3", "0x11946C00", "scripted_lines"); } }
    //    public static ScannerFile HASH119C4775 { get { return new ScannerFile("01_scripted_lines\\0x119C4775.mp3", "0x119C4775", "scripted_lines"); } }
    //    public static ScannerFile HASH11A9D669 { get { return new ScannerFile("01_scripted_lines\\0x11A9D669.mp3", "0x11A9D669", "scripted_lines"); } }
    //    public static ScannerFile HASH11CEB3EC { get { return new ScannerFile("01_scripted_lines\\0x11CEB3EC.mp3", "0x11CEB3EC", "scripted_lines"); } }
    //    public static ScannerFile HASH11F7DC3A { get { return new ScannerFile("01_scripted_lines\\0x11F7DC3A.mp3", "0x11F7DC3A", "scripted_lines"); } }
    //    public static ScannerFile HASH1259A260 { get { return new ScannerFile("01_scripted_lines\\0x1259A260.mp3", "0x1259A260", "scripted_lines"); } }
    //    public static ScannerFile HASH125DAD47 { get { return new ScannerFile("01_scripted_lines\\0x125DAD47.mp3", "0x125DAD47", "scripted_lines"); } }
    //    public static ScannerFile HASH1276F4B1 { get { return new ScannerFile("01_scripted_lines\\0x1276F4B1.mp3", "0x1276F4B1", "scripted_lines"); } }
    //    public static ScannerFile HASH12884CEB { get { return new ScannerFile("01_scripted_lines\\0x12884CEB.mp3", "0x12884CEB", "scripted_lines"); } }
    //    public static ScannerFile HASH1288DA4F { get { return new ScannerFile("01_scripted_lines\\0x1288DA4F.mp3", "0x1288DA4F", "scripted_lines"); } }
    //    public static ScannerFile HASH12AEE908 { get { return new ScannerFile("01_scripted_lines\\0x12AEE908.mp3", "0x12AEE908", "scripted_lines"); } }
    //    public static ScannerFile HASH12B349B2 { get { return new ScannerFile("01_scripted_lines\\0x12B349B2.mp3", "0x12B349B2", "scripted_lines"); } }
    //    public static ScannerFile HASH130F07AC { get { return new ScannerFile("01_scripted_lines\\0x130F07AC.mp3", "0x130F07AC", "scripted_lines"); } }
    //    public static ScannerFile HASH1334E4BA { get { return new ScannerFile("01_scripted_lines\\0x1334E4BA.mp3", "0x1334E4BA", "scripted_lines"); } }
    //    public static ScannerFile HASH141E9AF0 { get { return new ScannerFile("01_scripted_lines\\0x141E9AF0.mp3", "0x141E9AF0", "scripted_lines"); } }
    //    public static ScannerFile HASH14532861 { get { return new ScannerFile("01_scripted_lines\\0x14532861.mp3", "0x14532861", "scripted_lines"); } }
    //    public static ScannerFile HASH14F98E38 { get { return new ScannerFile("01_scripted_lines\\0x14F98E38.mp3", "0x14F98E38", "scripted_lines"); } }
    //    public static ScannerFile HASH152C3020 { get { return new ScannerFile("01_scripted_lines\\0x152C3020.mp3", "0x152C3020", "scripted_lines"); } }
    //    public static ScannerFile HASH158B2362 { get { return new ScannerFile("01_scripted_lines\\0x158B2362.mp3", "0x158B2362", "scripted_lines"); } }
    //    public static ScannerFile HASH15F6451B { get { return new ScannerFile("01_scripted_lines\\0x15F6451B.mp3", "0x15F6451B", "scripted_lines"); } }
    //    public static ScannerFile HASH165078B5 { get { return new ScannerFile("01_scripted_lines\\0x165078B5.mp3", "0x165078B5", "scripted_lines"); } }
    //    public static ScannerFile HASH167E6DA6 { get { return new ScannerFile("01_scripted_lines\\0x167E6DA6.mp3", "0x167E6DA6", "scripted_lines"); } }
    //    public static ScannerFile HASH169BA7E0 { get { return new ScannerFile("01_scripted_lines\\0x169BA7E0.mp3", "0x169BA7E0", "scripted_lines"); } }
    //    public static ScannerFile HASH16B27BD2 { get { return new ScannerFile("01_scripted_lines\\0x16B27BD2.mp3", "0x16B27BD2", "scripted_lines"); } }
    //    public static ScannerFile HASH16D57635 { get { return new ScannerFile("01_scripted_lines\\0x16D57635.mp3", "0x16D57635", "scripted_lines"); } }
    //    public static ScannerFile HASH16DF54FD { get { return new ScannerFile("01_scripted_lines\\0x16DF54FD.mp3", "0x16DF54FD", "scripted_lines"); } }
    //    public static ScannerFile HASH16E76B7B { get { return new ScannerFile("01_scripted_lines\\0x16E76B7B.mp3", "0x16E76B7B", "scripted_lines"); } }
    //    public static ScannerFile HASH16F228A5 { get { return new ScannerFile("01_scripted_lines\\0x16F228A5.mp3", "0x16F228A5", "scripted_lines"); } }
    //    public static ScannerFile HASH16FD3DC6 { get { return new ScannerFile("01_scripted_lines\\0x16FD3DC6.mp3", "0x16FD3DC6", "scripted_lines"); } }
    //    public static ScannerFile HASH171931DD { get { return new ScannerFile("01_scripted_lines\\0x171931DD.mp3", "0x171931DD", "scripted_lines"); } }
    //    public static ScannerFile HASH178BEBC0 { get { return new ScannerFile("01_scripted_lines\\0x178BEBC0.mp3", "0x178BEBC0", "scripted_lines"); } }
    //    public static ScannerFile HASH17AC2479 { get { return new ScannerFile("01_scripted_lines\\0x17AC2479.mp3", "0x17AC2479", "scripted_lines"); } }
    //    public static ScannerFile HASH18115D81 { get { return new ScannerFile("01_scripted_lines\\0x18115D81.mp3", "0x18115D81", "scripted_lines"); } }
    //    public static ScannerFile HASH1827FEB0 { get { return new ScannerFile("01_scripted_lines\\0x1827FEB0.mp3", "0x1827FEB0", "scripted_lines"); } }
    //    public static ScannerFile HASH183E1F75 { get { return new ScannerFile("01_scripted_lines\\0x183E1F75.mp3", "0x183E1F75", "scripted_lines"); } }
    //    public static ScannerFile HASH1846C75D { get { return new ScannerFile("01_scripted_lines\\0x1846C75D.mp3", "0x1846C75D", "scripted_lines"); } }
    //    public static ScannerFile HASH18843C41 { get { return new ScannerFile("01_scripted_lines\\0x18843C41.mp3", "0x18843C41", "scripted_lines"); } }
    //    public static ScannerFile HASH18A02156 { get { return new ScannerFile("01_scripted_lines\\0x18A02156.mp3", "0x18A02156", "scripted_lines"); } }
    //    public static ScannerFile HASH18DEFFCD { get { return new ScannerFile("01_scripted_lines\\0x18DEFFCD.mp3", "0x18DEFFCD", "scripted_lines"); } }
    //    public static ScannerFile HASH19296CAA { get { return new ScannerFile("01_scripted_lines\\0x19296CAA.mp3", "0x19296CAA", "scripted_lines"); } }
    //    public static ScannerFile HASH194740B0 { get { return new ScannerFile("01_scripted_lines\\0x194740B0.mp3", "0x194740B0", "scripted_lines"); } }
    //    public static ScannerFile HASH19505B83 { get { return new ScannerFile("01_scripted_lines\\0x19505B83.mp3", "0x19505B83", "scripted_lines"); } }
    //    public static ScannerFile HASH196B32E0 { get { return new ScannerFile("01_scripted_lines\\0x196B32E0.mp3", "0x196B32E0", "scripted_lines"); } }
    //    public static ScannerFile HASH19B73C44 { get { return new ScannerFile("01_scripted_lines\\0x19B73C44.mp3", "0x19B73C44", "scripted_lines"); } }
    //    public static ScannerFile HASH1A1E2335 { get { return new ScannerFile("01_scripted_lines\\0x1A1E2335.mp3", "0x1A1E2335", "scripted_lines"); } }
    //    public static ScannerFile HASH1A58D8EF { get { return new ScannerFile("01_scripted_lines\\0x1A58D8EF.mp3", "0x1A58D8EF", "scripted_lines"); } }
    //    public static ScannerFile HASH1A9A3E12 { get { return new ScannerFile("01_scripted_lines\\0x1A9A3E12.mp3", "0x1A9A3E12", "scripted_lines"); } }
    //    public static ScannerFile HASH1AA7D7B6 { get { return new ScannerFile("01_scripted_lines\\0x1AA7D7B6.mp3", "0x1AA7D7B6", "scripted_lines"); } }
    //    public static ScannerFile HASH1ACBFE04 { get { return new ScannerFile("01_scripted_lines\\0x1ACBFE04.mp3", "0x1ACBFE04", "scripted_lines"); } }
    //    public static ScannerFile HASH1B8DB7C3 { get { return new ScannerFile("01_scripted_lines\\0x1B8DB7C3.mp3", "0x1B8DB7C3", "scripted_lines"); } }
    //    public static ScannerFile HASH1BE3AF18 { get { return new ScannerFile("01_scripted_lines\\0x1BE3AF18.mp3", "0x1BE3AF18", "scripted_lines"); } }
    //    public static ScannerFile HASH1C34C0F5 { get { return new ScannerFile("01_scripted_lines\\0x1C34C0F5.mp3", "0x1C34C0F5", "scripted_lines"); } }
    //    public static ScannerFile HASH1C4BE8AD { get { return new ScannerFile("01_scripted_lines\\0x1C4BE8AD.mp3", "0x1C4BE8AD", "scripted_lines"); } }
    //    public static ScannerFile HASH1C5303DF { get { return new ScannerFile("01_scripted_lines\\0x1C5303DF.mp3", "0x1C5303DF", "scripted_lines"); } }
    //    public static ScannerFile HASH1C5727B4 { get { return new ScannerFile("01_scripted_lines\\0x1C5727B4.mp3", "0x1C5727B4", "scripted_lines"); } }
    //    public static ScannerFile HASH1C66569D { get { return new ScannerFile("01_scripted_lines\\0x1C66569D.mp3", "0x1C66569D", "scripted_lines"); } }
    //    public static ScannerFile HASH1C76B3B4 { get { return new ScannerFile("01_scripted_lines\\0x1C76B3B4.mp3", "0x1C76B3B4", "scripted_lines"); } }
    //    public static ScannerFile HASH1C7BC165 { get { return new ScannerFile("01_scripted_lines\\0x1C7BC165.mp3", "0x1C7BC165", "scripted_lines"); } }
    //    public static ScannerFile HASH1C89DA80 { get { return new ScannerFile("01_scripted_lines\\0x1C89DA80.mp3", "0x1C89DA80", "scripted_lines"); } }
    //    public static ScannerFile HASH1CA4F480 { get { return new ScannerFile("01_scripted_lines\\0x1CA4F480.mp3", "0x1CA4F480", "scripted_lines"); } }
    //    public static ScannerFile HASH1CB9B1BE { get { return new ScannerFile("01_scripted_lines\\0x1CB9B1BE.mp3", "0x1CB9B1BE", "scripted_lines"); } }
    //    public static ScannerFile HASH1CBFFF47 { get { return new ScannerFile("01_scripted_lines\\0x1CBFFF47.mp3", "0x1CBFFF47", "scripted_lines"); } }
    //    public static ScannerFile HASH1D148E21 { get { return new ScannerFile("01_scripted_lines\\0x1D148E21.mp3", "0x1D148E21", "scripted_lines"); } }
    //    public static ScannerFile HASH1D19EB77 { get { return new ScannerFile("01_scripted_lines\\0x1D19EB77.mp3", "0x1D19EB77", "scripted_lines"); } }
    //    public static ScannerFile HASH1D4C8E22 { get { return new ScannerFile("01_scripted_lines\\0x1D4C8E22.mp3", "0x1D4C8E22", "scripted_lines"); } }
    //    public static ScannerFile HASH1D4F5F3F { get { return new ScannerFile("01_scripted_lines\\0x1D4F5F3F.mp3", "0x1D4F5F3F", "scripted_lines"); } }
    //    public static ScannerFile HASH1D8203E2 { get { return new ScannerFile("01_scripted_lines\\0x1D8203E2.mp3", "0x1D8203E2", "scripted_lines"); } }
    //    public static ScannerFile HASH1D894914 { get { return new ScannerFile("01_scripted_lines\\0x1D894914.mp3", "0x1D894914", "scripted_lines"); } }
    //    public static ScannerFile HASH1DA7CF40 { get { return new ScannerFile("01_scripted_lines\\0x1DA7CF40.mp3", "0x1DA7CF40", "scripted_lines"); } }
    //    public static ScannerFile HASH1DB18B27 { get { return new ScannerFile("01_scripted_lines\\0x1DB18B27.mp3", "0x1DB18B27", "scripted_lines"); } }
    //    public static ScannerFile HASH1DBD4790 { get { return new ScannerFile("01_scripted_lines\\0x1DBD4790.mp3", "0x1DBD4790", "scripted_lines"); } }
    //    public static ScannerFile HASH1DC689AF { get { return new ScannerFile("01_scripted_lines\\0x1DC689AF.mp3", "0x1DC689AF", "scripted_lines"); } }
    //    public static ScannerFile HASH1DE12E58 { get { return new ScannerFile("01_scripted_lines\\0x1DE12E58.mp3", "0x1DE12E58", "scripted_lines"); } }
    //    public static ScannerFile HASH1DFF2F14 { get { return new ScannerFile("01_scripted_lines\\0x1DFF2F14.mp3", "0x1DFF2F14", "scripted_lines"); } }
    //    public static ScannerFile HASH1E133BCE { get { return new ScannerFile("01_scripted_lines\\0x1E133BCE.mp3", "0x1E133BCE", "scripted_lines"); } }
    //    public static ScannerFile HASH1E34857B { get { return new ScannerFile("01_scripted_lines\\0x1E34857B.mp3", "0x1E34857B", "scripted_lines"); } }
    //    public static ScannerFile HASH1E8024DB { get { return new ScannerFile("01_scripted_lines\\0x1E8024DB.mp3", "0x1E8024DB", "scripted_lines"); } }
    //    public static ScannerFile HASH1E89D108 { get { return new ScannerFile("01_scripted_lines\\0x1E89D108.mp3", "0x1E89D108", "scripted_lines"); } }
    //    public static ScannerFile HASH1E9DE1DD { get { return new ScannerFile("01_scripted_lines\\0x1E9DE1DD.mp3", "0x1E9DE1DD", "scripted_lines"); } }
    //    public static ScannerFile HASH1EA59FB1 { get { return new ScannerFile("01_scripted_lines\\0x1EA59FB1.mp3", "0x1EA59FB1", "scripted_lines"); } }
    //    public static ScannerFile HASH1EB09F1D { get { return new ScannerFile("01_scripted_lines\\0x1EB09F1D.mp3", "0x1EB09F1D", "scripted_lines"); } }
    //    public static ScannerFile HASH1ED51471 { get { return new ScannerFile("01_scripted_lines\\0x1ED51471.mp3", "0x1ED51471", "scripted_lines"); } }
    //    public static ScannerFile HASH1F71BEF7 { get { return new ScannerFile("01_scripted_lines\\0x1F71BEF7.mp3", "0x1F71BEF7", "scripted_lines"); } }
    //    public static ScannerFile HASH1F9FBA77 { get { return new ScannerFile("01_scripted_lines\\0x1F9FBA77.mp3", "0x1F9FBA77", "scripted_lines"); } }
    //    public static ScannerFile HASH1FAB0581 { get { return new ScannerFile("01_scripted_lines\\0x1FAB0581.mp3", "0x1FAB0581", "scripted_lines"); } }
    //    public static ScannerFile HASH1FC130C5 { get { return new ScannerFile("01_scripted_lines\\0x1FC130C5.mp3", "0x1FC130C5", "scripted_lines"); } }
    //    public static ScannerFile HASH1FD90887 { get { return new ScannerFile("01_scripted_lines\\0x1FD90887.mp3", "0x1FD90887", "scripted_lines"); } }
    //}
    //public class special_instructions_approach
    //{
    //    public static ScannerFile Engagefromthe { get { return new ScannerFile("01_special_instructions_approach\\0x05B3288B.mp3", "Engage from the...", "special_instructions_approach"); } }
    //    public static ScannerFile Approachfromthe { get { return new ScannerFile("01_special_instructions_approach\\0x0E2BF983.mp3", "Approach from the...", "special_instructions_approach"); } }
    //    public static ScannerFile Engagefromthe1 { get { return new ScannerFile("01_special_instructions_approach\\0x13EF4503.mp3", "Engage...from the...", "special_instructions_approach"); } }
    //    public static ScannerFile Convenefromthe { get { return new ScannerFile("01_special_instructions_approach\\0x18644DEE.mp3", "Convene from the...", "special_instructions_approach"); } }
    //    public static ScannerFile Approachfromthe1 { get { return new ScannerFile("01_special_instructions_approach\\0x1FF51D16.mp3", "Approach from the...", "special_instructions_approach"); } }
    //}
    //public class special_ins_app_dir
    //{
    //    public static ScannerFile West { get { return new ScannerFile("01_special_ins_app_dir\\0x00D13053.mp3", "West.", "special_ins_app_dir"); } }
    //    public static ScannerFile South { get { return new ScannerFile("01_special_ins_app_dir\\0x01CD1C1A.mp3", "South.", "special_ins_app_dir"); } }
    //    public static ScannerFile Rear { get { return new ScannerFile("01_special_ins_app_dir\\0x08633D59.mp3", "Rear.", "special_ins_app_dir"); } }
    //    public static ScannerFile Eastside { get { return new ScannerFile("01_special_ins_app_dir\\0x0B61A4C6.mp3", "East side.", "special_ins_app_dir"); } }
    //    public static ScannerFile Northentrance { get { return new ScannerFile("01_special_ins_app_dir\\0x0C81C88E.mp3", "North entrance.", "special_ins_app_dir"); } }
    //    public static ScannerFile Eastentrance { get { return new ScannerFile("01_special_ins_app_dir\\0x0D6B53E7.mp3", "East entrance.", "special_ins_app_dir"); } }
    //    public static ScannerFile Frontentrance { get { return new ScannerFile("01_special_ins_app_dir\\0x0DAF97CD.mp3", "Front entrance.", "special_ins_app_dir"); } }
    //    public static ScannerFile Westentrance { get { return new ScannerFile("01_special_ins_app_dir\\0x0F81625C.mp3", "West entrance.", "special_ins_app_dir"); } }
    //    public static ScannerFile Northside { get { return new ScannerFile("01_special_ins_app_dir\\0x1159147E.mp3", "North side.", "special_ins_app_dir"); } }
    //    public static ScannerFile East { get { return new ScannerFile("01_special_ins_app_dir\\0x12F149E3.mp3", "East.", "special_ins_app_dir"); } }
    //    public static ScannerFile Southside { get { return new ScannerFile("01_special_ins_app_dir\\0x14223FB2.mp3", "South side.", "special_ins_app_dir"); } }
    //    public static ScannerFile North { get { return new ScannerFile("01_special_ins_app_dir\\0x16D1886A.mp3", "North.", "special_ins_app_dir"); } }
    //    public static ScannerFile Southentrance { get { return new ScannerFile("01_special_ins_app_dir\\0x1B075B88.mp3", "South entrance.", "special_ins_app_dir"); } }
    //    public static ScannerFile Front { get { return new ScannerFile("01_special_ins_app_dir\\0x1D1883D9.mp3", "Front.", "special_ins_app_dir"); } }
    //    public static ScannerFile Rearentrance { get { return new ScannerFile("01_special_ins_app_dir\\0x1DB770EB.mp3", "Rear entrance.", "special_ins_app_dir"); } }
    //    public static ScannerFile Westside { get { return new ScannerFile("01_special_ins_app_dir\\0x1F58477F.mp3", "West side.", "special_ins_app_dir"); } }
    //}
    //public class special_vehicle
    //{
    //    public static ScannerFile Drivingadigger { get { return new ScannerFile("01_special_vehicle\\0x000D2597.mp3", "Driving a digger.", "special_vehicle"); } }
    //    public static ScannerFile Flyingamilitaryaircraft { get { return new ScannerFile("01_special_vehicle\\0x00BA742F.mp3", "Flying a military aircraft.", "special_vehicle"); } }
    //    public static ScannerFile Drivingatank { get { return new ScannerFile("01_special_vehicle\\0x01684C1F.mp3", "Driving a tank.", "special_vehicle"); } }
    //    public static ScannerFile Drivingapolicecar { get { return new ScannerFile("01_special_vehicle\\0x023F3422.mp3", "Driving a police car.", "special_vehicle"); } }
    //    public static ScannerFile Onadarkcoloredhorse { get { return new ScannerFile("01_special_vehicle\\0x02C1BD67.mp3", "On a dark-colored horse.", "special_vehicle"); } }
    //    public static ScannerFile Drivingadumptruck { get { return new ScannerFile("01_special_vehicle\\0x04474592.mp3", "Driving a dump truck.", "special_vehicle"); } }
    //    public static ScannerFile Ridingacustomizedmotorcycle { get { return new ScannerFile("01_special_vehicle\\0x059DD2D4.mp3", "Riding a customized motorcycle.", "special_vehicle"); } }
    //    public static ScannerFile Ridingamountainbike { get { return new ScannerFile("01_special_vehicle\\0x05AA96B3.mp3", "Riding a mountain bike.", "special_vehicle"); } }
    //    public static ScannerFile Onayacht { get { return new ScannerFile("01_special_vehicle\\0x05DA0986.mp3", "On a yacht.", "special_vehicle"); } }
    //    public static ScannerFile OperatinganAnnihilatorhelicopter { get { return new ScannerFile("01_special_vehicle\\0x06B3CFF4.mp3", "Operating an Annihilator helicopter.", "special_vehicle"); } }
    //    public static ScannerFile Onaschooner { get { return new ScannerFile("01_special_vehicle\\0x07158FF4.mp3", "On a schooner.", "special_vehicle"); } }
    //    public static ScannerFile OperatinganAnnihilatorAttackHelicopter { get { return new ScannerFile("01_special_vehicle\\0x079051AE.mp3", "Operating an Annihilator Attack Helicopter.", "special_vehicle"); } }
    //    public static ScannerFile Flyingacivilianairplane { get { return new ScannerFile("01_special_vehicle\\0x079FB220.mp3", "Flying a civilian airplane.", "special_vehicle"); } }
    //    public static ScannerFile Operatingamilitaryhelicopter { get { return new ScannerFile("01_special_vehicle\\0x07BB9776.mp3", "Operating a military helicopter.", "special_vehicle"); } }
    //    public static ScannerFile Onalightcoloredhorse { get { return new ScannerFile("01_special_vehicle\\0x0840074D.mp3", "On a light-colored horse.", "special_vehicle"); } }
    //    public static ScannerFile Drivinganambulance { get { return new ScannerFile("01_special_vehicle\\0x0A95F1BD.mp3", "Driving an ambulance.", "special_vehicle"); } }
    //    public static ScannerFile Ridingablackhorse { get { return new ScannerFile("01_special_vehicle\\0x0ACBBD8F.mp3", "Riding a black horse.", "special_vehicle"); } }
    //    public static ScannerFile Drivingagarbagetruck { get { return new ScannerFile("01_special_vehicle\\0x0B1FA404.mp3", "Driving a garbage truck.", "special_vehicle"); } }
    //    public static ScannerFile OperatingaMaverickhelicopter { get { return new ScannerFile("01_special_vehicle\\0x0B9D5088.mp3", "Operating a Maverick helicopter.", "special_vehicle"); } }
    //    public static ScannerFile Drivingabulldozer { get { return new ScannerFile("01_special_vehicle\\0x0C505B49.mp3", "Driving a bulldozer.", "special_vehicle"); } }
    //    public static ScannerFile Ridingawhitehorse { get { return new ScannerFile("01_special_vehicle\\0x0D808D20.mp3", "Riding a white horse.", "special_vehicle"); } }
    //    public static ScannerFile Drivingapolicesedan { get { return new ScannerFile("01_special_vehicle\\0x0E0C0BBC.mp3", "Driving a police sedan.", "special_vehicle"); } }
    //    public static ScannerFile Onabrownhorse { get { return new ScannerFile("01_special_vehicle\\0x0E38C84F.mp3", "On a brown horse.", "special_vehicle"); } }
    //    public static ScannerFile Flyingamilitaryairplane { get { return new ScannerFile("01_special_vehicle\\0x0FEC9294.mp3", "Flying a military airplane.", "special_vehicle"); } }
    //    public static ScannerFile Ridingaracingbike { get { return new ScannerFile("01_special_vehicle\\0x10F1559B.mp3", "Riding a racing bike.", "special_vehicle"); } }
    //    public static ScannerFile Ridingadarkcoloredhorse { get { return new ScannerFile("01_special_vehicle\\0x110B19FA.mp3", "Riding a dark-colored horse.", "special_vehicle"); } }
    //    public static ScannerFile Flyinganairplane { get { return new ScannerFile("01_special_vehicle\\0x11E586AD.mp3", "Flying an airplane.", "special_vehicle"); } }
    //    public static ScannerFile RidingaBMXbike { get { return new ScannerFile("01_special_vehicle\\0x12C22CBB.mp3", "Riding a BMX bike.", "special_vehicle"); } }
    //    public static ScannerFile Drivingatippertruck { get { return new ScannerFile("01_special_vehicle\\0x1330A850.mp3", "Driving a tipper truck.", "special_vehicle"); } }
    //    public static ScannerFile Ridingamotorcycle { get { return new ScannerFile("01_special_vehicle\\0x13A1BDA3.mp3", "Riding a motorcycle.", "special_vehicle"); } }
    //    public static ScannerFile PilotinganAnnihilatorhelicopter { get { return new ScannerFile("01_special_vehicle\\0x142D6AE7.mp3", "Piloting an Annihilator helicopter.", "special_vehicle"); } }
    //    public static ScannerFile Onaboat { get { return new ScannerFile("01_special_vehicle\\0x144919B6.mp3", "On a boat.", "special_vehicle"); } }
    //    public static ScannerFile Flyingamilitaryhelicopter { get { return new ScannerFile("01_special_vehicle\\0x15EAF3D3.mp3", "Flying a military helicopter.", "special_vehicle"); } }
    //    public static ScannerFile FlyingaVTOLaircraft { get { return new ScannerFile("01_special_vehicle\\0x186F5839.mp3", "Flying a VTOL aircraft.", "special_vehicle"); } }
    //    public static ScannerFile Ridingalightcoloredhorse { get { return new ScannerFile("01_special_vehicle\\0x191228F1.mp3", "Riding a light-colored horse.", "special_vehicle"); } }
    //    public static ScannerFile Onawhitehorse { get { return new ScannerFile("01_special_vehicle\\0x1B3E289B.mp3", "On a white horse.", "special_vehicle"); } }
    //    public static ScannerFile Onablackhorse { get { return new ScannerFile("01_special_vehicle\\0x1C5DE0B3.mp3", "On a black horse.", "special_vehicle"); } }
    //    public static ScannerFile Ridingabrownhorse { get { return new ScannerFile("01_special_vehicle\\0x1CCB2569.mp3", "Riding a brown horse.", "special_vehicle"); } }
    //    public static ScannerFile PilotingaMaverickhelicopter { get { return new ScannerFile("01_special_vehicle\\0x1D77B43D.mp3", "Piloting a Maverick helicopter.", "special_vehicle"); } }
    //}
    public class specific_location//IS USED JUST NOT REF!
    {
        public static ScannerFile Vinewood247Market { get { return new ScannerFile("01_specific_location\\0x000E7300.mp3", "Vinewood 24/7 Market", "specific_location"); } }
        public static ScannerFile CentralLaMesaRonStation { get { return new ScannerFile("01_specific_location\\0x0011827A.mp3", "Central La Mesa Ron Station", "specific_location"); } }
        public static ScannerFile SenoraRecyclingCenter { get { return new ScannerFile("01_specific_location\\0x0044397F.mp3", "Senora Recycling Center", "specific_location"); } }
        public static ScannerFile RockfordPlazaSubwayStation { get { return new ScannerFile("01_specific_location\\0x005E5414.mp3", "Rockford Plaza Subway Station", "specific_location"); } }
        public static ScannerFile BraddockPassGasStation { get { return new ScannerFile("01_specific_location\\0x007AC3FC.mp3", "Braddock Pass Gas Station", "specific_location"); } }
        public static ScannerFile RockfordHillsDiderSachs { get { return new ScannerFile("01_specific_location\\0x0092CBCB.mp3", "Rockford Hills Dider Sachs", "specific_location"); } }
        public static ScannerFile LosSantosRiver { get { return new ScannerFile("01_specific_location\\0x00CA973E.mp3", "The Los Santos River", "specific_location"); } }
        public static ScannerFile ChumashPier { get { return new ScannerFile("01_specific_location\\0x00EF8558.mp3", "Chumash Pier", "specific_location"); } }
        public static ScannerFile QueensburyBoxingClub { get { return new ScannerFile("01_specific_location\\0x00FEFA6E.mp3", "Queensbury Boxing Club", "specific_location"); } }
        public static ScannerFile CatonBankingGroupBuilding { get { return new ScannerFile("01_specific_location\\0x014AA746.mp3", "Caton Banking Group Building", "specific_location"); } }
        public static ScannerFile StrawberryDollarPills { get { return new ScannerFile("01_specific_location\\0x017D2BE2.mp3", "The Dollar Pills Store in Strawberry", "specific_location"); } }
        public static ScannerFile KhalafiaBridge2 { get { return new ScannerFile("01_specific_location\\0x01800482.mp3", "Khalafia Bridge", "specific_location"); } }
        public static ScannerFile SatelliteArray { get { return new ScannerFile("01_specific_location\\0x01A84F28.mp3", "The Satellite Array", "specific_location"); } }
        public static ScannerFile SandyShoresSatelliteArray { get { return new ScannerFile("01_specific_location\\0x01CA4D77.mp3", "Sandy Shores Satellite Array", "specific_location"); } }
        public static ScannerFile SilverLakeRonStation { get { return new ScannerFile("01_specific_location\\0x021501AD.mp3", "Silver Lake Ron Station", "specific_location"); } }
        public static ScannerFile TheFishNet { get { return new ScannerFile("01_specific_location\\0x02249C78.mp3", "The Fish Net", "specific_location"); } }
        public static ScannerFile VinewoodMovieLot { get { return new ScannerFile("01_specific_location\\0x02389919.mp3", "Vinewood Movie Lot", "specific_location"); } }
        public static ScannerFile PortollaDriverPosonbys { get { return new ScannerFile("01_specific_location\\0x0289F802.mp3", "Portolla Drive Posonbys", "specific_location"); } }
        public static ScannerFile PostOpHeadquarters { get { return new ScannerFile("01_specific_location\\0x02967EFD.mp3", "The PostOp Headquarters", "specific_location"); } }
        public static ScannerFile BolingbrokePenitentiary { get { return new ScannerFile("01_specific_location\\0x02A305DE.mp3", "Bolingbroke Penitentiary", "specific_location"); } }
        public static ScannerFile RonAlternatesWindFarm { get { return new ScannerFile("01_specific_location\\0x02A53146.mp3", "The Ron Alternates Wind Farm", "specific_location"); } }
        public static ScannerFile YellowJackInn { get { return new ScannerFile("01_specific_location\\0x02C36B8B.mp3", "The Yellow Jack Inn", "specific_location"); } }
        public static ScannerFile LosSantosRiverChannels { get { return new ScannerFile("01_specific_location\\0x02DEC59F.mp3", "The Los Santos River Channels", "specific_location"); } }
        public static ScannerFile LSDrainageChannel { get { return new ScannerFile("01_specific_location\\0x02EC9FB5.mp3", "The LS Drainage Channel", "specific_location"); } }
        public static ScannerFile UpNAtomDiner { get { return new ScannerFile("01_specific_location\\0x035776E6.mp3", "The Up-n-Atom Diner", "specific_location"); } }
        public static ScannerFile PillboxHillConstructionSite { get { return new ScannerFile("01_specific_location\\0x03949A0F.mp3", "0x03949A0F", "specific_location"); } }
        public static ScannerFile VinewoodBurgerShot { get { return new ScannerFile("01_specific_location\\0x03A2A34A.mp3", "Vinewood Burger Shot", "specific_location"); } }
        public static ScannerFile ChumashBeachClub { get { return new ScannerFile("01_specific_location\\0x0431FE2B.mp3", "Chumash Beach Club", "specific_location"); } }
        public static ScannerFile LittleSeoulXeroStation { get { return new ScannerFile("01_specific_location\\0x04510C42.mp3", "Little Seoul Xero Station", "specific_location"); } }
        public static ScannerFile ShamorshootasRanch { get { return new ScannerFile("01_specific_location\\0x045D23E3.mp3", "Shamorshoota Ranch", "specific_location"); } }
        public static ScannerFile AlamoSeaBikerCompound { get { return new ScannerFile("01_specific_location\\0x04817594.mp3", "Alamo Sea Biker Compound", "specific_location"); } }
        public static ScannerFile MirrorParkCluckingBell { get { return new ScannerFile("01_specific_location\\0x04D70992.mp3", "Mirror Park Clucking Bell", "specific_location"); } }
        public static ScannerFile StrawberryMorgue { get { return new ScannerFile("01_specific_location\\0x04F66C50.mp3", "The Strawberry Morgue", "specific_location"); } }
        public static ScannerFile VinewoodToursBuilding { get { return new ScannerFile("01_specific_location\\0x04F6FA01.mp3", "The Vinewood Tours Building", "specific_location"); } }
        public static ScannerFile TataviaMountains { get { return new ScannerFile("01_specific_location\\0x051C5D0C.mp3", "Tatavia Mountains", "specific_location"); } }
        public static ScannerFile ChilliadLoggingCamp { get { return new ScannerFile("01_specific_location\\0x05217FAC.mp3", "Chilliad Logging Camp", "specific_location"); } }
        public static ScannerFile RedoowdLightsMotocross2 { get { return new ScannerFile("01_specific_location\\0x053A9900.mp3", "The Redwood Lights Motocross Track", "specific_location"); } }
        public static ScannerFile LosSantosBagCompany { get { return new ScannerFile("01_specific_location\\0x05505BE8.mp3", "Los Santos Bag Company", "specific_location"); } }
        public static ScannerFile MorningwoodRonStation { get { return new ScannerFile("01_specific_location\\0x056AF0EC.mp3", "Morningwood Ron Station", "specific_location"); } }
        public static ScannerFile EastLSDiner69er { get { return new ScannerFile("01_specific_location\\0x059E6639.mp3", "East LS Diner 69er", "specific_location"); } }
        public static ScannerFile BJSmithRecCenter { get { return new ScannerFile("01_specific_location\\0x05AB836E.mp3", "The BJ Smith Rec Center", "specific_location"); } }
        public static ScannerFile LagoZancudoCauseway { get { return new ScannerFile("01_specific_location\\0x068CED6A.mp3", "Lago Zancudo Causeway", "specific_location"); } }
        public static ScannerFile RockfordHillsPumpNRun { get { return new ScannerFile("01_specific_location\\0x06AD518B.mp3", "Rockford Hills Pump-N-Run", "specific_location"); } }
        public static ScannerFile ZancudoRidgeFarm { get { return new ScannerFile("01_specific_location\\0x06C75569.mp3", "Zancudo Ridge Farm", "specific_location"); } }
        public static ScannerFile MarlowVineyard { get { return new ScannerFile("01_specific_location\\0x06EEB5C2.mp3", "The Marlow VIneyard", "specific_location"); } }
        public static ScannerFile SouthLaMesaRonStation2 { get { return new ScannerFile("01_specific_location\\0x0723E151.mp3", "0x0723E151", "specific_location"); } }
        public static ScannerFile ElGordoLighthouse2 { get { return new ScannerFile("01_specific_location\\0x0761393B.mp3", "El Gordo Lighthouse", "specific_location"); } }
        public static ScannerFile LittleSeoulRonStation { get { return new ScannerFile("01_specific_location\\0x076BF9A3.mp3", "Little Seoul Ron Station", "specific_location"); } }
        public static ScannerFile VangelicoJewelryStore2 { get { return new ScannerFile("01_specific_location\\0x076E01B0.mp3", "The Vangelico Jewelry Store", "specific_location"); } }
        public static ScannerFile DelPerroShoppingPromenade { get { return new ScannerFile("01_specific_location\\0x077E335F.mp3", "Del Perro Shopping Promenade", "specific_location"); } }
        public static ScannerFile VinewoodPlaza { get { return new ScannerFile("01_specific_location\\0x078D31E5.mp3", "VinewoodPlaza", "specific_location"); } }
        public static ScannerFile Galilee { get { return new ScannerFile("01_specific_location\\0x07910E35.mp3", "Galilee", "specific_location"); } }
        public static ScannerFile JetsamShippingTerminal { get { return new ScannerFile("01_specific_location\\0x07DD9E5C.mp3", "The Jetsam Shipping Terminal", "specific_location"); } }
        public static ScannerFile PaulaSpringsTramway { get { return new ScannerFile("01_specific_location\\0x07FB062C.mp3", "The Paula Springs Tramway", "specific_location"); } }
        public static ScannerFile PlanetVinewood { get { return new ScannerFile("01_specific_location\\0x081BD374.mp3", "Planet Vinewood", "specific_location"); } }
        public static ScannerFile StrawberryShoppingPlaza { get { return new ScannerFile("01_specific_location\\0x0868B699.mp3", "Strawberry Shopping Plaza", "specific_location"); } }
        public static ScannerFile PisswasserFactory { get { return new ScannerFile("01_specific_location\\0x08AA4C64.mp3", "The Pisswasser Factory", "specific_location"); } }
        public static ScannerFile DelPerroNewSakiRestaurant { get { return new ScannerFile("01_specific_location\\0x08D9D223.mp3", "The Del Perro New Saki Restaurant", "specific_location"); } }
        public static ScannerFile GentryManorHotel { get { return new ScannerFile("01_specific_location\\0x08E0DB6C.mp3", "Gentry Manor Hotel", "specific_location"); } }
        public static ScannerFile SenoraWindfarmTrailerPark { get { return new ScannerFile("01_specific_location\\0x096C35C1.mp3", "Senora Windfarm Trailer Park", "specific_location"); } }
        public static ScannerFile LSRiver2 { get { return new ScannerFile("01_specific_location\\0x096CA882.mp3", "The LS River", "specific_location"); } }
        public static ScannerFile TextileCityBusDepot { get { return new ScannerFile("01_specific_location\\0x09A9666F.mp3", "Textile City Bus Depot", "specific_location"); } }
        public static ScannerFile SubwayConstructionTunnels { get { return new ScannerFile("01_specific_location\\0x09E1E461.mp3", "The Subway Construction Tunnels", "specific_location"); } }
        public static ScannerFile VinewoodRonStation { get { return new ScannerFile("01_specific_location\\0x09E4AAC8.mp3", "Vinewood Ron Station", "specific_location"); } }
        public static ScannerFile CapeCatfish { get { return new ScannerFile("01_specific_location\\0x09E521B9.mp3", "Cape Catfish", "specific_location"); } }
        public static ScannerFile EarlsMiniMart { get { return new ScannerFile("01_specific_location\\0x09E57626.mp3", "Earls Mini Mart", "specific_location"); } }
        public static ScannerFile CassidyCreekBridge { get { return new ScannerFile("01_specific_location\\0x09F6C27C.mp3", "The Cassidy Creek Bridge", "specific_location"); } }
        public static ScannerFile MazeBankOfLosSantos { get { return new ScannerFile("01_specific_location\\0x09FE57DE.mp3", "The Maze Bank of Los Santos", "specific_location"); } }
        public static ScannerFile AirplaneRecyclingYard { get { return new ScannerFile("01_specific_location\\0x0A158A5B.mp3", "The Airplane Recycling Yard", "specific_location"); } }
        public static ScannerFile LSXFireDepartment { get { return new ScannerFile("01_specific_location\\0x0A281CB4.mp3", "LSX Fire Department", "specific_location"); } }
        public static ScannerFile RockfordHillsFD { get { return new ScannerFile("01_specific_location\\0x0A33D1E1.mp3", "Rockford Hills Fire Department", "specific_location"); } }
        public static ScannerFile GranadeSenoraDesert { get { return new ScannerFile("01_specific_location\\0x0A4084AF.mp3", "The Grande Senora Desert", "specific_location"); } }
        public static ScannerFile MissioRowPD { get { return new ScannerFile("01_specific_location\\0x0A45FA8A.mp3", "Mission Row Police Department", "specific_location"); } }
        public static ScannerFile MirrorParkAutoRepairs { get { return new ScannerFile("01_specific_location\\0x0A70FEFC.mp3", "Mirror Park Auto Repairs", "specific_location"); } }
        public static ScannerFile VangelicoJewelryStore { get { return new ScannerFile("01_specific_location\\0x0A98BB4F.mp3", "The Vangelico Jewelry Store", "specific_location"); } }
        public static ScannerFile DavisFireDepartment { get { return new ScannerFile("01_specific_location\\0x0AC416A0.mp3", "Davis Fire Department", "specific_location"); } }
        public static ScannerFile SilverLakeRonStation2 { get { return new ScannerFile("01_specific_location\\0x0B421414.mp3", "Silver Lake Ron Station", "specific_location"); } }
        public static ScannerFile EasternHarmonyMotel { get { return new ScannerFile("01_specific_location\\0x0B4EB13E.mp3", "Eastern Harmony Hotel", "specific_location"); } }
        public static ScannerFile NooseBuilding { get { return new ScannerFile("01_specific_location\\0x0BC6790E.mp3", "The Noose Building", "specific_location"); } }
        public static ScannerFile LSRiverChannels { get { return new ScannerFile("01_specific_location\\0x0BCCFE7B.mp3", "The LS River Channels", "specific_location"); } }
        public static ScannerFile VinewoodSign { get { return new ScannerFile("01_specific_location\\0x0C57ACE0.mp3", "The Vinewood Sign", "specific_location"); } }
        public static ScannerFile StabCity { get { return new ScannerFile("01_specific_location\\0x0C5A4ECA.mp3", "Stab City", "specific_location"); } }
        public static ScannerFile VinewoodRonStation1 { get { return new ScannerFile("01_specific_location\\0x0CC13082.mp3", "Vinewood Ron Station", "specific_location"); } }
        public static ScannerFile SouthLSHandsCarWash { get { return new ScannerFile("01_specific_location\\0x0CC361AF.mp3", "South Los Santos Hand Car Wash", "specific_location"); } }
        public static ScannerFile KhalafiaBridge { get { return new ScannerFile("01_specific_location\\0x0CCADD03.mp3", "The Khalafia Bridge", "specific_location"); } }
        public static ScannerFile VanillaUnicorn { get { return new ScannerFile("01_specific_location\\0x0D1B649D.mp3", "The Vanilla Unicorn", "specific_location"); } }
        public static ScannerFile LosSantosGunClub { get { return new ScannerFile("01_specific_location\\0x0D40D5A4.mp3", "The Los Santos Gun Club", "specific_location"); } }
        public static ScannerFile DavisRonStation { get { return new ScannerFile("01_specific_location\\0x0D6F777B.mp3", "Davis Ron Station", "specific_location"); } }
        public static ScannerFile CluckingBellFactory { get { return new ScannerFile("01_specific_location\\0x0D8D06A1.mp3", "The Clucking Bell Factory", "specific_location"); } }
        public static ScannerFile SurvivalistCamp { get { return new ScannerFile("01_specific_location\\0x0D956322.mp3", "Survivalist Camp", "specific_location"); } }
        public static ScannerFile LosSantosDrainageChannel { get { return new ScannerFile("01_specific_location\\0x0D99B50F.mp3", "The Los Santos Drainage Channel", "specific_location"); } }
        public static ScannerFile SouthLSRingOfFire2 { get { return new ScannerFile("01_specific_location\\0x0DA81BFE.mp3", "South LS Ring of Fire", "specific_location"); } }
        public static ScannerFile VespucciPier { get { return new ScannerFile("01_specific_location\\0x0DAF6020.mp3", "Vespucci Pier", "specific_location"); } }
        public static ScannerFile RichardsMajesticStudios { get { return new ScannerFile("01_specific_location\\0x0DB18443.mp3", "The Richards Majestic Studios", "specific_location"); } }
        public static ScannerFile DelPerroLadiStore { get { return new ScannerFile("01_specific_location\\0x0DE50E66.mp3", "The Del Perro Ladi Store", "specific_location"); } }
        public static ScannerFile RockfordHillsCountryClub { get { return new ScannerFile("01_specific_location\\0x0E1F32BB.mp3", "Rockford Hills Country Club", "specific_location"); } }
        public static ScannerFile PaletoBaySheriffStation { get { return new ScannerFile("01_specific_location\\0x0E94FE38.mp3", "Paleto Bay Sheriff Station", "specific_location"); } }
        public static ScannerFile ChilliadLogginCamp { get { return new ScannerFile("01_specific_location\\0x0EE35330.mp3", "The Chilliad Logging Camp", "specific_location"); } }
        public static ScannerFile ZancudoRiverAmmunation { get { return new ScannerFile("01_specific_location\\0x0F7D8050.mp3", "Zancudo River Ammunation", "specific_location"); } }
        public static ScannerFile GlassHerosAutoRepair { get { return new ScannerFile("01_specific_location\\0x105B95C3.mp3", "Glass Heros Auto Repair", "specific_location"); } }
        public static ScannerFile SandyShoresTractorRepair { get { return new ScannerFile("01_specific_location\\0x10E16467.mp3", "Sandy Shores Tractor Repair", "specific_location"); } }
        public static ScannerFile LandActReservoir { get { return new ScannerFile("01_specific_location\\0x111BE082.mp3", "The Land Act Reservoir", "specific_location"); } }
        public static ScannerFile PaletoBayDelta { get { return new ScannerFile("01_specific_location\\0x111BF88B.mp3", "The Paleto Bay Delta", "specific_location"); } }
        public static ScannerFile Vinewoodracetrack { get { return new ScannerFile("01_specific_location\\0x11358D45.mp3", "Vinewood Racetrack", "specific_location"); } }
        public static ScannerFile EastSenoraPowerStation { get { return new ScannerFile("01_specific_location\\0x1139507A.mp3", "East Senora Power Station", "specific_location"); } }
        public static ScannerFile MirrorParkCatedral { get { return new ScannerFile("01_specific_location\\0x1190C8A4.mp3", "Mirror Park Cathedral", "specific_location"); } }
        public static ScannerFile SouthLSRingOfFire { get { return new ScannerFile("01_specific_location\\0x11CCE448.mp3", "South LS Ring of Fire", "specific_location"); } }
        public static ScannerFile HumaneLabsAndResearch { get { return new ScannerFile("01_specific_location\\0x11F08287.mp3", "Humane Labs and Research", "specific_location"); } }
        public static ScannerFile CarsonSelfStorageSenoraFreeway { get { return new ScannerFile("01_specific_location\\0x120B0B74.mp3", "Carson Self Storage off Senora Freeway", "specific_location"); } }
        public static ScannerFile DowntownVinewoodBlazingTattoo { get { return new ScannerFile("01_specific_location\\0x1223E5D3.mp3", "Downtown Vinewood Blazing Tattoo", "specific_location"); } }
        public static ScannerFile PDXShowroom { get { return new ScannerFile("01_specific_location\\0x122B5EFF.mp3", "The Premium Deluxe Showroom", "specific_location"); } }
        public static ScannerFile SanAadreasStateOffice { get { return new ScannerFile("01_specific_location\\0x124A359B.mp3", "San Andreas State Office", "specific_location"); } }
        public static ScannerFile RedwoodStdium2 { get { return new ScannerFile("01_specific_location\\0x126496AC.mp3", "Redwood Stadium", "specific_location"); } }
        public static ScannerFile ZancudoRiver2 { get { return new ScannerFile("01_specific_location\\0x128B95B2.mp3", "ZancudoRIver", "specific_location"); } }
        public static ScannerFile RedwoodLightsTrack { get { return new ScannerFile("01_specific_location\\0x12C1F74A.mp3", "Redwood Lights Track", "specific_location"); } }
        public static ScannerFile RockfordHillsSubway { get { return new ScannerFile("01_specific_location\\0x1337CFB1.mp3", "Rockford Hills Subway", "specific_location"); } }
        public static ScannerFile DavisHospital { get { return new ScannerFile("01_specific_location\\0x13583D6F.mp3", "Davis Hospital", "specific_location"); } }
        public static ScannerFile BeaconTheater { get { return new ScannerFile("01_specific_location\\0x13A5966F.mp3", "The Beacon Theater", "specific_location"); } }
        public static ScannerFile LorenzosGasStation { get { return new ScannerFile("01_specific_location\\0x13B9D9F7.mp3", "Lorenzos Gas Station", "specific_location"); } }
        public static ScannerFile VespucciBeachPoliceStation { get { return new ScannerFile("01_specific_location\\0x13CBAB64.mp3", "Vespucci Beach Police Station", "specific_location"); } }
        public static ScannerFile SchlongbergSachsTower { get { return new ScannerFile("01_specific_location\\0x141154C0.mp3", "The Schlongberg Sachs Tower", "specific_location"); } }
        public static ScannerFile BobMulletSalon { get { return new ScannerFile("01_specific_location\\0x143EDDDF.mp3", "Bob Mullet Salon", "specific_location"); } }
        public static ScannerFile KRPRadioStation { get { return new ScannerFile("01_specific_location\\0x1457D3BB.mp3", "The KRP Radio Station", "specific_location"); } }
        public static ScannerFile AnimalArkPetStore { get { return new ScannerFile("01_specific_location\\0x147855FA.mp3", "Animal Ark Pet Store", "specific_location"); } }
        public static ScannerFile DepOfWaterAndPower { get { return new ScannerFile("01_specific_location\\0x14A1C730.mp3", "The Department of Water and Power", "specific_location"); } }
        public static ScannerFile LittleSeoulLuckyPlucker { get { return new ScannerFile("01_specific_location\\0x14B8A4DB.mp3", "Little Seoul Lucky Plucker", "specific_location"); } }
        public static ScannerFile VespucciBurgerShot { get { return new ScannerFile("01_specific_location\\0x14C89994.mp3", "Vesucci Burger Shot", "specific_location"); } }
        public static ScannerFile LittleSeoulRonStation1 { get { return new ScannerFile("01_specific_location\\0x14C9D45F.mp3", "Little Seoul Ron Station", "specific_location"); } }
        public static ScannerFile CarsonSelfStorageStrawberry { get { return new ScannerFile("01_specific_location\\0x14F358CA.mp3", "Carson Self-Storage in Strawberry", "specific_location"); } }
        public static ScannerFile LagoZancudoCauseway2 { get { return new ScannerFile("01_specific_location\\0x150D4A67.mp3", "Lago Zancudo Causeway", "specific_location"); } }
        public static ScannerFile VespucciWigwam { get { return new ScannerFile("01_specific_location\\0x15151AB5.mp3", "Vespucci Wig-Wam Burger", "specific_location"); } }
        public static ScannerFile KRP69BroadcastStation { get { return new ScannerFile("01_specific_location\\0x1549EDC8.mp3", "KRP-69 Broadcast Station", "specific_location"); } }
        public static ScannerFile ZelenskySupplyWarehouse { get { return new ScannerFile("01_specific_location\\0x159C20B3.mp3", "Zelensky Supply Warehouse", "specific_location"); } }
        public static ScannerFile HarmonyMotel { get { return new ScannerFile("01_specific_location\\0x159DC557.mp3", "Harmony Motel", "specific_location"); } }
        public static ScannerFile KortzCenter { get { return new ScannerFile("01_specific_location\\0x15AD6A1C.mp3", "The Kortz Center", "specific_location"); } }
        public static ScannerFile SouthVinewoodMovieLot { get { return new ScannerFile("01_specific_location\\0x15B15683.mp3", "South Vinewood Movie Lot", "specific_location"); } }
        public static ScannerFile DopplerTheater { get { return new ScannerFile("01_specific_location\\0x15D35E76.mp3", "The Doppler Theater", "specific_location"); } }
        public static ScannerFile AlamoSea { get { return new ScannerFile("01_specific_location\\0x15D4147E.mp3", "The Alamo Sea", "specific_location"); } }
        public static ScannerFile DavisRonStation2 { get { return new ScannerFile("01_specific_location\\0x1639890D.mp3", "Davis Ron Station", "specific_location"); } }
        public static ScannerFile MorningwoodRonStation2 { get { return new ScannerFile("01_specific_location\\0x165792C7.mp3", "Morningwood Ron Station", "specific_location"); } }
        public static ScannerFile SandersMotorcycles { get { return new ScannerFile("01_specific_location\\0x16677E71.mp3", "Sanders Motorcycles", "specific_location"); } }
        public static ScannerFile FIBTower { get { return new ScannerFile("01_specific_location\\0x1667D63F.mp3", "FIB Tower", "specific_location"); } }
        public static ScannerFile LaFuentaBlancaRanch { get { return new ScannerFile("01_specific_location\\0x166818B8.mp3", "La Fluente Blanca Ranch", "specific_location"); } }
        public static ScannerFile NOOSE { get { return new ScannerFile("01_specific_location\\0x1677E89E.mp3", "National Office of Security Enforcement", "specific_location"); } }
        public static ScannerFile BlaineCountySavingsBank { get { return new ScannerFile("01_specific_location\\0x168085D1.mp3", "Blaine County Savings Bank", "specific_location"); } }
        public static ScannerFile CentalLaMesaRonStation { get { return new ScannerFile("01_specific_location\\0x16AAEFAC.mp3", "Central La Mesa Ron Station", "specific_location"); } }
        public static ScannerFile LittleSeoulBeanMachine { get { return new ScannerFile("01_specific_location\\0x16C620C3.mp3", "Little Seoul Bean Machine", "specific_location"); } }
        public static ScannerFile VinewoodSubUrban { get { return new ScannerFile("01_specific_location\\0x16F87D3A.mp3", "Vinewood Branch of Suburban", "specific_location"); } }
        public static ScannerFile RockfordPlaza { get { return new ScannerFile("01_specific_location\\0x17AE5C6D.mp3", "Rockford Plaza", "specific_location"); } }
        public static ScannerFile CNTBuilding { get { return new ScannerFile("01_specific_location\\0x17E65770.mp3", "The CNT Building", "specific_location"); } }
        public static ScannerFile SilentProbeMountain { get { return new ScannerFile("01_specific_location\\0x18508E93.mp3", "Silent Probe Mountain", "specific_location"); } }
        public static ScannerFile LSXFuelStorageArea { get { return new ScannerFile("01_specific_location\\0x1878923B.mp3", "LSX Fuel Storage Area", "specific_location"); } }
        public static ScannerFile MotocrossTrack { get { return new ScannerFile("01_specific_location\\0x189ED18A.mp3", "Motocross Track", "specific_location"); } }
        public static ScannerFile HillValleyChurch { get { return new ScannerFile("01_specific_location\\0x18C4124F.mp3", "Hill Valley Church", "specific_location"); } }
        public static ScannerFile SenoraFreewayXero { get { return new ScannerFile("01_specific_location\\0x18C6F152.mp3", "Senora Freeway Xero Station", "specific_location"); } }
        public static ScannerFile SouthLaMesaRonStation { get { return new ScannerFile("01_specific_location\\0x18EA44DE.mp3", "South La Mesa Ron Station", "specific_location"); } }
        public static ScannerFile TikiLaLa { get { return new ScannerFile("01_specific_location\\0x1907E32D.mp3", "Tiki La-La", "specific_location"); } }
        public static ScannerFile LittleSeoulSnrBuns { get { return new ScannerFile("01_specific_location\\0x19532EA2.mp3", "Little Seoul Snr Buns", "specific_location"); } }
        public static ScannerFile SouthLSHandsOnCarWash { get { return new ScannerFile("01_specific_location\\0x19797B25.mp3", "South LS Hands on Car-Wash", "specific_location"); } }
        public static ScannerFile HumaneLabsFacility2 { get { return new ScannerFile("01_specific_location\\0x197FDA82.mp3", "The Humane Labs Facility", "specific_location"); } }
        public static ScannerFile LittleTeapot { get { return new ScannerFile("01_specific_location\\0x1980DD57.mp3", "The Little Teapot", "specific_location"); } }
        public static ScannerFile SandyShoresAirstrip { get { return new ScannerFile("01_specific_location\\0x1983B0D4.mp3", "Sandy Shores Airstrip", "specific_location"); } }
        public static ScannerFile MtChilliadSummit { get { return new ScannerFile("01_specific_location\\0x19924D41.mp3", "The Summit of Mt Chilliad", "specific_location"); } }
        public static ScannerFile HarmonyDollarPillsPharmacy { get { return new ScannerFile("01_specific_location\\0x19E069DE.mp3", "Harmony Dollar Pills Pharmacy", "specific_location"); } }
        public static ScannerFile ChumashMall { get { return new ScannerFile("01_specific_location\\0x19E4D5BD.mp3", "ChumashMall", "specific_location"); } }
        public static ScannerFile LiquorAce { get { return new ScannerFile("01_specific_location\\0x1A23351D.mp3", "The Liquor Ace", "specific_location"); } }
        public static ScannerFile StonerCementWorks { get { return new ScannerFile("01_specific_location\\0x1A2E04DF.mp3", "Stoner Cement Works", "specific_location"); } }
        public static ScannerFile MazeBankOfLS { get { return new ScannerFile("01_specific_location\\0x1A3F7860.mp3", "The Maze Bank of LS", "specific_location"); } }
        public static ScannerFile EugenicsIncLab { get { return new ScannerFile("01_specific_location\\0x1A67316D.mp3", "The Eugenics Inc. Lab", "specific_location"); } }
        public static ScannerFile UnionGrainsSilos { get { return new ScannerFile("01_specific_location\\0x1A91C6DE.mp3", "The Union Grains Silos", "specific_location"); } }
        public static ScannerFile RedwoodLightsMotocross { get { return new ScannerFile("01_specific_location\\0x1A94B384.mp3", "The Redwood Lights Motocross Track", "specific_location"); } }
        public static ScannerFile RedwoodLightsStadium { get { return new ScannerFile("01_specific_location\\0x1AB17532.mp3", "The Redwood Lights Stadium", "specific_location"); } }
        public static ScannerFile SouthLSATMDiscountStore { get { return new ScannerFile("01_specific_location\\0x1AB60F0D.mp3", "South LS ATM Discount Store", "specific_location"); } }
        public static ScannerFile SouthHoKoreanNoodleHouse { get { return new ScannerFile("01_specific_location\\0x1ABB2DE0.mp3", "South Ho Korean Noodle House", "specific_location"); } }
        public static ScannerFile TheLSGunClub { get { return new ScannerFile("01_specific_location\\0x1AF37109.mp3", "The LS Gun Club", "specific_location"); } }
        public static ScannerFile PacificBluffsXeroStation { get { return new ScannerFile("01_specific_location\\0x1AFC8E72.mp3", "The Pacific Bluffs Xero Station", "specific_location"); } }
        public static ScannerFile DelPerroNewSakiRestaurant1 { get { return new ScannerFile("01_specific_location\\0x1B133696.mp3", "The Del Perro New Saki Restaurant", "specific_location"); } }
        public static ScannerFile YellowJackBar { get { return new ScannerFile("01_specific_location\\0x1B1BCF62.mp3", "The Yellow Jack Bar", "specific_location"); } }
        public static ScannerFile SanChianskiMountains { get { return new ScannerFile("01_specific_location\\0x1B2852E9.mp3", "The San Chiaski Mountains", "specific_location"); } }
        public static ScannerFile SplitSides { get { return new ScannerFile("01_specific_location\\0x1B3FE498.mp3", "Split Sides", "specific_location"); } }
        public static ScannerFile ElGordoLighthouse { get { return new ScannerFile("01_specific_location\\0x1B7B1F49.mp3", "The El Gordo Lighthouse", "specific_location"); } }
        public static ScannerFile PaletoBayGasStation { get { return new ScannerFile("01_specific_location\\0x1B81EF89.mp3", "Paleto Bay Gas Station", "specific_location"); } }
        public static ScannerFile VinewoodBankOfLS { get { return new ScannerFile("01_specific_location\\0x1BB48F43.mp3", "The Vinewood Bank of Los Santos", "specific_location"); } }
        public static ScannerFile MillersFishingVillage { get { return new ScannerFile("01_specific_location\\0x1BC1EA80.mp3", "Millers Fishing Village", "specific_location"); } }
        public static ScannerFile PalmerTaylorPower { get { return new ScannerFile("01_specific_location\\0x1C5D1678.mp3", "The Palmer-Taylor Power Station", "specific_location"); } }
        public static ScannerFile LandActDam { get { return new ScannerFile("01_specific_location\\0x1C674794.mp3", "The Land Act Dam", "specific_location"); } }
        public static ScannerFile CassidyCreek { get { return new ScannerFile("01_specific_location\\0x1CD25A01.mp3", "Cassidy Creek", "specific_location"); } }
        public static ScannerFile TheCluckingBellFactory { get { return new ScannerFile("01_specific_location\\0x1D2407D2.mp3", "The Clucking Bell Factory", "specific_location"); } }
        public static ScannerFile RichmanGlofCourse { get { return new ScannerFile("01_specific_location\\0x1D532F53.mp3", "Richman Golf Course", "specific_location"); } }
        public static ScannerFile AltaConstructionSite { get { return new ScannerFile("01_specific_location\\0x1D6A83F9.mp3", "The Construction Site in Alta", "specific_location"); } }
        public static ScannerFile GrapeseedStorageFacility { get { return new ScannerFile("01_specific_location\\0x1DA6BA84.mp3", "Grapeseed Storage Facility", "specific_location"); } }
        public static ScannerFile HerrKutzBarberShop { get { return new ScannerFile("01_specific_location\\0x1DB64CA3.mp3", "Herr Kutz Barber Shop", "specific_location"); } }
        public static ScannerFile LSXCustomAutos { get { return new ScannerFile("01_specific_location\\0x1DE8D28D.mp3", "LSX Custom Autos", "specific_location"); } }
        public static ScannerFile GalileoParkObservatory { get { return new ScannerFile("01_specific_location\\0x1DEC0BDE.mp3", "Galileo Park Observatory", "specific_location"); } }
        public static ScannerFile LosSantosRecyclingCenter { get { return new ScannerFile("01_specific_location\\0x1DF81DFF.mp3", "Los Santos Recycling Center", "specific_location"); } }
        public static ScannerFile OneilFarm { get { return new ScannerFile("01_specific_location\\0x1E2AE79B.mp3", "The ONeil Farm", "specific_location"); } }
        public static ScannerFile LittleSeoulMuseum { get { return new ScannerFile("01_specific_location\\0x1E74A249.mp3", "The Little Seoul Museum", "specific_location"); } }
        public static ScannerFile WeazelPlaza { get { return new ScannerFile("01_specific_location\\0x1E998193.mp3", "Weazel Plaza", "specific_location"); } }
        public static ScannerFile DorsetDrivePillPharmacy { get { return new ScannerFile("01_specific_location\\0x1F07D876.mp3", "Dorset Drive Pill Pharmacy", "specific_location"); } }
        public static ScannerFile MirrorParkPoliceStation { get { return new ScannerFile("01_specific_location\\0x1F0E27B7.mp3", "Mirror Park Police Station", "specific_location"); } }
        public static ScannerFile HumaneLabsFacility { get { return new ScannerFile("01_specific_location\\0x1FB449F8.mp3", "The Humane Labs Facility", "specific_location"); } }
    }
    //public class stand_down
    //{
    //    public static ScannerFile Code4 { get { return new ScannerFile("01_stand_down\\0x05C0A263.mp3", "0x05C0A263", "stand_down"); } }
    //    public static ScannerFile StandDownReturnToPatrol { get { return new ScannerFile("01_stand_down\\0x0A396B54.mp3", "0x0A396B54", "stand_down"); } }
    //    public static ScannerFile AllUnitsCode4 { get { return new ScannerFile("01_stand_down\\0x1120B929.mp3", "0x1120B929", "stand_down"); } }
    //    public static ScannerFile AllUnitsStandDown { get { return new ScannerFile("01_stand_down\\0x187347C8.mp3", "0x187347C8", "stand_down"); } }
    //    public static ScannerFile ReturnToPatrol { get { return new ScannerFile("01_stand_down\\0x18CE0883.mp3", "0x18CE0883", "stand_down"); } }
    //    public static ScannerFile ReturnToPatrol1 { get { return new ScannerFile("01_stand_down\\0x195C899A.mp3", "0x195C899A", "stand_down"); } }
    //    public static ScannerFile ReturnToPatrol2 { get { return new ScannerFile("01_stand_down\\0x1F379557.mp3", "0x1F379557", "stand_down"); } }
    //}
    public class status_message
    {
        public static ScannerFile HASH01B72847 { get { return new ScannerFile("01_status_message\\0x01B72847.mp3", "0x01B72847", "status_message"); } }
        public static ScannerFile CarryingSmallArms { get { return new ScannerFile("01_status_message\\0x01E7B2E2.mp3", "Carrying small arms", "status_message"); } }
        public static ScannerFile HASH02E79882 { get { return new ScannerFile("01_status_message\\0x02E79882.mp3", "0x02E79882", "status_message"); } }
        public static ScannerFile HASH04904F02 { get { return new ScannerFile("01_status_message\\0x04904F02.mp3", "0x04904F02", "status_message"); } }
        public static ScannerFile HASH04F26EBD { get { return new ScannerFile("01_status_message\\0x04F26EBD.mp3", "0x04F26EBD", "status_message"); } }
        public static ScannerFile HASH0717B309 { get { return new ScannerFile("01_status_message\\0x0717B309.mp3", "0x0717B309", "status_message"); } }
        public static ScannerFile ArmedWithExplosives { get { return new ScannerFile("01_status_message\\0x0A14A6DC.mp3", "Armed with Explosives", "status_message"); } }
        public static ScannerFile ExtremelyAgitated { get { return new ScannerFile("01_status_message\\0x0A3658CA.mp3", "Extremely Agitated", "status_message"); } }
        public static ScannerFile FleeingTheSceneOfTheCrime { get { return new ScannerFile("01_status_message\\0x0B291B46.mp3", "Fleeing the scene of the crime", "status_message"); } }
        public static ScannerFile ApparentlyWounded { get { return new ScannerFile("01_status_message\\0x0C00BCDC.mp3", "Apparently Wounded", "status_message"); } }
        public static ScannerFile HASH0C5A6D4D { get { return new ScannerFile("01_status_message\\0x0C5A6D4D.mp3", "0x0C5A6D4D", "status_message"); } }
        public static ScannerFile HASH0DDD2FA0 { get { return new ScannerFile("01_status_message\\0x0DDD2FA0.mp3", "0x0DDD2FA0", "status_message"); } }
        public static ScannerFile HeavilyArmedAndDangerous { get { return new ScannerFile("01_status_message\\0x0E412264.mp3", "Heavily armed and dangerous", "status_message"); } }
        public static ScannerFile HASH0FAD644B { get { return new ScannerFile("01_status_message\\0x0FAD644B.mp3", "0x0FAD644B", "status_message"); } }
        public static ScannerFile HASH11C92887 { get { return new ScannerFile("01_status_message\\0x11C92887.mp3", "0x11C92887", "status_message"); } }
        public static ScannerFile HASH11CEF782 { get { return new ScannerFile("01_status_message\\0x11CEF782.mp3", "0x11CEF782", "status_message"); } }
        public static ScannerFile HASH12EEEBBF { get { return new ScannerFile("01_status_message\\0x12EEEBBF.mp3", "0x12EEEBBF", "status_message"); } }
        public static ScannerFile HASH1325155D { get { return new ScannerFile("01_status_message\\0x1325155D.mp3", "0x1325155D", "status_message"); } }
        public static ScannerFile ArmedWithAssaultWeapon { get { return new ScannerFile("01_status_message\\0x13F6EE1F.mp3", "Armed with assault weapon", "status_message"); } }
        public static ScannerFile HASH14078CE8 { get { return new ScannerFile("01_status_message\\0x14078CE8.mp3", "0x14078CE8", "status_message"); } }
        public static ScannerFile HASH16997FE5 { get { return new ScannerFile("01_status_message\\0x16997FE5.mp3", "0x16997FE5", "status_message"); } }
        public static ScannerFile HASH16BAF1D4 { get { return new ScannerFile("01_status_message\\0x16BAF1D4.mp3", "0x16BAF1D4", "status_message"); } }
        public static ScannerFile HASH1704B3DA { get { return new ScannerFile("01_status_message\\0x1704B3DA.mp3", "0x1704B3DA", "status_message"); } }
        public static ScannerFile HeavilyArmed { get { return new ScannerFile("01_status_message\\0x1A13548C.mp3", "Heavily armed", "status_message"); } }
        public static ScannerFile HASH1AA2C9DE { get { return new ScannerFile("01_status_message\\0x1AA2C9DE.mp3", "0x1AA2C9DE", "status_message"); } }
        public static ScannerFile HASH1ABEDA57 { get { return new ScannerFile("01_status_message\\0x1ABEDA57.mp3", "0x1ABEDA57", "status_message"); } }
        public static ScannerFile HASH1BF83C4F { get { return new ScannerFile("01_status_message\\0x1BF83C4F.mp3", "0x1BF83C4F", "status_message"); } }
        public static ScannerFile ArmedWithRocketLauncher { get { return new ScannerFile("01_status_message\\0x1D60077B.mp3", "Armed with rocket launcher", "status_message"); } }
        public static ScannerFile HASH1D77FFE3 { get { return new ScannerFile("01_status_message\\0x1D77FFE3.mp3", "0x1D77FFE3", "status_message"); } }
        public static ScannerFile HASH1DDE80AE { get { return new ScannerFile("01_status_message\\0x1DDE80AE.mp3", "0x1DDE80AE", "status_message"); } }
        public static ScannerFile ArmedAndDangerous { get { return new ScannerFile("01_status_message\\0x1E0B81F9.mp3", "Armed and dangerous", "status_message"); } }
        public static ScannerFile HASH1FFCD3D4 { get { return new ScannerFile("01_status_message\\0x1FFCD3D4.mp3", "0x1FFCD3D4", "status_message"); } }
    }
    public class streets
    {
        public static ScannerFile LindenDrive { get { return new ScannerFile("01_streets\\0x0001B096.mp3", "0x0001B096", "streets"); } }
        public static ScannerFile LakeVinewoodEstate { get { return new ScannerFile("01_streets\\0x0049AED0.mp3", "0x0049AED0", "streets"); } }
        public static ScannerFile SeaviewRd { get { return new ScannerFile("01_streets\\0x00BFEAA6.mp3", "SeaviewRd", "streets"); } }
        public static ScannerFile IntergrityWy { get { return new ScannerFile("01_streets\\0x00C4CB28.mp3", "IntergrityWy", "streets"); } }
        public static ScannerFile HawickAve { get { return new ScannerFile("01_streets\\0x00D1F515.mp3", "HawickAve", "streets"); } }
        public static ScannerFile LakeVineWoodDrive { get { return new ScannerFile("01_streets\\0x00EB9A86.mp3", "LakeVineWoodDrive", "streets"); } }
        public static ScannerFile DorsetPlace { get { return new ScannerFile("01_streets\\0x0102C67D.mp3", "0x0102C67D", "streets"); } }
        public static ScannerFile HollywoodBlvd { get { return new ScannerFile("01_streets\\0x0103ABE0.mp3", "0x0103ABE0", "streets"); } }
        public static ScannerFile MorningwoodBlvd { get { return new ScannerFile("01_streets\\0x010F58DC.mp3", "0x010F58DC", "streets"); } }
        public static ScannerFile EastGalileoAve { get { return new ScannerFile("01_streets\\0x0123B12E.mp3", "0x0123B12E", "streets"); } }
        public static ScannerFile BlaverPlace { get { return new ScannerFile("01_streets\\0x0136F8BE.mp3", "0x0136F8BE", "streets"); } }
        public static ScannerFile NorthElRanchoBlvd { get { return new ScannerFile("01_streets\\0x01406583.mp3", "0x01406583", "streets"); } }
        public static ScannerFile EastMirrorDrive { get { return new ScannerFile("01_streets\\0x0149BC83.mp3", "0x0149BC83", "streets"); } }
        public static ScannerFile NorthBlvdDelPerro { get { return new ScannerFile("01_streets\\0x016ACF1D.mp3", "0x016ACF1D", "streets"); } }
        public static ScannerFile LittleBighornAve { get { return new ScannerFile("01_streets\\0x016E5EB8.mp3", "0x016E5EB8", "streets"); } }
        public static ScannerFile SouthSeasideAve { get { return new ScannerFile("01_streets\\0x019EDBDE.mp3", "0x019EDBDE", "streets"); } }
        public static ScannerFile ElGouhaStreet { get { return new ScannerFile("01_streets\\0x01B1ECA2.mp3", "0x01B1ECA2", "streets"); } }
        public static ScannerFile RichmondStreet { get { return new ScannerFile("01_streets\\0x01C6754A.mp3", "0x01C6754A", "streets"); } }
        public static ScannerFile InventionCourt { get { return new ScannerFile("01_streets\\0x01C7D19F.mp3", "0x01C7D19F", "streets"); } }
        public static ScannerFile MarathonAve { get { return new ScannerFile("01_streets\\0x020EADF0.mp3", "0x020EADF0", "streets"); } }
        public static ScannerFile ConquistadorBlvd { get { return new ScannerFile("01_streets\\0x0214731C.mp3", "0x0214731C", "streets"); } }
        public static ScannerFile MiriamTurnerOverpass { get { return new ScannerFile("01_streets\\0x021A099C.mp3", "0x021A099C", "streets"); } }
        public static ScannerFile Route68 { get { return new ScannerFile("01_streets\\0x021CAA3D.mp3", "0x021CAA3D", "streets"); } }
        public static ScannerFile PlayaVista { get { return new ScannerFile("01_streets\\0x022520F8.mp3", "0x022520F8", "streets"); } }
        public static ScannerFile LowPowerStreet { get { return new ScannerFile("01_streets\\0x0240EC46.mp3", "0x0240EC46", "streets"); } }
        public static ScannerFile SelmaAve { get { return new ScannerFile("01_streets\\0x026AE70A.mp3", "0x026AE70A", "streets"); } }
        public static ScannerFile DelPierroFreeway { get { return new ScannerFile("01_streets\\0x0284E3F3.mp3", "0x0284E3F3", "streets"); } }
        public static ScannerFile ProperityStreetPromenade { get { return new ScannerFile("01_streets\\0x0285B168.mp3", "0x0285B168", "streets"); } }
        public static ScannerFile PowerStreet { get { return new ScannerFile("01_streets\\0x0299BFF3.mp3", "0x0299BFF3", "streets"); } }
        public static ScannerFile CanneryStreet { get { return new ScannerFile("01_streets\\0x02E19C74.mp3", "0x02E19C74", "streets"); } }
        public static ScannerFile NorthSycamoreAve { get { return new ScannerFile("01_streets\\0x02E1EA9E.mp3", "0x02E1EA9E", "streets"); } }
        public static ScannerFile SouthShambleStreet { get { return new ScannerFile("01_streets\\0x033297CE.mp3", "0x033297CE", "streets"); } }
        public static ScannerFile MutineeRoad { get { return new ScannerFile("01_streets\\0x033FD7E7.mp3", "0x033FD7E7", "streets"); } }
        public static ScannerFile MirangeLane { get { return new ScannerFile("01_streets\\0x034E8F44.mp3", "0x034E8F44", "streets"); } }
        public static ScannerFile StrawberryAve { get { return new ScannerFile("01_streets\\0x03582630.mp3", "0x03582630", "streets"); } }
        public static ScannerFile OrchidvilleAve { get { return new ScannerFile("01_streets\\0x037B7DEE.mp3", "0x037B7DEE", "streets"); } }
        public static ScannerFile ZancudoBaranca { get { return new ScannerFile("01_streets\\0x03C08D92.mp3", "0x03C08D92", "streets"); } }
        public static ScannerFile HeritageWay { get { return new ScannerFile("01_streets\\0x03C75F8B.mp3", "0x03C75F8B", "streets"); } }
        public static ScannerFile BergAve { get { return new ScannerFile("01_streets\\0x03CE8FB7.mp3", "0x03CE8FB7", "streets"); } }
        public static ScannerFile BacklotBlvd { get { return new ScannerFile("01_streets\\0x03CF126F.mp3", "0x03CF126F", "streets"); } }
        public static ScannerFile JilledLane { get { return new ScannerFile("01_streets\\0x03DE370F.mp3", "0x03DE370F", "streets"); } }
        public static ScannerFile NormandyDrive { get { return new ScannerFile("01_streets\\0x03E746F6.mp3", "0x03E746F6", "streets"); } }
        public static ScannerFile DorsetDrive { get { return new ScannerFile("01_streets\\0x03E8C91A.mp3", "0x03E8C91A", "streets"); } }
        public static ScannerFile MiltonRoad { get { return new ScannerFile("01_streets\\0x043E9B50.mp3", "0x043E9B50", "streets"); } }
        public static ScannerFile EnecinoRoad { get { return new ScannerFile("01_streets\\0x04421BC2.mp3", "0x04421BC2", "streets"); } }
        public static ScannerFile PackersAve { get { return new ScannerFile("01_streets\\0x04BBC5F4.mp3", "0x04BBC5F4", "streets"); } }
        public static ScannerFile CoxWay { get { return new ScannerFile("01_streets\\0x04F36858.mp3", "0x04F36858", "streets"); } }
        public static ScannerFile StrangeWaysDrive { get { return new ScannerFile("01_streets\\0x04F7F00A.mp3", "0x04F7F00A", "streets"); } }
        public static ScannerFile AlterStreet { get { return new ScannerFile("01_streets\\0x05000FA8.mp3", "0x05000FA8", "streets"); } }
        public static ScannerFile OccupationAve { get { return new ScannerFile("01_streets\\0x050B6755.mp3", "0x050B6755", "streets"); } }
        public static ScannerFile PopularStreet { get { return new ScannerFile("01_streets\\0x050C9979.mp3", "0x050C9979", "streets"); } }
        public static ScannerFile LesbosLane { get { return new ScannerFile("01_streets\\0x0512495B.mp3", "0x0512495B", "streets"); } }
        public static ScannerFile LibertyStreet { get { return new ScannerFile("01_streets\\0x057D565E.mp3", "0x057D565E", "streets"); } }
        public static ScannerFile LasLegunasBlvd { get { return new ScannerFile("01_streets\\0x059B01E6.mp3", "0x059B01E6", "streets"); } }
        public static ScannerFile AmarilloWay { get { return new ScannerFile("01_streets\\0x05C48E2D.mp3", "0x05C48E2D", "streets"); } }
        public static ScannerFile HangmanAve { get { return new ScannerFile("01_streets\\0x05E9C1D2.mp3", "0x05E9C1D2", "streets"); } }
        public static ScannerFile ElginAve { get { return new ScannerFile("01_streets\\0x05ED135D.mp3", "0x05ED135D", "streets"); } }
        public static ScannerFile LaMoineStreet { get { return new ScannerFile("01_streets\\0x05EEED49.mp3", "0x05EEED49", "streets"); } }
        public static ScannerFile FortZancudoApproachRoad { get { return new ScannerFile("01_streets\\0x05F099C8.mp3", "0x05F099C8", "streets"); } }
        public static ScannerFile UnionStreet { get { return new ScannerFile("01_streets\\0x05FFB99E.mp3", "0x05FFB99E", "streets"); } }
        public static ScannerFile MtHaanRoad { get { return new ScannerFile("01_streets\\0x060B40EB.mp3", "0x060B40EB", "streets"); } }
        public static ScannerFile MtHaanDrive { get { return new ScannerFile("01_streets\\0x06170A98.mp3", "0x06170A98", "streets"); } }
        public static ScannerFile BlvdDelPierro { get { return new ScannerFile("01_streets\\0x062B3516.mp3", "0x062B3516", "streets"); } }
        public static ScannerFile ZancudoRoad { get { return new ScannerFile("01_streets\\0x0632CC3F.mp3", "0x0632CC3F", "streets"); } }
        public static ScannerFile SignalStreet { get { return new ScannerFile("01_streets\\0x06428985.mp3", "0x06428985", "streets"); } }
        public static ScannerFile CourtBIDK { get { return new ScannerFile("01_streets\\0x064A93B1.mp3", "0x064A93B1", "streets"); } }
        public static ScannerFile AceJonesDrive { get { return new ScannerFile("01_streets\\0x064C6BCB.mp3", "0x064C6BCB", "streets"); } }
        public static ScannerFile ShankStreet { get { return new ScannerFile("01_streets\\0x06895863.mp3", "0x06895863", "streets"); } }
        public static ScannerFile NeelanAve { get { return new ScannerFile("01_streets\\0x068A7299.mp3", "0x068A7299", "streets"); } }
        public static ScannerFile NorthRockfordDrive { get { return new ScannerFile("01_streets\\0x06992D16.mp3", "0x06992D16", "streets"); } }
        public static ScannerFile CarsonAve { get { return new ScannerFile("01_streets\\0x06C26E31.mp3", "0x06C26E31", "streets"); } }
        public static ScannerFile RodeoDrive { get { return new ScannerFile("01_streets\\0x06C7F383.mp3", "0x06C7F383", "streets"); } }
        public static ScannerFile GomezStreet { get { return new ScannerFile("01_streets\\0x06F4E179.mp3", "0x06F4E179", "streets"); } }
        public static ScannerFile DarrianAve { get { return new ScannerFile("01_streets\\0x071521F6.mp3", "0x071521F6", "streets"); } }
        public static ScannerFile GrapseedMainStreet { get { return new ScannerFile("01_streets\\0x071EC39F.mp3", "0x071EC39F", "streets"); } }
        public static ScannerFile NorthConkerAve { get { return new ScannerFile("01_streets\\0x072750C7.mp3", "0x072750C7", "streets"); } }
        public static ScannerFile FenwellPlace { get { return new ScannerFile("01_streets\\0x0759F387.mp3", "0x0759F387", "streets"); } }
        public static ScannerFile WestSilverlakeDrive { get { return new ScannerFile("01_streets\\0x075AB3CD.mp3", "0x075AB3CD", "streets"); } }
        public static ScannerFile ZancudoAve { get { return new ScannerFile("01_streets\\0x07829707.mp3", "0x07829707", "streets"); } }
        public static ScannerFile SanVitusBlvd { get { return new ScannerFile("01_streets\\0x07933135.mp3", "SanVitusBlvd", "streets"); } }
        public static ScannerFile RubStreet { get { return new ScannerFile("01_streets\\0x07B5988A.mp3", "0x07B5988A", "streets"); } }
        public static ScannerFile RunwayOne { get { return new ScannerFile("01_streets\\0x07F71C56.mp3", "0x07F71C56", "streets"); } }
        public static ScannerFile ExceptionalistWay { get { return new ScannerFile("01_streets\\0x07FC1AAD.mp3", "0x07FC1AAD", "streets"); } }
        public static ScannerFile KortzDrive { get { return new ScannerFile("01_streets\\0x07FCFC45.mp3", "0x07FCFC45", "streets"); } }
        public static ScannerFile ZancudoGrandeValley { get { return new ScannerFile("01_streets\\0x08095013.mp3", "0x08095013", "streets"); } }
        public static ScannerFile DunstableDrive { get { return new ScannerFile("01_streets\\0x083F0542.mp3", "0x083F0542", "streets"); } }
        public static ScannerFile NorgowerStreet { get { return new ScannerFile("01_streets\\0x08409C07.mp3", "0x08409C07", "streets"); } }
        public static ScannerFile ProcopioDrive { get { return new ScannerFile("01_streets\\0x0853209F.mp3", "0x0853209F", "streets"); } }
        public static ScannerFile BearStreet { get { return new ScannerFile("01_streets\\0x08D99127.mp3", "0x08D99127", "streets"); } }
        public static ScannerFile RockfordDrive { get { return new ScannerFile("01_streets\\0x08D9E251.mp3", "0x08D9E251", "streets"); } }
        public static ScannerFile LindsayCircus { get { return new ScannerFile("01_streets\\0x08DE189A.mp3", "0x08DE189A", "streets"); } }
        public static ScannerFile ElysianFieldsFreeway { get { return new ScannerFile("01_streets\\0x08E78CF6.mp3", "0x08E78CF6", "streets"); } }
        public static ScannerFile MontanaAve { get { return new ScannerFile("01_streets\\0x08F4CA53.mp3", "0x08F4CA53", "streets"); } }
        public static ScannerFile ElBurroBlvd { get { return new ScannerFile("01_streets\\0x090A8DDF.mp3", "0x090A8DDF", "streets"); } }
        public static ScannerFile NorthLaCienega { get { return new ScannerFile("01_streets\\0x09231D7B.mp3", "0x09231D7B", "streets"); } }
        public static ScannerFile BridgeStreet { get { return new ScannerFile("01_streets\\0x0947E0A1.mp3", "0x0947E0A1", "streets"); } }
        public static ScannerFile CortezAve { get { return new ScannerFile("01_streets\\0x097B1644.mp3", "0x097B1644", "streets"); } }
        public static ScannerFile NorthOrangeDrive { get { return new ScannerFile("01_streets\\0x098045CE.mp3", "0x098045CE", "streets"); } }
        public static ScannerFile ForumDrive { get { return new ScannerFile("01_streets\\0x09B22349.mp3", "0x09B22349", "streets"); } }
        public static ScannerFile RoyLowensteinBlvd { get { return new ScannerFile("01_streets\\0x0A1242A7.mp3", "0x0A1242A7", "streets"); } }
        public static ScannerFile FantasticPlace { get { return new ScannerFile("01_streets\\0x0A359C18.mp3", "0x0A359C18", "streets"); } }
        public static ScannerFile EastbourneWay { get { return new ScannerFile("01_streets\\0x0A4F62AD.mp3", "EastborneWay", "streets"); } }
        public static ScannerFile CourtBIDK2 { get { return new ScannerFile("01_streets\\0x0A709BFF.mp3", "0x0A709BFF", "streets"); } }
        public static ScannerFile NorthLaCienegaBlvd { get { return new ScannerFile("01_streets\\0x0A776023.mp3", "0x0A776023", "streets"); } }
        public static ScannerFile AmarilloVista { get { return new ScannerFile("01_streets\\0x0A7B310C.mp3", "AmarilloVista", "streets"); } }
        public static ScannerFile FringeDrive { get { return new ScannerFile("01_streets\\0x0AC29BE5.mp3", "0x0AC29BE5", "streets"); } }
        public static ScannerFile ForceLaborPlace { get { return new ScannerFile("01_streets\\0x0B148304.mp3", "0x0B148304", "streets"); } }
        public static ScannerFile OlympicFreeway { get { return new ScannerFile("01_streets\\0x0B292FF2.mp3", "0x0B292FF2", "streets"); } }
        public static ScannerFile BanhamCanyon { get { return new ScannerFile("01_streets\\0x0B43DD81.mp3", "0x0B43DD81", "streets"); } }
        public static ScannerFile NorthwiltonPlace { get { return new ScannerFile("01_streets\\0x0B4B1A02.mp3", "0x0B4B1A02", "streets"); } }
        public static ScannerFile TowerWay { get { return new ScannerFile("01_streets\\0x0B991BCF.mp3", "0x0B991BCF", "streets"); } }
        public static ScannerFile NopeStreet { get { return new ScannerFile("01_streets\\0x0BA78BC5.mp3", "0x0BA78BC5", "streets"); } }
        public static ScannerFile SustanciaRoad { get { return new ScannerFile("01_streets\\0x0BA90F34.mp3", "0x0BA90F34", "streets"); } }
        public static ScannerFile LagunaPlace { get { return new ScannerFile("01_streets\\0x0BCD8ABB.mp3", "0x0BCD8ABB", "streets"); } }
        public static ScannerFile FreemarketStreet { get { return new ScannerFile("01_streets\\0x0BCF25BE.mp3", "0x0BCF25BE", "streets"); } }
        public static ScannerFile ElectricAve { get { return new ScannerFile("01_streets\\0x0BDF5759.mp3", "0x0BDF5759", "streets"); } }
        public static ScannerFile AvatorAve { get { return new ScannerFile("01_streets\\0x0BF59F04.mp3", "0x0BF59F04", "streets"); } }
        public static ScannerFile ArgyleAve { get { return new ScannerFile("01_streets\\0x0C064C7C.mp3", "0x0C064C7C", "streets"); } }
        public static ScannerFile CapitalBlvd { get { return new ScannerFile("01_streets\\0x0C2D5617.mp3", "0x0C2D5617", "streets"); } }
        public static ScannerFile PalmwoodDrive { get { return new ScannerFile("01_streets\\0x0C536506.mp3", "0x0C536506", "streets"); } }
        public static ScannerFile GingerStreet { get { return new ScannerFile("01_streets\\0x0C8D24B5.mp3", "0x0C8D24B5", "streets"); } }
        public static ScannerFile UnionRoad { get { return new ScannerFile("01_streets\\0x0CE0CCEF.mp3", "0x0CE0CCEF", "streets"); } }
        public static ScannerFile WestEclipseBlvd { get { return new ScannerFile("01_streets\\0x0D10195A.mp3", "0x0D10195A", "streets"); } }
        public static ScannerFile EclipseBlvd { get { return new ScannerFile("01_streets\\0x0D1F9564.mp3", "0x0D1F9564", "streets"); } }
        public static ScannerFile DutchLantonStreet { get { return new ScannerFile("01_streets\\0x0D232ACD.mp3", "0x0D232ACD", "streets"); } }
        public static ScannerFile AltaPlace { get { return new ScannerFile("01_streets\\0x0D2643A4.mp3", "0x0D2643A4", "streets"); } }
        public static ScannerFile VineDrive { get { return new ScannerFile("01_streets\\0x0D340899.mp3", "0x0D340899", "streets"); } }
        public static ScannerFile CortezStreet { get { return new ScannerFile("01_streets\\0x0D34C14E.mp3", "0x0D34C14E", "streets"); } }
        public static ScannerFile BanhamCanyonDrive { get { return new ScannerFile("01_streets\\0x0D558DA4.mp3", "0x0D558DA4", "streets"); } }
        public static ScannerFile ImaginationCourt { get { return new ScannerFile("01_streets\\0x0D559440.mp3", "0x0D559440", "streets"); } }
        public static ScannerFile HeartyWay { get { return new ScannerFile("01_streets\\0x0D68C123.mp3", "0x0D68C123", "streets"); } }
        public static ScannerFile TeslaAve { get { return new ScannerFile("01_streets\\0x0DA66615.mp3", "0x0DA66615", "streets"); } }
        public static ScannerFile SinnerStreet { get { return new ScannerFile("01_streets\\0x0DB7ED5A.mp3", "0x0DB7ED5A", "streets"); } }
        public static ScannerFile PaliminoFreeway { get { return new ScannerFile("01_streets\\0x0DDB1753.mp3", "0x0DDB1753", "streets"); } }
        public static ScannerFile GroveStreet { get { return new ScannerFile("01_streets\\0x0E14D472.mp3", "0x0E14D472", "streets"); } }
        public static ScannerFile CatClawAve { get { return new ScannerFile("01_streets\\0x0E36940E.mp3", "0x0E36940E", "streets"); } }
        public static ScannerFile SignalPlace { get { return new ScannerFile("01_streets\\0x0E4A65EE.mp3", "0x0E4A65EE", "streets"); } }
        public static ScannerFile NicolaAve { get { return new ScannerFile("01_streets\\0x0E8C9E9E.mp3", "0x0E8C9E9E", "streets"); } }
        public static ScannerFile SeeviewRoad { get { return new ScannerFile("01_streets\\0x0ED2C6CC.mp3", "0x0ED2C6CC", "streets"); } }
        public static ScannerFile PicturePerfectWay { get { return new ScannerFile("01_streets\\0x0EF82A15.mp3", "0x0EF82A15", "streets"); } }
        public static ScannerFile SouthChollaSpringsAve { get { return new ScannerFile("01_streets\\0x0F186293.mp3", "0x0F186293", "streets"); } }
        public static ScannerFile GallileoRoad { get { return new ScannerFile("01_streets\\0x0F31A105.mp3", "0x0F31A105", "streets"); } }
        public static ScannerFile DunstableLane { get { return new ScannerFile("01_streets\\0x0F6F2841.mp3", "0x0F6F2841", "streets"); } }
        public static ScannerFile ApplinWay { get { return new ScannerFile("01_streets\\0x0F9320D2.mp3", "0x0F9320D2", "streets"); } }
        public static ScannerFile MelanomaStreet { get { return new ScannerFile("01_streets\\0x0FE3AADE.mp3", "0x0FE3AADE", "streets"); } }
        public static ScannerFile DutchLondonStreet { get { return new ScannerFile("01_streets\\0x100B2FFA.mp3", "0x100B2FFA", "streets"); } }
        public static ScannerFile VitasStreet { get { return new ScannerFile("01_streets\\0x102CDEDE.mp3", "0x102CDEDE", "streets"); } }
        public static ScannerFile MelroseAve { get { return new ScannerFile("01_streets\\0x103A9F18.mp3", "0x103A9F18", "streets"); } }
        public static ScannerFile InnocenceBlvd { get { return new ScannerFile("01_streets\\0x103C12F0.mp3", "0x103C12F0", "streets"); } }
        public static ScannerFile AtleyStreet { get { return new ScannerFile("01_streets\\0x104D6E7E.mp3", "0x104D6E7E", "streets"); } }
        public static ScannerFile SouthPacificAve { get { return new ScannerFile("01_streets\\0x105CD3F7.mp3", "0x105CD3F7", "streets"); } }
        public static ScannerFile PicturePerfectDrive { get { return new ScannerFile("01_streets\\0x1075F96B.mp3", "0x1075F96B", "streets"); } }
        public static ScannerFile DutchThompsonStreet { get { return new ScannerFile("01_streets\\0x1097503F.mp3", "0x1097503F", "streets"); } }
        public static ScannerFile AdamsAppleBlvd { get { return new ScannerFile("01_streets\\0x109F69A2.mp3", "0x109F69A2", "streets"); } }
        public static ScannerFile EdwardWay { get { return new ScannerFile("01_streets\\0x10CF0302.mp3", "0x10CF0302", "streets"); } }
        public static ScannerFile ChollaRoad { get { return new ScannerFile("01_streets\\0x10D7E34B.mp3", "0x10D7E34B", "streets"); } }
        public static ScannerFile UtopiaGardens { get { return new ScannerFile("01_streets\\0x10E079B6.mp3", "0x10E079B6", "streets"); } }
        public static ScannerFile CarcerWay { get { return new ScannerFile("01_streets\\0x10E8FF7B.mp3", "0x10E8FF7B", "streets"); } }
        public static ScannerFile PeacefulStreet { get { return new ScannerFile("01_streets\\0x10F2DD3E.mp3", "0x10F2DD3E", "streets"); } }
        public static ScannerFile AmericanoWay { get { return new ScannerFile("01_streets\\0x1101B476.mp3", "0x1101B476", "streets"); } }
        public static ScannerFile PyriteAve { get { return new ScannerFile("01_streets\\0x11059B10.mp3", "0x11059B10", "streets"); } }
        public static ScannerFile ArgyleAve2 { get { return new ScannerFile("01_streets\\0x11089681.mp3", "0x11089681", "streets"); } }
        public static ScannerFile HawickAve2 { get { return new ScannerFile("01_streets\\0x11212529.mp3", "0x11212529", "streets"); } }
        public static ScannerFile TangerineStreet { get { return new ScannerFile("01_streets\\0x112CCCA7.mp3", "0x112CCCA7", "streets"); } }
        public static ScannerFile PortolaDrive { get { return new ScannerFile("01_streets\\0x1137CBEA.mp3", "0x1137CBEA", "streets"); } }
        public static ScannerFile WispyMoundDrive { get { return new ScannerFile("01_streets\\0x1181A1F7.mp3", "0x1181A1F7", "streets"); } }
        public static ScannerFile WildOatsDrive { get { return new ScannerFile("01_streets\\0x11A03703.mp3", "0x11A03703", "streets"); } }
        public static ScannerFile GrunnichPlace { get { return new ScannerFile("01_streets\\0x11D24FED.mp3", "0x11D24FED", "streets"); } }
        public static ScannerFile CockandGinDrive { get { return new ScannerFile("01_streets\\0x11FC3B6D.mp3", "0x11FC3B6D", "streets"); } }
        public static ScannerFile SardineStreet { get { return new ScannerFile("01_streets\\0x1206C213.mp3", "0x1206C213", "streets"); } }
        public static ScannerFile ClintonAve { get { return new ScannerFile("01_streets\\0x120AA4AF.mp3", "0x120AA4AF", "streets"); } }
        public static ScannerFile CalapiaRoad { get { return new ScannerFile("01_streets\\0x126D3515.mp3", "0x126D3515", "streets"); } }
        public static ScannerFile CourtA { get { return new ScannerFile("01_streets\\0x12853681.mp3", "0x12853681", "streets"); } }
        public static ScannerFile GloryWay { get { return new ScannerFile("01_streets\\0x12A0D4E0.mp3", "0x12A0D4E0", "streets"); } }
        public static ScannerFile SonoraRoad { get { return new ScannerFile("01_streets\\0x12A17392.mp3", "0x12A17392", "streets"); } }
        public static ScannerFile NorthArcherAve { get { return new ScannerFile("01_streets\\0x12D34D96.mp3", "0x12D34D96", "streets"); } }
        public static ScannerFile EqualityWay { get { return new ScannerFile("01_streets\\0x132C0BF1.mp3", "0x132C0BF1", "streets"); } }
        public static ScannerFile ElRanchoBlvd { get { return new ScannerFile("01_streets\\0x132CC4F5.mp3", "0x132CC4F5", "streets"); } }
        public static ScannerFile SouthRockfordDrive { get { return new ScannerFile("01_streets\\0x133D8310.mp3", "0x133D8310", "streets"); } }
        public static ScannerFile MorningwoodBlvd2 { get { return new ScannerFile("01_streets\\0x135DBD79.mp3", "0x135DBD79", "streets"); } }
        public static ScannerFile SouthMoMiltonDrive { get { return new ScannerFile("01_streets\\0x13B44AA4.mp3", "0x13B44AA4", "streets"); } }
        public static ScannerFile MovieStarWay { get { return new ScannerFile("01_streets\\0x13D8BDBC.mp3", "0x13D8BDBC", "streets"); } }
        public static ScannerFile DelouasAve { get { return new ScannerFile("01_streets\\0x13E17105.mp3", "0x13E17105", "streets"); } }
        public static ScannerFile JoshuaRoad { get { return new ScannerFile("01_streets\\0x140CA80D.mp3", "0x140CA80D", "streets"); } }
        public static ScannerFile HillcrestAve { get { return new ScannerFile("01_streets\\0x1435B4D1.mp3", "0x1435B4D1", "streets"); } }
        public static ScannerFile ChumStreet { get { return new ScannerFile("01_streets\\0x143A5D42.mp3", "0x143A5D42", "streets"); } }
        public static ScannerFile PalaminoAve { get { return new ScannerFile("01_streets\\0x144E6DB1.mp3", "0x144E6DB1", "streets"); } }
        public static ScannerFile EmperialBlvd { get { return new ScannerFile("01_streets\\0x147A5B07.mp3", "0x147A5B07", "streets"); } }
        public static ScannerFile SouthArsenalStreet { get { return new ScannerFile("01_streets\\0x14AA8C14.mp3", "0x14AA8C14", "streets"); } }
        public static ScannerFile NowhereRoad { get { return new ScannerFile("01_streets\\0x14BD713A.mp3", "0x14BD713A", "streets"); } }
        public static ScannerFile VineStreet { get { return new ScannerFile("01_streets\\0x14CD7C43.mp3", "0x14CD7C43", "streets"); } }
        public static ScannerFile DellAve { get { return new ScannerFile("01_streets\\0x14D34F55.mp3", "0x14D34F55", "streets"); } }
        public static ScannerFile CovenantAve { get { return new ScannerFile("01_streets\\0x14FE3C11.mp3", "0x14FE3C11", "streets"); } }
        public static ScannerFile NorthKalafiaWay { get { return new ScannerFile("01_streets\\0x1527D88D.mp3", "0x1527D88D", "streets"); } }
        public static ScannerFile ChollaSpringsAve { get { return new ScannerFile("01_streets\\0x1570583B.mp3", "0x1570583B", "streets"); } }
        public static ScannerFile HeritageWay2 { get { return new ScannerFile("01_streets\\0x15858309.mp3", "0x15858309", "streets"); } }
        public static ScannerFile EightMiltonParkway { get { return new ScannerFile("01_streets\\0x1587AE8A.mp3", "0x1587AE8A", "streets"); } }
        public static ScannerFile DeckerStreet { get { return new ScannerFile("01_streets\\0x15D9D369.mp3", "0x15D9D369", "streets"); } }
        public static ScannerFile MagellanAve { get { return new ScannerFile("01_streets\\0x15F419A1.mp3", "0x15F419A1", "streets"); } }
        public static ScannerFile BacklotBlvd2 { get { return new ScannerFile("01_streets\\0x15F8B6C2.mp3", "0x15F8B6C2", "streets"); } }
        public static ScannerFile MountainViewDrive { get { return new ScannerFile("01_streets\\0x164F3B7B.mp3", "0x164F3B7B", "streets"); } }
        public static ScannerFile ElHamberDrive { get { return new ScannerFile("01_streets\\0x16A7EEAB.mp3", "0x16A7EEAB", "streets"); } }
        public static ScannerFile TugStreet { get { return new ScannerFile("01_streets\\0x16BCC9F1.mp3", "0x16BCC9F1", "streets"); } }
        public static ScannerFile BarracudaStreet { get { return new ScannerFile("01_streets\\0x16D97CC9.mp3", "0x16D97CC9", "streets"); } }
        public static ScannerFile MountVinewoodDrive { get { return new ScannerFile("01_streets\\0x17410E3C.mp3", "0x17410E3C", "streets"); } }
        public static ScannerFile VinewoodBlvd { get { return new ScannerFile("01_streets\\0x1743E9A3.mp3", "0x1743E9A3", "streets"); } }
        public static ScannerFile JamestownStreet { get { return new ScannerFile("01_streets\\0x175B1386.mp3", "0x175B1386", "streets"); } }
        public static ScannerFile SouthMagoFenderDrive { get { return new ScannerFile("01_streets\\0x1783A6E2.mp3", "0x1783A6E2", "streets"); } }
        public static ScannerFile HighSpanishAve { get { return new ScannerFile("01_streets\\0x178FDF73.mp3", "0x178FDF73", "streets"); } }
        public static ScannerFile SonoraFreeway { get { return new ScannerFile("01_streets\\0x17983309.mp3", "0x17983309", "streets"); } }
        public static ScannerFile FortZancudoApproachRoad2 { get { return new ScannerFile("01_streets\\0x17AB7D3D.mp3", "0x17AB7D3D", "streets"); } }
        public static ScannerFile BoinbinoRoad { get { return new ScannerFile("01_streets\\0x17ADEA2A.mp3", "0x17ADEA2A", "streets"); } }
        public static ScannerFile YorkStreet { get { return new ScannerFile("01_streets\\0x17C66B96.mp3", "0x17C66B96", "streets"); } }
        public static ScannerFile YouingStreet { get { return new ScannerFile("01_streets\\0x17F87FDC.mp3", "0x17F87FDC", "streets"); } }
        public static ScannerFile BaseCityIncline { get { return new ScannerFile("01_streets\\0x18182B71.mp3", "0x18182B71", "streets"); } }
        public static ScannerFile MeteorStreet { get { return new ScannerFile("01_streets\\0x181A3C88.mp3", "0x181A3C88", "streets"); } }
        public static ScannerFile CrenshawBlvd { get { return new ScannerFile("01_streets\\0x181EE2FD.mp3", "0x181EE2FD", "streets"); } }
        public static ScannerFile HamstonDrive { get { return new ScannerFile("01_streets\\0x18226A66.mp3", "0x18226A66", "streets"); } }
        public static ScannerFile SouthBlvdDelPierro { get { return new ScannerFile("01_streets\\0x183EA3D8.mp3", "0x183EA3D8", "streets"); } }
        public static ScannerFile PanoramaDrive { get { return new ScannerFile("01_streets\\0x184DB6D1.mp3", "0x184DB6D1", "streets"); } }
        public static ScannerFile BaseCityAve { get { return new ScannerFile("01_streets\\0x18787617.mp3", "0x18787617", "streets"); } }
        public static ScannerFile TackleStreet { get { return new ScannerFile("01_streets\\0x18903C12.mp3", "0x18903C12", "streets"); } }
        public static ScannerFile SamAustinDrive { get { return new ScannerFile("01_streets\\0x18975F9C.mp3", "0x18975F9C", "streets"); } }
        public static ScannerFile VespucciBlvd { get { return new ScannerFile("01_streets\\0x189DF2C9.mp3", "0x189DF2C9", "streets"); } }
        public static ScannerFile ConquistadorStreet { get { return new ScannerFile("01_streets\\0x18C7869E.mp3", "0x18C7869E", "streets"); } }
        public static ScannerFile SandcastleWay { get { return new ScannerFile("01_streets\\0x18DDA36A.mp3", "0x18DDA36A", "streets"); } }
        public static ScannerFile SonoraWay { get { return new ScannerFile("01_streets\\0x18DFF9AE.mp3", "0x18DFF9AE", "streets"); } }
        public static ScannerFile PerfStreet { get { return new ScannerFile("01_streets\\0x190212E1.mp3", "0x190212E1", "streets"); } }
        public static ScannerFile LolitaAve { get { return new ScannerFile("01_streets\\0x190941AE.mp3", "0x190941AE", "streets"); } }
        public static ScannerFile MirrorParkBlvd { get { return new ScannerFile("01_streets\\0x192B2F50.mp3", "0x192B2F50", "streets"); } }
        public static ScannerFile HangarWay { get { return new ScannerFile("01_streets\\0x19300CFB.mp3", "0x19300CFB", "streets"); } }
        public static ScannerFile ElBurroBlvd2 { get { return new ScannerFile("01_streets\\0x1941E833.mp3", "0x1941E833", "streets"); } }
        public static ScannerFile BuccanierWay { get { return new ScannerFile("01_streets\\0x19553E1E.mp3", "0x19553E1E", "streets"); } }
        public static ScannerFile SupplyStreet { get { return new ScannerFile("01_streets\\0x19602650.mp3", "0x19602650", "streets"); } }
        public static ScannerFile PicturePerfectWay2 { get { return new ScannerFile("01_streets\\0x19743F10.mp3", "0x19743F10", "streets"); } }
        public static ScannerFile DavisAve { get { return new ScannerFile("01_streets\\0x1987B393.mp3", "0x1987B393", "streets"); } }
        public static ScannerFile SteelWay { get { return new ScannerFile("01_streets\\0x1987EA0F.mp3", "0x1987EA0F", "streets"); } }
        public static ScannerFile SpanishAve { get { return new ScannerFile("01_streets\\0x19B6651E.mp3", "0x19B6651E", "streets"); } }
        public static ScannerFile EastJoshuaRoad { get { return new ScannerFile("01_streets\\0x19D51F0C.mp3", "0x19D51F0C", "streets"); } }
        public static ScannerFile NorthHighlandAve { get { return new ScannerFile("01_streets\\0x19EC1BD4.mp3", "0x19EC1BD4", "streets"); } }
        public static ScannerFile MagwavevendorDrive { get { return new ScannerFile("01_streets\\0x19EEA2EB.mp3", "0x19EEA2EB", "streets"); } }
        public static ScannerFile NorthLaBreaAve { get { return new ScannerFile("01_streets\\0x19F716C1.mp3", "0x19F716C1", "streets"); } }
        public static ScannerFile TongvaDrive { get { return new ScannerFile("01_streets\\0x1A05AA29.mp3", "0x1A05AA29", "streets"); } }
        public static ScannerFile SmokeTreeRoad { get { return new ScannerFile("01_streets\\0x1A3A317D.mp3", "0x1A3A317D", "streets"); } }
        public static ScannerFile NorthMagiovendorDrive { get { return new ScannerFile("01_streets\\0x1A568E1F.mp3", "0x1A568E1F", "streets"); } }
        public static ScannerFile NewEmpireWay { get { return new ScannerFile("01_streets\\0x1A56E636.mp3", "0x1A56E636", "streets"); } }
        public static ScannerFile BarbarinoRoad { get { return new ScannerFile("01_streets\\0x1A970537.mp3", "0x1A970537", "streets"); } }
        public static ScannerFile PerinoPlace { get { return new ScannerFile("01_streets\\0x1AC3B09F.mp3", "0x1AC3B09F", "streets"); } }
        public static ScannerFile GrenwichWay { get { return new ScannerFile("01_streets\\0x1AD1A701.mp3", "0x1AD1A701", "streets"); } }
        public static ScannerFile OneilWay { get { return new ScannerFile("01_streets\\0x1AE3822B.mp3", "0x1AE3822B", "streets"); } }
        public static ScannerFile ProcopioPromenade { get { return new ScannerFile("01_streets\\0x1AEB1670.mp3", "0x1AEB1670", "streets"); } }
        public static ScannerFile JamestownStreet2 { get { return new ScannerFile("01_streets\\0x1B1C2616.mp3", "0x1B1C2616", "streets"); } }
        public static ScannerFile NorthPoplerStreet { get { return new ScannerFile("01_streets\\0x1B206290.mp3", "0x1B206290", "streets"); } }
        public static ScannerFile AltopiaParkway { get { return new ScannerFile("01_streets\\0x1B406761.mp3", "0x1B406761", "streets"); } }
        public static ScannerFile VinewoodParkDrive { get { return new ScannerFile("01_streets\\0x1B710698.mp3", "0x1B710698", "streets"); } }
        public static ScannerFile HanwellAve { get { return new ScannerFile("01_streets\\0x1B8204A1.mp3", "0x1B8204A1", "streets"); } }
        public static ScannerFile CenturyFreeway { get { return new ScannerFile("01_streets\\0x1B94A52A.mp3", "0x1B94A52A", "streets"); } }
        public static ScannerFile ArgyleAve3 { get { return new ScannerFile("01_streets\\0x1BB8EBE1.mp3", "0x1BB8EBE1", "streets"); } }
        public static ScannerFile CacobellAve { get { return new ScannerFile("01_streets\\0x1BDEB04B.mp3", "0x1BDEB04B", "streets"); } }
        public static ScannerFile NikolaPlace { get { return new ScannerFile("01_streets\\0x1BF71FD3.mp3", "0x1BF71FD3", "streets"); } }
        public static ScannerFile AmarilloWay2 { get { return new ScannerFile("01_streets\\0x1BFFBAA2.mp3", "0x1BFFBAA2", "streets"); } }
        public static ScannerFile PaletoBlvd { get { return new ScannerFile("01_streets\\0x1C078234.mp3", "0x1C078234", "streets"); } }
        public static ScannerFile WestGalileoAve { get { return new ScannerFile("01_streets\\0x1C2299E2.mp3", "0x1C2299E2", "streets"); } }
        public static ScannerFile AlgonquinBlvd { get { return new ScannerFile("01_streets\\0x1C2849B4.mp3", "0x1C2849B4", "streets"); } }
        public static ScannerFile SwissStreet { get { return new ScannerFile("01_streets\\0x1C7B9A4B.mp3", "0x1C7B9A4B", "streets"); } }
        public static ScannerFile McDonaldStreet { get { return new ScannerFile("01_streets\\0x1D075A11.mp3", "0x1D075A11", "streets"); } }
        public static ScannerFile ProsperityStreet { get { return new ScannerFile("01_streets\\0x1D12DF32.mp3", "0x1D12DF32", "streets"); } }
        public static ScannerFile DryDockStreet { get { return new ScannerFile("01_streets\\0x1D2FFD5B.mp3", "0x1D2FFD5B", "streets"); } }
        public static ScannerFile HillcrestRidgeAccessRoad { get { return new ScannerFile("01_streets\\0x1D3D5C62.mp3", "0x1D3D5C62", "streets"); } }
        public static ScannerFile EastSilverlakeDrive { get { return new ScannerFile("01_streets\\0x1D4D9646.mp3", "0x1D4D9646", "streets"); } }
        public static ScannerFile MirrorPlace { get { return new ScannerFile("01_streets\\0x1D5268E1.mp3", "0x1D5268E1", "streets"); } }
        public static ScannerFile BaytreeCanyonRoad { get { return new ScannerFile("01_streets\\0x1D5D46A1.mp3", "0x1D5D46A1", "streets"); } }
        public static ScannerFile CassidyTrail { get { return new ScannerFile("01_streets\\0x1D5F57C1.mp3", "0x1D5F57C1", "streets"); } }
        public static ScannerFile ArmadilloAve { get { return new ScannerFile("01_streets\\0x1D600A1D.mp3", "0x1D600A1D", "streets"); } }
        public static ScannerFile GrapeseedAve { get { return new ScannerFile("01_streets\\0x1D77E55F.mp3", "0x1D77E55F", "streets"); } }
        public static ScannerFile CenturyBlvd { get { return new ScannerFile("01_streets\\0x1D910EAE.mp3", "0x1D910EAE", "streets"); } }
        public static ScannerFile CrusadeRoad { get { return new ScannerFile("01_streets\\0x1DAC5255.mp3", "0x1DAC5255", "streets"); } }
        public static ScannerFile SouthChollaSpringsAve2 { get { return new ScannerFile("01_streets\\0x1DEDC03E.mp3", "0x1DEDC03E", "streets"); } }
        public static ScannerFile GrenwichParkway { get { return new ScannerFile("01_streets\\0x1DF52DF6.mp3", "0x1DF52DF6", "streets"); } }
        public static ScannerFile VincentThomasBridge { get { return new ScannerFile("01_streets\\0x1DF6B4D3.mp3", "0x1DF6B4D3", "streets"); } }
        public static ScannerFile CaliasAve { get { return new ScannerFile("01_streets\\0x1E03DBA4.mp3", "0x1E03DBA4", "streets"); } }
        public static ScannerFile NullDrive { get { return new ScannerFile("01_streets\\0x1E2AF575.mp3", "0x1E2AF575", "streets"); } }
        public static ScannerFile DiedianDrive { get { return new ScannerFile("01_streets\\0x1E2D9A08.mp3", "0x1E2D9A08", "streets"); } }
        public static ScannerFile SouthSotoStreet { get { return new ScannerFile("01_streets\\0x1E53AAE0.mp3", "0x1E53AAE0", "streets"); } }
        public static ScannerFile CapeCatfish { get { return new ScannerFile("01_streets\\0x1E55985D.mp3", "0x1E55985D", "streets"); } }
        public static ScannerFile CougarAve { get { return new ScannerFile("01_streets\\0x1E61D52C.mp3", "0x1E61D52C", "streets"); } }
        public static ScannerFile SanAndreasAve { get { return new ScannerFile("01_streets\\0x1E6AFCCC.mp3", "0x1E6AFCCC", "streets"); } }
        public static ScannerFile FudgeLane { get { return new ScannerFile("01_streets\\0x1E763D7D.mp3", "0x1E763D7D", "streets"); } }
        public static ScannerFile NorhtwesternAve { get { return new ScannerFile("01_streets\\0x1E8F5B45.mp3", "0x1E8F5B45", "streets"); } }
        public static ScannerFile RedDesertAve { get { return new ScannerFile("01_streets\\0x1EBD7733.mp3", "0x1EBD7733", "streets"); } }
        public static ScannerFile NorthSheldonAve { get { return new ScannerFile("01_streets\\0x1EC3CE23.mp3", "0x1EC3CE23", "streets"); } }
        public static ScannerFile CatfishView { get { return new ScannerFile("01_streets\\0x1EC679E1.mp3", "0x1EC679E1", "streets"); } }
        public static ScannerFile GreatOceanHighway { get { return new ScannerFile("01_streets\\0x1EE59AF9.mp3", "0x1EE59AF9", "streets"); } }
        public static ScannerFile CaesarPlace { get { return new ScannerFile("01_streets\\0x1EE8F047.mp3", "0x1EE8F047", "streets"); } }
        public static ScannerFile WestMirrorDrive { get { return new ScannerFile("01_streets\\0x1EFF682E.mp3", "0x1EFF682E", "streets"); } }
        public static ScannerFile SinnersPassage { get { return new ScannerFile("01_streets\\0x1F027A0E.mp3", "0x1F027A0E", "streets"); } }
        public static ScannerFile MarinaDrive { get { return new ScannerFile("01_streets\\0x1F053811.mp3", "0x1F053811", "streets"); } }
        public static ScannerFile KimbalHillDrive { get { return new ScannerFile("01_streets\\0x1F14CC99.mp3", "0x1F14CC99", "streets"); } }
        public static ScannerFile BraddockTunnel { get { return new ScannerFile("01_streets\\0x1F55F0A8.mp3", "0x1F55F0A8", "streets"); } }
        public static ScannerFile WorfStreet { get { return new ScannerFile("01_streets\\0x1FB2B2AA.mp3", "0x1FB2B2AA", "streets"); } }
        public static ScannerFile CockandGinDrive2 { get { return new ScannerFile("01_streets\\0x1FB496DF.mp3", "0x1FB496DF", "streets"); } }
        public static ScannerFile Skyway { get { return new ScannerFile("01_streets\\0x1FF7BB6A.mp3", "0x1FF7BB6A", "streets"); } }
        public static ScannerFile ColliseumStreet { get { return new ScannerFile("01_streets\\0x1FF7CB59.mp3", "0x1FF7CB59", "streets"); } }
    }
    //public class suspects_are
    //{
    //    public static ScannerFile HASH0262F796 { get { return new ScannerFile("01_suspects_are\\0x0262F796.mp3", "0x0262F796", "suspects_are"); } }
    //    public static ScannerFile HASH0323B926 { get { return new ScannerFile("01_suspects_are\\0x0323B926.mp3", "0x0323B926", "suspects_are"); } }
    //    public static ScannerFile HASH0DE38E9B { get { return new ScannerFile("01_suspects_are\\0x0DE38E9B.mp3", "0x0DE38E9B", "suspects_are"); } }
    //    public static ScannerFile HASH0EA45019 { get { return new ScannerFile("01_suspects_are\\0x0EA45019.mp3", "0x0EA45019", "suspects_are"); } }
    //}
    //public class suspects_are_members_of
    //{
    //    public static ScannerFile HASH05EBE717 { get { return new ScannerFile("01_suspects_are_members_of\\0x05EBE717.mp3", "0x05EBE717", "suspects_are_members_of"); } }
    //    public static ScannerFile HASH17B5CAAB { get { return new ScannerFile("01_suspects_are_members_of\\0x17B5CAAB.mp3", "0x17B5CAAB", "suspects_are_members_of"); } }
    //    public static ScannerFile HASH1A4BCF5F { get { return new ScannerFile("01_suspects_are_members_of\\0x1A4BCF5F.mp3", "0x1A4BCF5F", "suspects_are_members_of"); } }
    //}
    //public class suspects_heading
    //{
    //    public static ScannerFile HASH00F4821D { get { return new ScannerFile("01_suspects_heading\\0x00F4821D.mp3", "0x00F4821D", "suspects_heading"); } }
    //    public static ScannerFile HASH0389C747 { get { return new ScannerFile("01_suspects_heading\\0x0389C747.mp3", "0x0389C747", "suspects_heading"); } }
    //    public static ScannerFile HASH13312696 { get { return new ScannerFile("01_suspects_heading\\0x13312696.mp3", "0x13312696", "suspects_heading"); } }
    //    public static ScannerFile HASH15CAEBC9 { get { return new ScannerFile("01_suspects_heading\\0x15CAEBC9.mp3", "0x15CAEBC9", "suspects_heading"); } }
    //    public static ScannerFile HASH1A56B4E0 { get { return new ScannerFile("01_suspects_heading\\0x1A56B4E0.mp3", "0x1A56B4E0", "suspects_heading"); } }
    //}
    //public class suspects_last_seen
    //{
    //    public static ScannerFile SuspectLastSeen { get { return new ScannerFile("01_suspects_last_seen\\0x02637742.mp3", "0x02637742", "suspects_last_seen"); } }
    //    public static ScannerFile HASH04E93C4D { get { return new ScannerFile("01_suspects_last_seen\\0x04E93C4D.mp3", "0x04E93C4D", "suspects_last_seen"); } }
    //    public static ScannerFile HASH0BCB0A12 { get { return new ScannerFile("01_suspects_last_seen\\0x0BCB0A12.mp3", "0x0BCB0A12", "suspects_last_seen"); } }
    //    public static ScannerFile HASH1D712D60 { get { return new ScannerFile("01_suspects_last_seen\\0x1D712D60.mp3", "0x1D712D60", "suspects_last_seen"); } }
    //}
    //public class suspect_arrested
    //{
    //    public static ScannerFile SuspectIncustody { get { return new ScannerFile("01_suspect_arrested\\0x0C51EC8C.mp3", "Suspect in custody", "suspect_arrested"); } }
    //    public static ScannerFile SuspectApprehended { get { return new ScannerFile("01_suspect_arrested\\0x1627003A.mp3", "Suspect Aprehended", "suspect_arrested"); } }
    //    public static ScannerFile SuspectIsTenFifteen { get { return new ScannerFile("01_suspect_arrested\\0x1A944911.mp3", "Suspect is 10-15", "suspect_arrested"); } }
    //    public static ScannerFile TenFifteenSuspectInCustody { get { return new ScannerFile("01_suspect_arrested\\0x1EC51175.mp3", "10-15 Suspect in Custody", "suspect_arrested"); } }
    //}
    public class suspect_eluded_pt_1
    {
        public static ScannerFile SuspectLost { get { return new ScannerFile("01_suspect_eluded_pt_1\\0x036E44E1.mp3", "Suspect Lost", "suspect_eluded_pt_1"); } }
        public static ScannerFile SuspectHasEvadedOfficers { get { return new ScannerFile("01_suspect_eluded_pt_1\\0x105E9EC1.mp3", "Suspect Has Evaded Officers", "suspect_eluded_pt_1"); } }
        public static ScannerFile SuspectEvadedPursuingOfficiers { get { return new ScannerFile("01_suspect_eluded_pt_1\\0x15A02945.mp3", "Suspect Evaded Pursuing Officiers", "suspect_eluded_pt_1"); } }
        public static ScannerFile OfficiersHaveLostVisualOnSuspect { get { return new ScannerFile("01_suspect_eluded_pt_1\\0x1FD43DAC.mp3", "Officiers Have Lost Visual on Suspect", "suspect_eluded_pt_1"); } }
    }
    public class suspect_eluded_pt_2
    {
        public static ScannerFile AllUnitsStayInTheArea { get { return new ScannerFile("01_suspect_eluded_pt_2\\0x05A6E31C.mp3", "All Units stay in the area", "suspect_eluded_pt_2"); } }
        public static ScannerFile AllUnitsRemainOnAlert { get { return new ScannerFile("01_suspect_eluded_pt_2\\0x145D808B.mp3", "All Units Remain on alert", "suspect_eluded_pt_2"); } }
        public static ScannerFile AllUnitsStandby { get { return new ScannerFile("01_suspect_eluded_pt_2\\0x1EBB5543.mp3", "All Units Standby", "suspect_eluded_pt_2"); } }
    }
    //public class suspect_has
    //{
    //    public static ScannerFile HASH004D3F60 { get { return new ScannerFile("01_suspect_has\\0x004D3F60.mp3", "0x004D3F60", "suspect_has"); } }
    //    public static ScannerFile HASH0E6C9B9F { get { return new ScannerFile("01_suspect_has\\0x0E6C9B9F.mp3", "0x0E6C9B9F", "suspect_has"); } }
    //    public static ScannerFile HASH13626589 { get { return new ScannerFile("01_suspect_has\\0x13626589.mp3", "0x13626589", "suspect_has"); } }
    //}
    public class suspect_heading
    {
        public static ScannerFile SuspectHeading { get { return new ScannerFile("01_suspect_heading\\0x04AE12BC.mp3", "Suspect heading", "suspect_heading"); } }
        public static ScannerFile TargetSeenHeading { get { return new ScannerFile("01_suspect_heading\\0x0DA624A7.mp3", "Target seen heading", "suspect_heading"); } }
        public static ScannerFile TargetLastSeenHeading { get { return new ScannerFile("01_suspect_heading\\0x1200ED5C.mp3", "Target last seen heading", "suspect_heading"); } }
        public static ScannerFile TargetHeading { get { return new ScannerFile("01_suspect_heading\\0x1AD27F02.mp3", "Target Heading", "suspect_heading"); } }
        public static ScannerFile TargetSpottedHeading { get { return new ScannerFile("01_suspect_heading\\0x1CD3C302.mp3", "Target spotted heading", "suspect_heading"); } }
        public static ScannerFile TargetReportedHeading { get { return new ScannerFile("01_suspect_heading\\0x1F668829.mp3", "Target reported heading", "suspect_heading"); } }
    }
    public class suspect_is
    {
        public static ScannerFile SuspectIs { get { return new ScannerFile("01_suspect_is\\0x09AB3AEA.mp3", "SuspectIs", "suspect_is"); } }
        public static ScannerFile CriminalIs { get { return new ScannerFile("01_suspect_is\\0x0F630663.mp3", "CriminalIs", "suspect_is"); } }
        public static ScannerFile TargetIs { get { return new ScannerFile("01_suspect_is\\0x19A5DADF.mp3", "TargetIs", "suspect_is"); } }
    }
    //public class suspect_is_a_member_of
    //{
    //    public static ScannerFile HASH0789E155 { get { return new ScannerFile("01_suspect_is_a_member_of\\0x0789E155.mp3", "0x0789E155", "suspect_is_a_member_of"); } }
    //    public static ScannerFile HASH14D37BED { get { return new ScannerFile("01_suspect_is_a_member_of\\0x14D37BED.mp3", "0x14D37BED", "suspect_is_a_member_of"); } }
    //    public static ScannerFile HASH184F02E0 { get { return new ScannerFile("01_suspect_is_a_member_of\\0x184F02E0.mp3", "0x184F02E0", "suspect_is_a_member_of"); } }
    //}
    //public class suspect_is_wearing
    //{
    //    public static ScannerFile HASH04A18D33 { get { return new ScannerFile("01_suspect_is_wearing\\0x04A18D33.mp3", "0x04A18D33", "suspect_is_wearing"); } }
    //    public static ScannerFile HASH0AE599BA { get { return new ScannerFile("01_suspect_is_wearing\\0x0AE599BA.mp3", "0x0AE599BA", "suspect_is_wearing"); } }
    //    public static ScannerFile HASH12E369B6 { get { return new ScannerFile("01_suspect_is_wearing\\0x12E369B6.mp3", "0x12E369B6", "suspect_is_wearing"); } }
    //    public static ScannerFile HASH1CA43D37 { get { return new ScannerFile("01_suspect_is_wearing\\0x1CA43D37.mp3", "0x1CA43D37", "suspect_is_wearing"); } }
    //}
    public class suspect_last_seen
    {
        public static ScannerFile TargetLastReported { get { return new ScannerFile("01_suspect_last_seen\\0x021E1830.mp3", "TargetLastReported", "suspect_last_seen"); } }
        public static ScannerFile TargetSpotted { get { return new ScannerFile("01_suspect_last_seen\\0x09C86781.mp3", "TargetSpotted", "suspect_last_seen"); } }
        public static ScannerFile SuspectSpotted { get { return new ScannerFile("01_suspect_last_seen\\0x0D84AEFA.mp3", "SuspectSpotted", "suspect_last_seen"); } }
        public static ScannerFile TargetLastSeen { get { return new ScannerFile("01_suspect_last_seen\\0x110375FA.mp3", "TargetLastSeen", "suspect_last_seen"); } }
        public static ScannerFile TargetIs { get { return new ScannerFile("01_suspect_last_seen\\0x17A6C33E.mp3", "TargetIs", "suspect_last_seen"); } }
    }
    public class suspect_license_plate
    {
        public static ScannerFile TargetLicensePlate { get { return new ScannerFile("01_suspect_license_plate\\0x02F918C0.mp3", "0x02F918C0", "target license plate"); } }
        public static ScannerFile SuspectsLicensePlate01 { get { return new ScannerFile("01_suspect_license_plate\\0x0C436B59.mp3", "0x0C436B59", "suspects license plate"); } }
        public static ScannerFile SuspectLicensePlate { get { return new ScannerFile("01_suspect_license_plate\\0x123C7746.mp3", "0x123C7746", "suspects license plate"); } }
        public static ScannerFile TargetsLicensePlate { get { return new ScannerFile("01_suspect_license_plate\\0x15A1BE11.mp3", "0x15A1BE11", "targets license plate"); } }
        public static ScannerFile TargetVehicleLicensePlate { get { return new ScannerFile("01_suspect_license_plate\\0x17AB4229.mp3", "0x17AB4229", "target vehicle license plate"); } }
        public static ScannerFile SuspectsLicensePlate02 { get { return new ScannerFile("01_suspect_license_plate\\0x1E8D8FEE.mp3", "Suspects Licens ePlate", "suspects license plate"); } }
    }
    //public class suspect_wasted
    //{
    //    public static ScannerFile HASH018C67CD { get { return new ScannerFile("01_suspect_wasted\\0x018C67CD.mp3", "0x018C67CD", "suspect_wasted"); } }
    //    public static ScannerFile HASH0A0FB8D4 { get { return new ScannerFile("01_suspect_wasted\\0x0A0FB8D4.mp3", "0x0A0FB8D4", "suspect_wasted"); } }
    //    public static ScannerFile HASH129A89EB { get { return new ScannerFile("01_suspect_wasted\\0x129A89EB.mp3", "0x129A89EB", "suspect_wasted"); } }
    //    public static ScannerFile HASH1BEBDC93 { get { return new ScannerFile("01_suspect_wasted\\0x1BEBDC93.mp3", "0x1BEBDC93", "suspect_wasted"); } }
    //}
    //public class tattoos
    //{
    //    public static ScannerFile HASH005473A0 { get { return new ScannerFile("01_tattoos\\0x005473A0.mp3", "0x005473A0", "tattoos"); } }
    //    public static ScannerFile HASH05A8B900 { get { return new ScannerFile("01_tattoos\\0x05A8B900.mp3", "0x05A8B900", "tattoos"); } }
    //    public static ScannerFile HASH06AB8D05 { get { return new ScannerFile("01_tattoos\\0x06AB8D05.mp3", "0x06AB8D05", "tattoos"); } }
    //    public static ScannerFile HASH0B67567C { get { return new ScannerFile("01_tattoos\\0x0B67567C.mp3", "0x0B67567C", "tattoos"); } }
    //    public static ScannerFile HASH102C7332 { get { return new ScannerFile("01_tattoos\\0x102C7332.mp3", "0x102C7332", "tattoos"); } }
    //    public static ScannerFile HASH1989F2C1 { get { return new ScannerFile("01_tattoos\\0x1989F2C1.mp3", "0x1989F2C1", "tattoos"); } }
    //    public static ScannerFile HASH1A23673D { get { return new ScannerFile("01_tattoos\\0x1A23673D.mp3", "0x1A23673D", "tattoos"); } }
    //    public static ScannerFile HASH1D95AE22 { get { return new ScannerFile("01_tattoos\\0x1D95AE22.mp3", "0x1D95AE22", "tattoos"); } }
    //    public static ScannerFile HASH1F2CD12F { get { return new ScannerFile("01_tattoos\\0x1F2CD12F.mp3", "0x1F2CD12F", "tattoos"); } }
    //}
    //public class unit_responding_code
    //{
    //    public static ScannerFile HASH0236BDBA { get { return new ScannerFile("01_unit_responding_code\\0x0236BDBA.mp3", "0x0236BDBA", "unit_responding_code"); } }
    //    public static ScannerFile HASH04910270 { get { return new ScannerFile("01_unit_responding_code\\0x04910270.mp3", "0x04910270", "unit_responding_code"); } }
    //    public static ScannerFile HASH0A904DB3 { get { return new ScannerFile("01_unit_responding_code\\0x0A904DB3.mp3", "0x0A904DB3", "unit_responding_code"); } }
    //    public static ScannerFile HASH0E77EBB2 { get { return new ScannerFile("01_unit_responding_code\\0x0E77EBB2.mp3", "0x0E77EBB2", "unit_responding_code"); } }
    //    public static ScannerFile HASH0F0F2CE4 { get { return new ScannerFile("01_unit_responding_code\\0x0F0F2CE4.mp3", "0x0F0F2CE4", "unit_responding_code"); } }
    //    public static ScannerFile HASH10165979 { get { return new ScannerFile("01_unit_responding_code\\0x10165979.mp3", "0x10165979", "unit_responding_code"); } }
    //    public static ScannerFile HASH10F970B8 { get { return new ScannerFile("01_unit_responding_code\\0x10F970B8.mp3", "0x10F970B8", "unit_responding_code"); } }
    //    public static ScannerFile HASH16CD66E7 { get { return new ScannerFile("01_unit_responding_code\\0x16CD66E7.mp3", "0x16CD66E7", "unit_responding_code"); } }
    //}
    public class vehicle_category
    {
        public static ScannerFile ATV { get { return new ScannerFile("01_vehicle_category\\0x005D43A0.mp3", "0x005D43A0", "vehicle_category"); } }
        public static ScannerFile APC01 { get { return new ScannerFile("01_vehicle_category\\0x0110CF57.mp3", "0x0110CF57", "vehicle_category"); } }
        public static ScannerFile Train01 { get { return new ScannerFile("01_vehicle_category\\0x01426427.mp3", "Train", "vehicle_category"); } }
        public static ScannerFile SpinVehicle { get { return new ScannerFile("01_vehicle_category\\0x014D3B35.mp3", "0x014D3B35", "vehicle_category"); } }
        public static ScannerFile Bicycle01 { get { return new ScannerFile("01_vehicle_category\\0x01C22EAC.mp3", "Bicycle", "vehicle_category"); } }
        public static ScannerFile Boat01 { get { return new ScannerFile("01_vehicle_category\\0x01D004AB.mp3", "Boat", "vehicle_category"); } }
        public static ScannerFile StationWagon { get { return new ScannerFile("01_vehicle_category\\0x0216A584.mp3", "0x0216A584", "vehicle_category"); } }
        public static ScannerFile APC02 { get { return new ScannerFile("01_vehicle_category\\0x0251C064.mp3", "0x0251C064", "vehicle_category"); } }
        public static ScannerFile SemiTruck { get { return new ScannerFile("01_vehicle_category\\0x02917E7A.mp3", "0x02917E7A", "vehicle_category"); } }
        public static ScannerFile Motorcycle01 { get { return new ScannerFile("01_vehicle_category\\0x02B37E94.mp3", "Motorcycle", "vehicle_category"); } }
        public static ScannerFile HASH031106D2 { get { return new ScannerFile("01_vehicle_category\\0x031106D2.mp3", "0x031106D2", "vehicle_category"); } }
        public static ScannerFile Hearse { get { return new ScannerFile("01_vehicle_category\\0x0384A11A.mp3", "0x0384A11A", "vehicle_category"); } }
        public static ScannerFile ConstructionVehicle { get { return new ScannerFile("01_vehicle_category\\0x03A60E85.mp3", "0x03A60E85", "vehicle_category"); } }
        public static ScannerFile DumpTruck { get { return new ScannerFile("01_vehicle_category\\0x043502FD.mp3", "0x043502FD", "vehicle_category"); } }
        public static ScannerFile SailBoat { get { return new ScannerFile("01_vehicle_category\\0x0474F4A1.mp3", "0x0474F4A1", "vehicle_category"); } }
        public static ScannerFile MotorizedSkateboard01 { get { return new ScannerFile("01_vehicle_category\\0x0483453B.mp3", "Motorized skateboard", "vehicle_category"); } }
        public static ScannerFile HotRod { get { return new ScannerFile("01_vehicle_category\\0x04B923FA.mp3", "0x04B923FA", "vehicle_category"); } }
        public static ScannerFile Service01 { get { return new ScannerFile("01_vehicle_category\\0x04DBBC64.mp3", "Service Vehicle", "vehicle_category"); } }
        public static ScannerFile GolfCart { get { return new ScannerFile("01_vehicle_category\\0x04EE616F.mp3", "0x04EE616F", "vehicle_category"); } }
        public static ScannerFile Convertable01 { get { return new ScannerFile("01_vehicle_category\\0x05163779.mp3", "Convertable", "vehicle_category"); } }
        public static ScannerFile PickupTruck { get { return new ScannerFile("01_vehicle_category\\0x05D788EF.mp3", "0x05D788EF", "vehicle_category"); } }
        public static ScannerFile Combine { get { return new ScannerFile("01_vehicle_category\\0x0656C643.mp3", "0x0656C643", "vehicle_category"); } }
        public static ScannerFile RV { get { return new ScannerFile("01_vehicle_category\\0x06675D11.mp3", "0x06675D11", "vehicle_category"); } }
        public static ScannerFile SUV03 { get { return new ScannerFile("01_vehicle_category\\0x06D6D733.mp3", "0x06D6D733", "vehicle_category"); } }
        public static ScannerFile OffRoad01 { get { return new ScannerFile("01_vehicle_category\\0x06F2D611.mp3", "0x06F2D611", "vehicle_category"); } }
        public static ScannerFile Coupe01 { get { return new ScannerFile("01_vehicle_category\\0x0709DF95.mp3", "Coupe", "vehicle_category"); } }
        public static ScannerFile PoliceCar { get { return new ScannerFile("01_vehicle_category\\0x075FBBD8.mp3", "0x075FBBD8", "vehicle_category"); } }
        public static ScannerFile RollerSkates { get { return new ScannerFile("01_vehicle_category\\0x07713DE4.mp3", "0x07713DE4", "vehicle_category"); } }
        public static ScannerFile Trashmaster { get { return new ScannerFile("01_vehicle_category\\0x0797FA49.mp3", "0x0797FA49", "vehicle_category"); } }
        public static ScannerFile ATV01 { get { return new ScannerFile("01_vehicle_category\\0x0808530B.mp3", "ATV", "vehicle_category"); } }
        public static ScannerFile DuneBuggy { get { return new ScannerFile("01_vehicle_category\\0x08EE512E.mp3", "0x08EE512E", "vehicle_category"); } }
        public static ScannerFile Digger { get { return new ScannerFile("01_vehicle_category\\0x099011AD.mp3", "0x099011AD", "vehicle_category"); } }
        public static ScannerFile UtilityVehicle01 { get { return new ScannerFile("01_vehicle_category\\0x0ABDCE8E.mp3", "Utility vehicle", "vehicle_category"); } }
        public static ScannerFile MuscleCar01 { get { return new ScannerFile("01_vehicle_category\\0x0B6A5D7E.mp3", "Muscle Car", "vehicle_category"); } }
        public static ScannerFile MilitaryHelicopter { get { return new ScannerFile("01_vehicle_category\\0x0BEDDFB5.mp3", "0x0BEDDFB5", "vehicle_category"); } }
        public static ScannerFile Limo { get { return new ScannerFile("01_vehicle_category\\0x0C26D3BD.mp3", "0x0C26D3BD", "vehicle_category"); } }
        public static ScannerFile Scooter { get { return new ScannerFile("01_vehicle_category\\0x0CD9BE8E.mp3", "0x0CD9BE8E", "vehicle_category"); } }
        public static ScannerFile Tank { get { return new ScannerFile("01_vehicle_category\\0x0CDB4A21.mp3", "0x0CDB4A21", "vehicle_category"); } }
        public static ScannerFile Craine { get { return new ScannerFile("01_vehicle_category\\0x0D2D3165.mp3", "0x0D2D3165", "vehicle_category"); } }
        public static ScannerFile Classic01 { get { return new ScannerFile("01_vehicle_category\\0x0DB9439E.mp3", "Classic", "vehicle_category"); } }
        public static ScannerFile Tuner { get { return new ScannerFile("01_vehicle_category\\0x0DB9C91E.mp3", "0x0DB9C91E", "vehicle_category"); } }
        public static ScannerFile Troller { get { return new ScannerFile("01_vehicle_category\\0x0E4D13AD.mp3", "0x0E4D13AD", "vehicle_category"); } }
        public static ScannerFile Sedan { get { return new ScannerFile("01_vehicle_category\\0x0E63C9AE.mp3", "Sedan", "vehicle_category"); } }
        public static ScannerFile Forklift { get { return new ScannerFile("01_vehicle_category\\0x0E826F9B.mp3", "0x0E826F9B", "vehicle_category"); } }
        public static ScannerFile TroopTransport { get { return new ScannerFile("01_vehicle_category\\0x0E82768B.mp3", "0x0E82768B", "vehicle_category"); } }
        public static ScannerFile IndustrialVehicle01 { get { return new ScannerFile("01_vehicle_category\\0x0E970FAF.mp3", "industrail vehicle", "vehicle_category"); } }
        public static ScannerFile CivilianHelicopter { get { return new ScannerFile("01_vehicle_category\\0x0EBF5417.mp3", "0x0EBF5417", "vehicle_category"); } }
        public static ScannerFile Moped { get { return new ScannerFile("01_vehicle_category\\0x103174F6.mp3", "0x103174F6", "vehicle_category"); } }
        public static ScannerFile FourDoor01 { get { return new ScannerFile("01_vehicle_category\\0x1094F93E.mp3", "Four Door", "vehicle_category"); } }
        public static ScannerFile HydroFoil { get { return new ScannerFile("01_vehicle_category\\0x10A9671C.mp3", "0x10A9671C", "vehicle_category"); } }
        public static ScannerFile AgriculturalVehicle { get { return new ScannerFile("01_vehicle_category\\0x10E8D195.mp3", "0x10E8D195", "vehicle_category"); } }
        public static ScannerFile GoKart { get { return new ScannerFile("01_vehicle_category\\0x10FB6CA3.mp3", "0x10FB6CA3", "vehicle_category"); } }
        public static ScannerFile PontoonBoat { get { return new ScannerFile("01_vehicle_category\\0x1156A6A8.mp3", "0x1156A6A8", "vehicle_category"); } }
        public static ScannerFile PeopleCarrier { get { return new ScannerFile("01_vehicle_category\\0x11DB655E.mp3", "0x11DB655E", "vehicle_category"); } }
        public static ScannerFile MotorBike { get { return new ScannerFile("01_vehicle_category\\0x12A0A60B.mp3", "0x12A0A60B", "vehicle_category"); } }
        public static ScannerFile DuneBuggy02 { get { return new ScannerFile("01_vehicle_category\\0x12BF64D1.mp3", "0x12BF64D1", "vehicle_category"); } }
        public static ScannerFile TwoDoor01 { get { return new ScannerFile("01_vehicle_category\\0x1310A327.mp3", "Two Door", "vehicle_category"); } }
        public static ScannerFile FanBoat { get { return new ScannerFile("01_vehicle_category\\0x131B49C2.mp3", "0x131B49C2", "vehicle_category"); } }
        public static ScannerFile SubwayTrain { get { return new ScannerFile("01_vehicle_category\\0x13AFF107.mp3", "0x13AFF107", "vehicle_category"); } }
        public static ScannerFile Rollerblades { get { return new ScannerFile("01_vehicle_category\\0x141522F8.mp3", "0x141522F8", "vehicle_category"); } }
        public static ScannerFile Skateboard { get { return new ScannerFile("01_vehicle_category\\0x14BBA15E.mp3", "0x14BBA15E", "vehicle_category"); } }
        public static ScannerFile FourByFour { get { return new ScannerFile("01_vehicle_category\\0x14D0951B.mp3", "0x14D0951B", "vehicle_category"); } }
        public static ScannerFile Coupe02 { get { return new ScannerFile("01_vehicle_category\\0x14DE7B3E.mp3", "Coupe", "vehicle_category"); } }
        public static ScannerFile SpeedBoat { get { return new ScannerFile("01_vehicle_category\\0x14EC0C45.mp3", "0x14EC0C45", "vehicle_category"); } }
        public static ScannerFile MonsterTruck { get { return new ScannerFile("01_vehicle_category\\0x151A5E56.mp3", "0x151A5E56", "vehicle_category"); } }
        public static ScannerFile MiniVan01 { get { return new ScannerFile("01_vehicle_category\\0x15349899.mp3", "Minivan", "vehicle_category"); } }
        public static ScannerFile BackHoe { get { return new ScannerFile("01_vehicle_category\\0x1576E873.mp3", "0x1576E873", "vehicle_category"); } }
        public static ScannerFile Van01 { get { return new ScannerFile("01_vehicle_category\\0x158B8FA5.mp3", "Van", "vehicle_category"); } }
        public static ScannerFile JetSki { get { return new ScannerFile("01_vehicle_category\\0x1599B926.mp3", "0x1599B926", "vehicle_category"); } }
        public static ScannerFile Hatchback { get { return new ScannerFile("01_vehicle_category\\0x160B9ADB.mp3", "0x160B9ADB", "vehicle_category"); } }
        public static ScannerFile ArmoredTruck { get { return new ScannerFile("01_vehicle_category\\0x1620A2BC.mp3", "0x1620A2BC", "vehicle_category"); } }
        public static ScannerFile Helicopter01 { get { return new ScannerFile("01_vehicle_category\\0x177E286D.mp3", "Helicopter", "vehicle_category"); } }
        public static ScannerFile Pickup { get { return new ScannerFile("01_vehicle_category\\0x18092D52.mp3", "0x18092D52", "vehicle_category"); } }
        public static ScannerFile SUV01 { get { return new ScannerFile("01_vehicle_category\\0x18101511.mp3", "Sports Utility Vehicle", "vehicle_category"); } }
        public static ScannerFile Jallopy { get { return new ScannerFile("01_vehicle_category\\0x1831F800.mp3", "0x1831F800", "vehicle_category"); } }
        public static ScannerFile Rig01 { get { return new ScannerFile("01_vehicle_category\\0x188168A9.mp3", "Rig", "vehicle_category"); } }
        public static ScannerFile Yacht { get { return new ScannerFile("01_vehicle_category\\0x18BFD1A3.mp3", "0x18BFD1A3", "vehicle_category"); } }
        public static ScannerFile PoliceSedan01 { get { return new ScannerFile("01_vehicle_category\\0x1919DF4D.mp3", "Police Sedan", "vehicle_category"); } }
        public static ScannerFile QuadBike { get { return new ScannerFile("01_vehicle_category\\0x19F7C1E2.mp3", "0x19F7C1E2", "vehicle_category"); } }
        public static ScannerFile Junker { get { return new ScannerFile("01_vehicle_category\\0x1A159577.mp3", "0x1A159577", "vehicle_category"); } }
        public static ScannerFile Limo02 { get { return new ScannerFile("01_vehicle_category\\0x1A8BB088.mp3", "0x1A8BB088", "vehicle_category"); } }
        public static ScannerFile Trackter { get { return new ScannerFile("01_vehicle_category\\0x1A991863.mp3", "0x1A991863", "vehicle_category"); } }
        public static ScannerFile SportsCar01 { get { return new ScannerFile("01_vehicle_category\\0x1AEBB6E8.mp3", "Sports car", "vehicle_category"); } }
        public static ScannerFile RV02 { get { return new ScannerFile("01_vehicle_category\\0x1B1A8683.mp3", "0x1B1A8683", "vehicle_category"); } }
        public static ScannerFile BeachBuggy { get { return new ScannerFile("01_vehicle_category\\0x1C381231.mp3", "0x1C381231", "vehicle_category"); } }
        public static ScannerFile FarmVehicle { get { return new ScannerFile("01_vehicle_category\\0x1C9760CF.mp3", "0x1C9760CF", "vehicle_category"); } }
        public static ScannerFile Bus { get { return new ScannerFile("01_vehicle_category\\0x1CA6D8EC.mp3", "0x1CA6D8EC", "vehicle_category"); } }
        public static ScannerFile PerformanceCar01 { get { return new ScannerFile("01_vehicle_category\\0x1D525CE1.mp3", "Performance car", "vehicle_category"); } }
        public static ScannerFile Bulldozer { get { return new ScannerFile("01_vehicle_category\\0x1D8877D8.mp3", "Bulldozer", "vehicle_category"); } }
        public static ScannerFile TroopTransport02 { get { return new ScannerFile("01_vehicle_category\\0x1DBED504.mp3", "0x1DBED504", "vehicle_category"); } }
        public static ScannerFile MxBike { get { return new ScannerFile("01_vehicle_category\\0x1DBFB566.mp3", "0x1DBFB566", "vehicle_category"); } }
        public static ScannerFile MetroTrain { get { return new ScannerFile("01_vehicle_category\\0x1DCAAC3C.mp3", "0x1DCAAC3C", "vehicle_category"); } }
        public static ScannerFile FreightTrain { get { return new ScannerFile("01_vehicle_category\\0x1E24FC04.mp3", "0x1E24FC04", "vehicle_category"); } }
        public static ScannerFile PoliceMotorcycle { get { return new ScannerFile("01_vehicle_category\\0x1E8CEE5F.mp3", "0x1E8CEE5F", "vehicle_category"); } }
        public static ScannerFile Bike01 { get { return new ScannerFile("01_vehicle_category\\0x1FCD9DA9.mp3", "Bike", "vehicle_category"); } }
        public static ScannerFile Truck { get { return new ScannerFile("01_vehicle_category\\0x1FD2B13F.mp3", "0x1FD2B13F", "vehicle_category"); } }
    }
    public class we_have
    {
        public static ScannerFile UnitsReport_1 { get { return new ScannerFile("01_we_have\\0x03E3086B.mp3", "0x03E3086B", "we_have"); } }
        public static ScannerFile We_Have_1 { get { return new ScannerFile("01_we_have\\0x0662DE99.mp3", "0x0662DE99", "we_have"); } }
        public static ScannerFile CitizensReport_4 { get { return new ScannerFile("01_we_have\\0x07F7F36D.mp3", "0x07F7F36D", "we_have"); } }
        public static ScannerFile CitizensReport_1 { get { return new ScannerFile("01_we_have\\0x0ACF391D.mp3", "0x0ACF391D", "we_have"); } }
        public static ScannerFile OfficersReport_2 { get { return new ScannerFile("01_we_have\\0x128465AD.mp3", "0x128465AD", "we_have"); } }
        public static ScannerFile OfficersReport_1 { get { return new ScannerFile("01_we_have\\0x1628ACF6.mp3", "0x1628ACF6", "we_have"); } }
        public static ScannerFile We_Have_2 { get { return new ScannerFile("01_we_have\\0x1823821B.mp3", "0x1823821B", "we_have"); } }
        public static ScannerFile CitizensReport_2 { get { return new ScannerFile("01_we_have\\0x1D1D5DBA.mp3", "0x1D1D5DBA", "we_have"); } }
        public static ScannerFile CitizensReport_3 { get { return new ScannerFile("01_we_have\\0x1F72E264.mp3", "0x1F72E264", "we_have"); } }
    }
    //public class year
    //{
    //    public static ScannerFile HASH0033BF81 { get { return new ScannerFile("01_year\\0x0033BF81.mp3", "0x0033BF81", "year"); } }
    //    public static ScannerFile HASH00B67763 { get { return new ScannerFile("01_year\\0x00B67763.mp3", "0x00B67763", "year"); } }
    //    public static ScannerFile HASH02B30383 { get { return new ScannerFile("01_year\\0x02B30383.mp3", "0x02B30383", "year"); } }
    //    public static ScannerFile HASH036B8084 { get { return new ScannerFile("01_year\\0x036B8084.mp3", "0x036B8084", "year"); } }
    //    public static ScannerFile HASH05C709B8 { get { return new ScannerFile("01_year\\0x05C709B8.mp3", "0x05C709B8", "year"); } }
    //    public static ScannerFile HASH05FDCB16 { get { return new ScannerFile("01_year\\0x05FDCB16.mp3", "0x05FDCB16", "year"); } }
    //    public static ScannerFile HASH0708009C { get { return new ScannerFile("01_year\\0x0708009C.mp3", "0x0708009C", "year"); } }
    //    public static ScannerFile HASH070EFC25 { get { return new ScannerFile("01_year\\0x070EFC25.mp3", "0x070EFC25", "year"); } }
    //    public static ScannerFile HASH0761B07A { get { return new ScannerFile("01_year\\0x0761B07A.mp3", "0x0761B07A", "year"); } }
    //    public static ScannerFile HASH0821C9EF { get { return new ScannerFile("01_year\\0x0821C9EF.mp3", "0x0821C9EF", "year"); } }
    //    public static ScannerFile HASH09AC8E8E { get { return new ScannerFile("01_year\\0x09AC8E8E.mp3", "0x09AC8E8E", "year"); } }
    //    public static ScannerFile HASH0D1F985B { get { return new ScannerFile("01_year\\0x0D1F985B.mp3", "0x0D1F985B", "year"); } }
    //    public static ScannerFile HASH0D68947F { get { return new ScannerFile("01_year\\0x0D68947F.mp3", "0x0D68947F", "year"); } }
    //    public static ScannerFile HASH0F6B74E6 { get { return new ScannerFile("01_year\\0x0F6B74E6.mp3", "0x0F6B74E6", "year"); } }
    //    public static ScannerFile HASH1088ED93 { get { return new ScannerFile("01_year\\0x1088ED93.mp3", "0x1088ED93", "year"); } }
    //    public static ScannerFile HASH147616F3 { get { return new ScannerFile("01_year\\0x147616F3.mp3", "0x147616F3", "year"); } }
    //    public static ScannerFile HASH1567247B { get { return new ScannerFile("01_year\\0x1567247B.mp3", "0x1567247B", "year"); } }
    //    public static ScannerFile HASH15A77F9F { get { return new ScannerFile("01_year\\0x15A77F9F.mp3", "0x15A77F9F", "year"); } }
    //    public static ScannerFile HASH166862C8 { get { return new ScannerFile("01_year\\0x166862C8.mp3", "0x166862C8", "year"); } }
    //    public static ScannerFile HASH16A38189 { get { return new ScannerFile("01_year\\0x16A38189.mp3", "0x16A38189", "year"); } }
    //    public static ScannerFile HASH17816D2D { get { return new ScannerFile("01_year\\0x17816D2D.mp3", "0x17816D2D", "year"); } }
    //    public static ScannerFile HASH186D2F8B { get { return new ScannerFile("01_year\\0x186D2F8B.mp3", "0x186D2F8B", "year"); } }
    //    public static ScannerFile HASH19B0C108 { get { return new ScannerFile("01_year\\0x19B0C108.mp3", "0x19B0C108", "year"); } }
    //    public static ScannerFile HASH19C7D51C { get { return new ScannerFile("01_year\\0x19C7D51C.mp3", "0x19C7D51C", "year"); } }
    //    public static ScannerFile HASH1B24717A { get { return new ScannerFile("01_year\\0x1B24717A.mp3", "0x1B24717A", "year"); } }
    //    public static ScannerFile HASH1BCE8538 { get { return new ScannerFile("01_year\\0x1BCE8538.mp3", "0x1BCE8538", "year"); } }
    //    public static ScannerFile HASH1D1B1043 { get { return new ScannerFile("01_year\\0x1D1B1043.mp3", "0x1D1B1043", "year"); } }
    //    public static ScannerFile HASH1D979CE6 { get { return new ScannerFile("01_year\\0x1D979CE6.mp3", "0x1D979CE6", "year"); } }
    //    public static ScannerFile HASH1E4E491E { get { return new ScannerFile("01_year\\0x1E4E491E.mp3", "0x1E4E491E", "year"); } }
    //    public static ScannerFile HASH1EA0DEF4 { get { return new ScannerFile("01_year\\0x1EA0DEF4.mp3", "0x1EA0DEF4", "year"); } }
    //    public static ScannerFile HASH1EC83C50 { get { return new ScannerFile("01_year\\0x1EC83C50.mp3", "0x1EC83C50", "year"); } }
    //}
    //public class random_chat
    //{
    //    public static ScannerFile RANDOMCHAT1 { get { return new ScannerFile("random_chat\\RANDOMCHAT1.mp3", "RANDOMCHAT1", "random_chat"); } }
    //    public static ScannerFile RANDOMCHAT2 { get { return new ScannerFile("random_chat\\RANDOMCHAT2.mp3", "RANDOMCHAT2", "random_chat"); } }
    //    public static ScannerFile RANDOMCHAT3 { get { return new ScannerFile("random_chat\\RANDOMCHAT3.mp3", "RANDOMCHAT3", "random_chat"); } }
    //    public static ScannerFile RANDOMCHAT5 { get { return new ScannerFile("random_chat\\RANDOMCHAT5.mp3", "RANDOMCHAT5", "random_chat"); } }
    //    public static ScannerFile RANDOMCHAT6 { get { return new ScannerFile("random_chat\\RANDOMCHAT6.mp3", "RANDOMCHAT6", "random_chat"); } }
    //    public static ScannerFile RANDOMCHAT7 { get { return new ScannerFile("random_chat\\RANDOMCHAT7.mp3", "RANDOMCHAT7", "random_chat"); } }
    //    public static ScannerFile RANDOMCHAT8 { get { return new ScannerFile("random_chat\\RANDOMCHAT8.mp3", "RANDOMCHAT8", "random_chat"); } }
    //}
    public class spot_suspect_cop_01
    {
        public static ScannerFile WeHaveAVisual1 { get { return new ScannerFile("spot_suspect_cop_01\\0x0601EE8E.mp3", "0x0601EE8E", "spot_suspect_cop_01"); } }
        public static ScannerFile WeHaveAVisual2 { get { return new ScannerFile("spot_suspect_cop_01\\0x06A36FCF.mp3", "0x06A36FCF", "spot_suspect_cop_01"); } }
        public static ScannerFile WeHaveAVisual3 { get { return new ScannerFile("spot_suspect_cop_01\\0x08E3F451.mp3", "0x08E3F451", "spot_suspect_cop_01"); } }
        public static ScannerFile WeHaveAVisual4 { get { return new ScannerFile("spot_suspect_cop_01\\0x0C703B6A.mp3", "0x0C703B6A", "spot_suspect_cop_01"); } }
        public static ScannerFile WeHaveAVisual5 { get { return new ScannerFile("spot_suspect_cop_01\\0x13478918.mp3", "0x13478918", "spot_suspect_cop_01"); } }
        public static ScannerFile WeHaveAVisual6 { get { return new ScannerFile("spot_suspect_cop_01\\0x17551134.mp3", "0x17551134", "spot_suspect_cop_01"); } }
        public static ScannerFile WeHaveAVisual7 { get { return new ScannerFile("spot_suspect_cop_01\\0x1A3056EA.mp3", "0x1A3056EA", "spot_suspect_cop_01"); } }
        public static ScannerFile WeHaveAVisual8 { get { return new ScannerFile("spot_suspect_cop_01\\0x1B3A58FF.mp3", "0x1B3A58FF", "spot_suspect_cop_01"); } }
    }
    public class spot_suspect_cop_02
    {
        public static ScannerFile WeHaveAVisual1 { get { return new ScannerFile("spot_suspect_cop_02\\0x06A36FCF.mp3", "0x06A36FCF", "spot_suspect_cop_02"); } }
        public static ScannerFile WeHaveAVisual2 { get { return new ScannerFile("spot_suspect_cop_02\\0x08E3F451.mp3", "0x08E3F451", "spot_suspect_cop_02"); } }
        public static ScannerFile WeHaveAVisual3 { get { return new ScannerFile("spot_suspect_cop_02\\0x0C703B6A.mp3", "0x0C703B6A", "spot_suspect_cop_02"); } }
        public static ScannerFile WeHaveAVisual4 { get { return new ScannerFile("spot_suspect_cop_02\\0x13478918.mp3", "0x13478918", "spot_suspect_cop_02"); } }
        public static ScannerFile WeHaveAVisual5 { get { return new ScannerFile("spot_suspect_cop_02\\0x17551134.mp3", "0x17551134", "spot_suspect_cop_02"); } }
        public static ScannerFile WeHaveAVisual6 { get { return new ScannerFile("spot_suspect_cop_02\\0x1A3056EA.mp3", "0x1A3056EA", "spot_suspect_cop_02"); } }
        public static ScannerFile WeHaveAVisual7 { get { return new ScannerFile("spot_suspect_cop_02\\0x1B3A58FF.mp3", "0x1B3A58FF", "spot_suspect_cop_02"); } }
    }
    public class spot_suspect_cop_03
    {
        public static ScannerFile WeHaveAVisual1 { get { return new ScannerFile("spot_suspect_cop_03\\0x0601EE8E.mp3", "0x0601EE8E", "spot_suspect_cop_03"); } }
        public static ScannerFile WeHaveAVisual2 { get { return new ScannerFile("spot_suspect_cop_03\\0x06A36FCF.mp3", "0x06A36FCF", "spot_suspect_cop_03"); } }
        public static ScannerFile WeHaveAVisual3 { get { return new ScannerFile("spot_suspect_cop_03\\0x08E3F451.mp3", "0x08E3F451", "spot_suspect_cop_03"); } }
        public static ScannerFile WeHaveAVisual4 { get { return new ScannerFile("spot_suspect_cop_03\\0x0C703B6A.mp3", "0x0C703B6A", "spot_suspect_cop_03"); } }
        public static ScannerFile WeHaveAVisual5 { get { return new ScannerFile("spot_suspect_cop_03\\0x13478918.mp3", "0x13478918", "spot_suspect_cop_03"); } }
        public static ScannerFile WeHaveAVisual6 { get { return new ScannerFile("spot_suspect_cop_03\\0x17551134.mp3", "0x17551134", "spot_suspect_cop_03"); } }
        public static ScannerFile WeHaveAVisual7 { get { return new ScannerFile("spot_suspect_cop_03\\0x1A3056EA.mp3", "0x1A3056EA", "spot_suspect_cop_03"); } }
        public static ScannerFile WeHaveAVisual8 { get { return new ScannerFile("spot_suspect_cop_03\\0x1B3A58FF.mp3", "0x1B3A58FF", "spot_suspect_cop_03"); } }
    }
    public class spot_suspect_cop_04
    {
        public static ScannerFile WeHaveAVisual1 { get { return new ScannerFile("spot_suspect_cop_04\\0x0601EE8E.mp3", "0x0601EE8E", "spot_suspect_cop_04"); } }
        public static ScannerFile WeHaveAVisual2 { get { return new ScannerFile("spot_suspect_cop_04\\0x06A36FCF.mp3", "0x06A36FCF", "spot_suspect_cop_04"); } }
        public static ScannerFile WeHaveAVisual3 { get { return new ScannerFile("spot_suspect_cop_04\\0x08E3F451.mp3", "0x08E3F451", "spot_suspect_cop_04"); } }
        public static ScannerFile WeHaveAVisual4 { get { return new ScannerFile("spot_suspect_cop_04\\0x0C703B6A.mp3", "0x0C703B6A", "spot_suspect_cop_04"); } }
        public static ScannerFile WeHaveAVisual5 { get { return new ScannerFile("spot_suspect_cop_04\\0x13478918.mp3", "0x13478918", "spot_suspect_cop_04"); } }
        public static ScannerFile WeHaveAVisual6 { get { return new ScannerFile("spot_suspect_cop_04\\0x17551134.mp3", "0x17551134", "spot_suspect_cop_04"); } }
        public static ScannerFile WeHaveAVisual7 { get { return new ScannerFile("spot_suspect_cop_04\\0x1A3056EA.mp3", "0x1A3056EA", "spot_suspect_cop_04"); } }
        public static ScannerFile WeHaveAVisual8 { get { return new ScannerFile("spot_suspect_cop_04\\0x1B3A58FF.mp3", "0x1B3A58FF", "spot_suspect_cop_04"); } }
    }
    public class spot_suspect_cop_05
    {
        public static ScannerFile WeHaveAVisual1 { get { return new ScannerFile("spot_suspect_cop_05\\0x06A36FCF.mp3", "0x06A36FCF", "spot_suspect_cop_05"); } }
        public static ScannerFile WeHaveAVisual2 { get { return new ScannerFile("spot_suspect_cop_05\\0x08E3F451.mp3", "0x08E3F451", "spot_suspect_cop_05"); } }
        public static ScannerFile WeHaveAVisual3 { get { return new ScannerFile("spot_suspect_cop_05\\0x0C703B6A.mp3", "0x0C703B6A", "spot_suspect_cop_05"); } }
        public static ScannerFile WeHaveAVisual4 { get { return new ScannerFile("spot_suspect_cop_05\\0x13478918.mp3", "0x13478918", "spot_suspect_cop_05"); } }
        public static ScannerFile WeHaveAVisual5 { get { return new ScannerFile("spot_suspect_cop_05\\0x17551134.mp3", "0x17551134", "spot_suspect_cop_05"); } }
        public static ScannerFile WeHaveAVisual6 { get { return new ScannerFile("spot_suspect_cop_05\\0x1A3056EA.mp3", "0x1A3056EA", "spot_suspect_cop_05"); } }
        public static ScannerFile WeHaveAVisual7 { get { return new ScannerFile("spot_suspect_cop_05\\0x1B3A58FF.mp3", "0x1B3A58FF", "spot_suspect_cop_05"); } }
    }
    public class s_f_y_cop_black_full_01
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x017221AA.mp3", "0x017221AA", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x01A10324.mp3", "0x01A10324", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x0846F27E.mp3", "0x0846F27E", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x0AF015F7.mp3", "0x0AF015F7", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x0FD39C10.mp3", "0x0FD39C10", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x1046DF8A.mp3", "0x1046DF8A", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x137027BC.mp3", "0x137027BC", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x144A2876.mp3", "0x144A2876", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x1AF6E025.mp3", "0x1AF6E025", "s_f_y_cop_black_full_01"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_f_y_cop_01_black_full_01\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_f_y_cop_black_full_01"); } }
    }
    public class s_f_y_cop_black_full_02
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x017221AA.mp3", "0x017221AA", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x01A10324.mp3", "0x01A10324", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x0846F27E.mp3", "0x0846F27E", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x0AF015F7.mp3", "0x0AF015F7", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x0FD39C10.mp3", "0x0FD39C10", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x1046DF8A.mp3", "0x1046DF8A", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x137027BC.mp3", "0x137027BC", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x144A2876.mp3", "0x144A2876", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x1AF6E025.mp3", "0x1AF6E025", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x1B2B551D.mp3", "0x1B2B551D", "s_f_y_cop_black_full_02"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_f_y_cop_01_black_full_02\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_f_y_cop_black_full_02"); } }
    }
    public class s_f_y_cop_white_full_01
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x017221AA.mp3", "0x017221AA", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x01A10324.mp3", "0x01A10324", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x0846F27E.mp3", "0x0846F27E", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x0AF015F7.mp3", "0x0AF015F7", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x0FD39C10.mp3", "0x0FD39C10", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x1046DF8A.mp3", "0x1046DF8A", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x137027BC.mp3", "0x137027BC", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x144A2876.mp3", "0x144A2876", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x1AF6E025.mp3", "0x1AF6E025", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x1B2B551D.mp3", "0x1B2B551D", "s_f_y_cop_white_full_01"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_f_y_cop_01_white_full_01\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_f_y_cop_white_full_01"); } }
    }
    public class s_f_y_cop_white_full_02
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x017221AA.mp3", "0x017221AA", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x01A10324.mp3", "0x01A10324", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x0846F27E.mp3", "0x0846F27E", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x0AF015F7.mp3", "0x0AF015F7", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x0FD39C10.mp3", "0x0FD39C10", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x1046DF8A.mp3", "0x1046DF8A", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x137027BC.mp3", "0x137027BC", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x144A2876.mp3", "0x144A2876", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x1AF6E025.mp3", "0x1AF6E025", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x1B2B551D.mp3", "0x1B2B551D", "s_f_y_cop_white_full_02"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_f_y_cop_01_white_full_02\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_f_y_cop_white_full_02"); } }
    }
    public class s_m_y_cop_black_full_01
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile DrivingACar1 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x01A10324.mp3", "0x01A10324", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile RidingMotorcycle1 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x144A2876.mp3", "0x144A2876", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile DrivingACar2 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_cop_black_full_01"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_black_full_01\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_black_full_01"); } }
    }
    public class s_m_y_cop_black_full_02
    {
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x01A10324.mp3", "0x01A10324", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x030276D5.mp3", "0x030276D5", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x046135A4.mp3", "0x046135A4", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0496792A.mp3", "0x0496792A", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x12461560.mp3", "0x12461560", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x144A2876.mp3", "0x144A2876", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1C086912.mp3", "0x1C086912", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_cop_black_full_02"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_black_full_02\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_black_full_02"); } }
    }
    public class s_m_y_cop_black_mini_01
    {
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x030276D5.mp3", "0x030276D5", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x046135A4.mp3", "0x046135A4", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x0496792A.mp3", "0x0496792A", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH0D3B44AE { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x12461560.mp3", "0x12461560", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x1C086912.mp3", "0x1C086912", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_cop_black_mini_01"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_black_mini_01\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_black_mini_01"); } }
    }
    public class s_m_y_cop_black_mini_02
    {
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x030276D5.mp3", "0x030276D5", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x046135A4.mp3", "0x046135A4", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x0496792A.mp3", "0x0496792A", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x12461560.mp3", "0x12461560", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x1C086912.mp3", "0x1C086912", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_cop_black_mini_02"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_black_mini_02\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_black_mini_02"); } }
    }
    public class s_m_y_cop_black_mini_03
    {
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x030276D5.mp3", "0x030276D5", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x046135A4.mp3", "0x046135A4", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x0496792A.mp3", "0x0496792A", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x12461560.mp3", "0x12461560", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x1C086912.mp3", "0x1C086912", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_cop_black_mini_03"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_black_mini_03\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_black_mini_03"); } }
    }
    public class s_m_y_cop_black_mini_04
    {
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x030276D5.mp3", "0x030276D5", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x046135A4.mp3", "0x046135A4", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x0496792A.mp3", "0x0496792A", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x12461560.mp3", "0x12461560", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x1C086912.mp3", "0x1C086912", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_cop_black_mini_04"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_black_mini_04\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_black_mini_04"); } }
    }
    public class s_m_y_cop_white_full_01
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x00FFC2DB.mp3", "SuspectIsOnFoot", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectInACar { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x017221AA.mp3", "SuspectInACar", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x01A10324.mp3", "RequestingBackupWeNeedBackup", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile MaydayWeAreGoingDown { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x030276D5.mp3", "MaydayWeAreGoingDown", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile CopyThatWeAreInTheVecinity { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x046135A4.mp3", "CopyThatWeAreInTheVecinity", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile AirSupportSuspectIsHeadingSouth { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0496792A.mp3", "WeHaveAVisualOnTheSuspectMovingSouth", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile WeAreAirbornAndMovingIn { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0513FA72.mp3", "WeAreAirbornAndMovingIn", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x08DB544A.mp3", "DoesAnybodyHaveAVisual", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x08E377EE.mp3", "HaveVisualSuspectOnFoot", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0AF015F7.mp3", "WeNeedBackupNow", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0D3B44AE.mp3", "SuspectEnteringTheFreeway", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0D59A0C8.mp3", "SuspectLeavingTheFreeway", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0ED8BFA8.mp3", "SuspectHasFuckingCrashed", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile AirSupportSuspectIsHeadingNorth { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0F80B554.mp3", "AirSupportSuspectIsHeadingNorth", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x0FD39C10.mp3", "DispatchSuspectHasEneteredTheMetro", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectOnAMotorcycle { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile AirSupportLostSuspect { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x118A68BD.mp3", "AirSupportLostSuspect", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x12461560.mp3", "0x12461560", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x144A2876.mp3", "RequestingBackup", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile AirSupportSuspectIsHeadingWest { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x14C47BCF.mp3", "AirSupportSuspectWest", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile GotEyesHesOnFoot { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile DispatchYouHaveALocationForTheSuspect { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1A56373F.mp3", "DispatchYouHaveALocationForTheSuspect", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile AirSupportSuspectIsHeadingEast { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1AAF0500.mp3", "AirSupportSuspectEast", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectIsInACarInPursuit { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile AirSupportIsInRoute { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1BCC27E6.mp3", "AirSupportIsInRoute", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1C086912.mp3", "CopyThatMovingRightNow", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile WeDoNotHaveAVisual { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1E65C2A3.mp3", "WeDoNotHaveAVisual", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile RogerThatWeAreOnOurWay { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1EB82E73.mp3", "RogerThatWeAreOnOurWay", "s_m_y_cop_white_full_01"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_white_full_01\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_white_full_01"); } }
    }
    public class s_m_y_cop_white_full_02
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x01A10324.mp3", "MikeOscarSamInHotNeedOfBackup", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x030276D5.mp3", "0x030276D5", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile CharlieFourRogerThatWereIntheArea { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x046135A4.mp3", "CharlieFourRogerThatWereIntheArea", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0496792A.mp3", "0x0496792A", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0AF015F7.mp3", "MikeOScarSamRequestingBackup", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x12461560.mp3", "0x12461560", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x144A2876.mp3", "0x144A2876", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1C086912.mp3", "0x1C086912", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile Charlie4WellLookForThoseMaggots { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_cop_white_full_02"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_white_full_02\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_white_full_02"); } }
    }
    public class s_m_y_cop_white_mini_01
    {
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_white_mini_01\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_white_mini_01"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_01\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_cop_white_mini_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_white_mini_01\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_white_mini_01"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_01\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_white_mini_01"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_white_mini_01\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_white_mini_01"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_white_mini_01\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_white_mini_01"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_01\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_white_mini_01"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_01\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_white_mini_01"); } }
    }
    public class s_m_y_cop_white_mini_02
    {
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x030276D5.mp3", "0x030276D5", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x046135A4.mp3", "0x046135A4", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x0496792A.mp3", "0x0496792A", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x0AF015F7.mp3", "INeedSomeSeriousBackupHere", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x12461560.mp3", "0x12461560", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x1C086912.mp3", "0x1C086912", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_cop_white_mini_02"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_white_mini_02\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_white_mini_02"); } }
    }
    public class s_m_y_cop_white_mini_03
    {
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x030276D5.mp3", "0x030276D5", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x046135A4.mp3", "0x046135A4", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x0496792A.mp3", "0x0496792A", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x0AF015F7.mp3", "OfficerInNeedofSomeBackupHere", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x12461560.mp3", "0x12461560", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x1C086912.mp3", "0x1C086912", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile AdamFourCopy { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x1EB82E73.mp3", "AdamFourCopy", "s_m_y_cop_white_mini_03"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_white_mini_03\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_white_mini_03"); } }
    }
    public class s_m_y_cop_white_mini_04
    {
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x017221AA.mp3", "0x017221AA", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x030276D5.mp3", "0x030276D5", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x046135A4.mp3", "0x046135A4", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x0496792A.mp3", "0x0496792A", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x12461560.mp3", "0x12461560", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x137027BC.mp3", "0x137027BC", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x16A41369.mp3", "0x16A41369", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x1C086912.mp3", "0x1C086912", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_cop_white_mini_04"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_cop_01_white_mini_04\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_cop_white_mini_04"); } }
    }
    public class s_m_y_hwaycop_black_full_01
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x017221AA.mp3", "0x017221AA", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x01A10324.mp3", "0x01A10324", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x030276D5.mp3", "0x030276D5", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x046135A4.mp3", "0x046135A4", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0496792A.mp3", "0x0496792A", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH053ECA5F { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x053ECA5F.mp3", "0x053ECA5F", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0AF015F7.mp3", "WeNeedBackupQuick", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x12461560.mp3", "0x12461560", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x137027BC.mp3", "0x137027BC", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x144A2876.mp3", "0x144A2876", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x16A41369.mp3", "0x16A41369", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH17776ED0 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x17776ED0.mp3", "0x17776ED0", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1C086912.mp3", "0x1C086912", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_hwaycop_black_full_01"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_01\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_hwaycop_black_full_01"); } }
    }
    public class s_m_y_hwaycop_black_full_02
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x017221AA.mp3", "0x017221AA", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x01A10324.mp3", "0x01A10324", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x030276D5.mp3", "0x030276D5", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x046135A4.mp3", "0x046135A4", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0496792A.mp3", "0x0496792A", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x12461560.mp3", "0x12461560", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x137027BC.mp3", "0x137027BC", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x144A2876.mp3", "0x144A2876", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x16A41369.mp3", "0x16A41369", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1C086912.mp3", "0x1C086912", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_hwaycop_black_full_02"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_hwaycop_01_black_full_02\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_hwaycop_black_full_02"); } }
    }
    public class s_m_y_hwaycop_white_full_01
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x017221AA.mp3", "0x017221AA", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x01A10324.mp3", "0x01A10324", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x030276D5.mp3", "0x030276D5", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x046135A4.mp3", "0x046135A4", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0496792A.mp3", "0x0496792A", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x12461560.mp3", "0x12461560", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x137027BC.mp3", "0x137027BC", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x144A2876.mp3", "0x144A2876", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x16A41369.mp3", "0x16A41369", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1C086912.mp3", "0x1C086912", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_hwaycop_white_full_01"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_01\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_hwaycop_white_full_01"); } }
    }
    public class s_m_y_hwaycop_white_full_02
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x017221AA.mp3", "0x017221AA", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x01A10324.mp3", "0x01A10324", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH030276D5 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x030276D5.mp3", "0x030276D5", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH046135A4 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x046135A4.mp3", "0x046135A4", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH0496792A { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0496792A.mp3", "0x0496792A", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH0513FA72 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0513FA72.mp3", "0x0513FA72", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile CantSeeSuspect1 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x08DB544A.mp3", "0x08DB544A", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile SuspectOnFoot3 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x08E377EE.mp3", "0x08E377EE", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH09D5A5ED { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x09D5A5ED.mp3", "0x09D5A5ED", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH0B5B6665 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0B5B6665.mp3", "0x0B5B6665", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH0B78C3D3 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0B78C3D3.mp3", "0x0B78C3D3", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH0F80B554 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0F80B554.mp3", "0x0F80B554", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH118A68BD { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x118A68BD.mp3", "0x118A68BD", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH12461560 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x12461560.mp3", "0x12461560", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x137027BC.mp3", "0x137027BC", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x144A2876.mp3", "0x144A2876", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH14C47BCF { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x14C47BCF.mp3", "0x14C47BCF", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH16A41369 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x16A41369.mp3", "0x16A41369", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH16D11D9F { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x16D11D9F.mp3", "0x16D11D9F", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH1A56373F { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1A56373F.mp3", "0x1A56373F", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH1AAF0500 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1AAF0500.mp3", "0x1AAF0500", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH1BCC27E6 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1BCC27E6.mp3", "0x1BCC27E6", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile RogerEnRoute1 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1C086912.mp3", "0x1C086912", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH1E65C2A3 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1E65C2A3.mp3", "0x1E65C2A3", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH1EB82E73 { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1EB82E73.mp3", "0x1EB82E73", "s_m_y_hwaycop_white_full_02"); } }
        public static ScannerFile HASH1F7C154B { get { return new ScannerFile("s_m_y_hwaycop_01_white_full_02\\0x1F7C154B.mp3", "0x1F7C154B", "s_m_y_hwaycop_white_full_02"); } }
    }
    public class s_m_y_sheriff_white_full_01
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x017221AA.mp3", "0x017221AA", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x01A10324.mp3", "0x01A10324", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x137027BC.mp3", "0x137027BC", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x144A2876.mp3", "0x144A2876", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_sheriff_white_full_01"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_01\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_sheriff_white_full_01"); } }
    }
    public class s_m_y_sheriff_white_full_02
    {
        public static ScannerFile SuspectOnFoot4 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x00FFC2DB.mp3", "0x00FFC2DB", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile HASH017221AA { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x017221AA.mp3", "0x017221AA", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile NeedBackup1 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x01A10324.mp3", "0x01A10324", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile SuspectCrashed { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x0846F27E.mp3", "0x0846F27E", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile NeedBackup3 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x0AF015F7.mp3", "0x0AF015F7", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x0D3B44AE.mp3", "0x0D3B44AE", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile SuspectLeftFreeway { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x0D59A0C8.mp3", "0x0D59A0C8", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile SuspectCrashed2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x0ED8BFA8.mp3", "0x0ED8BFA8", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile SuspectEnteredMetro { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x0FD39C10.mp3", "0x0FD39C10", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile HASH1046DF8A { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x1046DF8A.mp3", "0x1046DF8A", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile SuspectOnFoot2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x137027BC.mp3", "0x137027BC", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile NeedBackup2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x144A2876.mp3", "0x144A2876", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile SuspectEnteringTheFreeway2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x1AF6E025.mp3", "0x1AF6E025", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile HASH1B2B551D { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x1B2B551D.mp3", "0x1B2B551D", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile SuspectLeftFreeway2 { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x1BD2FDBA.mp3", "0x1BD2FDBA", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile HASH1E193B2F { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x1E193B2F.mp3", "0x1E193B2F", "s_m_y_sheriff_white_full_02"); } }
        public static ScannerFile HASH1E99399B { get { return new ScannerFile("s_m_y_sheriff_01_white_full_02\\0x1E99399B.mp3", "0x1E99399B", "s_m_y_sheriff_white_full_02"); } }
    }
    public class SpeedQuotes
    {
        public static ScannerFile PopQuizHotShot { get { return new ScannerFile("SpeedQuotes\\PopQuizHotShot.mp3", "Pop quiz hot shot...", "Speed"); } }
    }
    public class AudioBeeps
    {
        public static ScannerFile Radio_Start_1 { get { return new ScannerFile("01_radio_beep\\Radio_Start_1.mp3", "Radio_Start_1", "Radio_Start_1"); } }
        public static ScannerFile Radio_Start_2 { get { return new ScannerFile("01_radio_beep\\Radio_Start_2.mp3", "Radio_Start_2", "Radio_Start_2"); } }
        public static ScannerFile Radio_End_1 { get { return new ScannerFile("01_radio_beep\\Radio_End_1.mp3", "Radio_End_1", "Radio_End_1"); } }
        public static ScannerFile Radio_End_2 { get { return new ScannerFile("01_radio_beep\\Radio_End_2.mp3", "Radio_End_2", "Radio_End_2"); } }
    }


    public class Ringtones
    {
        public static ScannerFile CELLPHONE_RING { get { return new ScannerFile("tones\\CELLPHONE_RING.mp3", "CELLPHONE_RING", "CELLPHONE_RING"); } }
        public static ScannerFile OneZeroNine { get { return new ScannerFile("tones\\109.mp3", "109", "109"); } }
        public static ScannerFile BASSMATIC { get { return new ScannerFile("tones\\BASSMATIC.mp3", "BASSMATIC", "BASSMATIC"); } }
        public static ScannerFile CELLPHONE_SMS_LOOP { get { return new ScannerFile("tones\\CELLPHONE_SMS_LOOP.mp3", "CELLPHONE_SMS_LOOP", "CELLPHONE_SMS_LOOP"); } }
        public static ScannerFile COOLROOM { get { return new ScannerFile("tones\\COOLROOM.mp3", "COOLROOM", "COOLROOM"); } }
        public static ScannerFile CREDITCHECK { get { return new ScannerFile("tones\\CREDITCHECK.mp3", "CREDITCHECK", "CREDITCHECK"); } }
        public static ScannerFile DRIVE { get { return new ScannerFile("tones\\DRIVE.mp3", "DRIVE", "DRIVE"); } }
        public static ScannerFile FOURTHSRINGTONE { get { return new ScannerFile("tones\\FOURTHSRINGTONE.mp3", "FOURTHSRINGTONE", "FOURTHSRINGTONE"); } }
        public static ScannerFile FUNKINTIME { get { return new ScannerFile("tones\\FUNKINTIME.mp3", "FUNKINTIME", "FUNKINTIME"); } }
        public static ScannerFile GETDOWN { get { return new ScannerFile("tones\\GETDOWN.mp3", "GETDOWN", "GETDOWN"); } }
        public static ScannerFile INTOSOMETHING { get { return new ScannerFile("tones\\INTOSOMETHING.mp3", "INTOSOMETHING", "INTOSOMETHING"); } }
        public static ScannerFile KATJASWALTZ { get { return new ScannerFile("tones\\KATJASWALTZ.mp3", "KATJASWALTZ", "KATJASWALTZ"); } }
        public static ScannerFile LAIDBACK { get { return new ScannerFile("tones\\LAIDBACK.mp3", "LAIDBACK", "LAIDBACK"); } }
        public static ScannerFile MINEUNTILMONDAY { get { return new ScannerFile("tones\\MINEUNTILMONDAY.mp3", "MINEUNTILMONDAY", "MINEUNTILMONDAY"); } }
        public static ScannerFile SOLO { get { return new ScannerFile("tones\\SOLO.mp3", "SOLO", "SOLO"); } }
        public static ScannerFile SWINGIT { get { return new ScannerFile("tones\\SWINGIT.mp3", "SWINGIT", "SWINGIT"); } }
        public static ScannerFile TAKETHEPAIN { get { return new ScannerFile("tones\\TAKETHEPAIN.mp3", "TAKETHEPAIN", "TAKETHEPAIN"); } }
        public static ScannerFile THEONEFORME { get { return new ScannerFile("tones\\THEONEFORME.mp3", "THEONEFORME", "THEONEFORME"); } }
        public static ScannerFile TONIGHT { get { return new ScannerFile("tones\\TONIGHT.mp3", "TONIGHT", "TONIGHT"); } }
        public static ScannerFile STTHOMAS { get { return new ScannerFile("tones\\STTHOMAS.mp3", "STTHOMAS", "STTHOMAS"); } }

    }


    public class SWAT3
    {
        public static ScannerFile airsupportimmediateinsertion { get { return new ScannerFile("03_swat\\airsupportimmediateinsertion.mp3", "Radio_Start_1", "Radio_Start_1"); } }
        public static ScannerFile calloutpending { get { return new ScannerFile("03_swat\\calloutpending.mp3", "Radio_Start_2", "Radio_Start_2"); } }
        public static ScannerFile copyemergencytraffic { get { return new ScannerFile("03_swat\\copyemergencytraffic.mp3", "Radio_End_1", "Radio_End_1"); } }
        public static ScannerFile copywarrantinformation { get { return new ScannerFile("03_swat\\copywarrantinformation.mp3", "swat", "swat"); } }
        public static ScannerFile emergencytraffic { get { return new ScannerFile("03_swat\\emergencytraffic.mp3", "swat", "swat"); } }
        public static ScannerFile hitandrun { get { return new ScannerFile("03_swat\\hitandrun.mp3", "swat", "swat"); } }
        public static ScannerFile respondcode3 { get { return new ScannerFile("03_swat\\respondcode3.mp3", "swat", "swat"); } }
        public static ScannerFile tendavidgo { get { return new ScannerFile("03_swat\\tendavidgo.mp3", "swat", "swat"); } }
        public static ScannerFile tendavidgoahead { get { return new ScannerFile("03_swat\\tendavidgoahead.mp3", "swat", "swat"); } }
        public static ScannerFile tendavidrogershowusinroute { get { return new ScannerFile("03_swat\\tendavidrogershowusinroute.mp3", "swat", "swat"); } }
        public static ScannerFile multipleswatunitsresponding { get { return new ScannerFile("03_swat\\multipleswatunitsresponding.mp3", "swat", "swat"); } }
        public static ScannerFile numerousshotsfired { get { return new ScannerFile("03_swat\\numerousshotsfired.mp3", "swat", "swat"); } }
        public static ScannerFile requestingcode1alphain30minutes { get { return new ScannerFile("03_swat\\requestingcode1alphain30minutes.mp3", "swat", "swat"); } }
        public static ScannerFile suspectarmedusecaution { get { return new ScannerFile("03_swat\\suspectarmedusecaution.mp3", "swat", "swat"); } }
        public static ScannerFile suspectsarmedwithheavyweaponsandbodyarmor { get { return new ScannerFile("03_swat\\suspectsarmedwithheavyweaponsandbodyarmor.mp3", "swat", "swat"); } }
        public static ScannerFile swat10minuteeta { get { return new ScannerFile("03_swat\\swat10minuteeta.mp3", "swat", "swat"); } }
        public static ScannerFile tendavidrogerrespondingcode3 { get { return new ScannerFile("03_swat\\tendavidrogerrespondingcode3.mp3", "swat", "swat"); } }
    }


    public class ScannerFile
    {
        public ScannerFile()
        {

        }
        public ScannerFile(string _FileName, string _Quote, string _GroupName)
        {
            FileName = _FileName;
            Quote = _Quote;
            GroupName = _GroupName;
        }
        public string FileName { get; set; }
        public string Quote { get; set; }
        public string GroupName { get; set; }
    }
}