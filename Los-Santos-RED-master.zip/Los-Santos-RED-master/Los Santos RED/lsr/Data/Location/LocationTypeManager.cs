﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class LocationTypeManager
{
    public LocationTypeManager()
    {
    }

    public List<GameCounty> CountyList { get; set; } = new List<GameCounty>();
    public List<GameState> StateList { get; set; } = new List<GameState>();
}

