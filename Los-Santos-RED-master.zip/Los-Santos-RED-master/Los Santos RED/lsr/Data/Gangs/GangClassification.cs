﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum GangClassification
{
    Generic = 0,
    Mafia = 1,
    Street = 2,
    Cartel = 3,
    Biker = 4,
}