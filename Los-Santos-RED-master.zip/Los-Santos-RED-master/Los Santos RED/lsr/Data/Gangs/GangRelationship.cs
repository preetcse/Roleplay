﻿public enum GangRespect
{
    Friendly,
    Neutral,
    Hostile,
    Member,
}