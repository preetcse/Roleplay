﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum ResponseType
{
    LawEnforcement = 0,
    EMS = 1,
    Fire = 2,
    Other = 3,
    None = 4,
    Security = 5,
}