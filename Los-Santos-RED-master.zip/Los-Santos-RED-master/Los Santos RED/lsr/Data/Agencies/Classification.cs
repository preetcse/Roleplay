﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum Classification
{
    Police = 0,
    Sheriff = 1,
    Federal = 2,
    State = 3,
    Security = 4,
    Military = 5,
    Other = 6,
    EMS = 7,
    Fire = 8,
    Marshal = 9,
}