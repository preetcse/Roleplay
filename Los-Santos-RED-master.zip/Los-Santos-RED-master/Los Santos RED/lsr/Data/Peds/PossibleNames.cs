﻿using System.Collections.Generic;


public class PossibleNames
{


    public PossibleNames()
    {

    }
    public HashSet<string> MaleNames { get; set; } = new HashSet<string>();
    public HashSet<string> FemaleNames { get; set; } = new HashSet<string>();
    public HashSet<string> UnisexNames { get; set; } = new HashSet<string>();
    public HashSet<string> LastNames { get; set; } = new HashSet<string>();
  
}

