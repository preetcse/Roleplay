﻿public enum PoliceVehicleType
{
    Marked = 0,
    Unmarked = 1,
    Detective = 2,
    SlicktopMarked = 3,
    MarkedWithColor = 4,
    OlderMarked = 5,
    MarkedFlatLightbar = 6,
    MarkedValorLightbar = 7,
    MarkedOriginalLightbar = 8,
    MarkedNewSlicktop = 9,
}