﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class PlateTypeManager
{
    public List<PlateType> PlateTypeList = new List<PlateType>();
    public List<string> VanityPlates = new List<string>();

    public PlateTypeManager()
    {

    }
}

