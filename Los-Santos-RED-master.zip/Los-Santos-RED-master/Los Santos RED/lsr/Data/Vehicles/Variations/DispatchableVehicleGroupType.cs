﻿public enum DispatchbleVehicleGroupType
{
    Other = 0,
    Racing = 1,
}