﻿public enum PoliceServiceType
{
    Patrol = 0,
    Intercept = 1,
    GeneralUse = 2,
    Simple = 3,
}
