﻿public enum MilitaryVehicleType
{
    Unarmed = 0,
    Armed = 1,

}