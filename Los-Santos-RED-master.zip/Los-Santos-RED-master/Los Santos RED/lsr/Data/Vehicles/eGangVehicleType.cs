﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum GangVehicleType
{
    Gang1 = 0,
    Gang2 = 1,
    Gang3 = 2,
    Gang4 = 3,
}