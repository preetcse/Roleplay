﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum ServiceVehicleType
{
    Taxi1 = 0,
    Taxi2 = 1,
    Taxi3 = 2,
    Taxi4 = 3,
    Security = 4,
}