﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LosSantosRED.lsr.Data.Interface
{
    public interface ICraftable
    {
        string CraftingFlag { get; set; }
    }
}
