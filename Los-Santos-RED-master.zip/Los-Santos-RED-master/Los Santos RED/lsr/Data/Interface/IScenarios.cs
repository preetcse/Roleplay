﻿using Rage;
using System.Collections.Generic;

namespace LosSantosRED.lsr.Interface
{
    public interface IScenarios
    {
        List<Scenario> ScenarioList { get; }
    }
}
