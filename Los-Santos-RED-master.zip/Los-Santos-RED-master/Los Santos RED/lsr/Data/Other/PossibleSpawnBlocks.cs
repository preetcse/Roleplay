﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class PossibleSpawnBlocks
{
    public List<CarGeneratorBlock> CarGeneratorBlock { get; private set; } = new List<CarGeneratorBlock>();
    public List<ScenarioBlock> ScenarioBlocks { get; private set; } = new List<ScenarioBlock>();
}

