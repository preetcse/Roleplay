﻿using LosSantosRED.lsr.Interface;
using Rage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//public class LocationTeleporter
//{
//    private ILocationInteractable Player;
//    private GameLocation InteractableLocation;
//    private ISettingsProvideable Settings;
//    public bool IsInside { get; private set; }

//    public LocationTeleporter(ILocationInteractable player, GameLocation interactableLocation, ISettingsProvideable settings)
//    {
//        Player = player;
//        InteractableLocation = interactableLocation;
//        Settings = settings;
//    }
//    public void Teleport(LocationCamera locationCamera)
//    {
//        if(InteractableLocation.Interior != null && InteractableLocation.Interior.IsTeleportEntry)
//        {
//            InteractableLocation.Interior.Teleport(Player,InteractableLocation,locationCamera, Settings);
//        }
//    }
//}

