﻿using LosSantosRED.lsr.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//public class LEDispatcherNew : DefaultDispatcher
//{
//    public LEDispatcherNew(IEntityProvideable world, IDispatchable player, IAgencies agencies, ISettingsProvideable settings, IStreets streets, IZones zones, IJurisdictions jurisdictions, IWeapons weapons, INameProvideable names, IPlacesOfInterest placesOfInterest) : base(world, player, agencies, settings, streets, zones, jurisdictions, weapons, names, placesOfInterest)
//    {

//    }
//    protected override bool DetermineRun()
//    {
//        return base.DetermineRun();
//    }
//}

